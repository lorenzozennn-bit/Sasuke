import com.kenjutsu.anim.Clip;
import com.kenjutsu.anim.Pose;
import com.kenjutsu.choreo.PlayerClips;
import com.kenjutsu.choreo.ActorClips;
import com.kenjutsu.rig.Mat4;
import com.kenjutsu.rig.Skeleton;
import java.lang.reflect.Field;
import java.util.Locale;

/** Imprime, por tick, a ponta e o guarda-mão da espada: F=frente, R=direita, U=altura (blocos). */
public class KAnalyze {
    public static void main(String[] a) throws Exception {
        String filter = a.length > 0 ? a[0] : ".*";
        for (Class<?> c : new Class<?>[]{PlayerClips.class, ActorClips.class})
        for (Field f : c.getFields()) {
            if (f.getType() != Clip.class) continue;
            Clip clip = (Clip) f.get(null);
            if (!clip.name.matches(filter)) continue;
            System.out.println("== " + clip.name + " (" + clip.duration + " ticks)");
            for (float t = 0; t <= clip.duration + 0.01f; t += 1f) {
                Pose p = new Pose(); clip.sample(t, p);
                Skeleton.Rig rig = new Skeleton.Rig(); Skeleton.compute(p, false, rig);
                Mat4 s = Skeleton.bodyMatrixBlocks(0, p).mul(Skeleton.swordModelSpace(rig));
                float[] tip = new float[3], g = new float[3];
                s.transformPoint(Skeleton.SWORD_TIP[0], Skeleton.SWORD_TIP[1], Skeleton.SWORD_TIP[2], tip);
                s.transformPoint(Skeleton.SWORD_GUARD[0], Skeleton.SWORD_GUARD[1], Skeleton.SWORD_GUARD[2], g);
                float dx = tip[0]-g[0], dy = tip[1]-g[1], dz = tip[2]-g[2];
                float len = (float)Math.sqrt(dx*dx+dy*dy+dz*dz);
                System.out.println(String.format(Locale.ROOT, " t=%4.1f  ponta F=%5.2f R=%5.2f U=%5.2f | mão F=%5.2f R=%5.2f U=%5.2f | lâmina->F%+.2f R%+.2f U%+.2f",
                    t, tip[2], -tip[0], tip[1], g[2], -g[0], g[1], dz/len, -dx/len, dy/len));
            }
        }
    }
}
