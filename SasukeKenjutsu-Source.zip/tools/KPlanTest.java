import com.kenjutsu.choreo.*; import com.kenjutsu.combat.*;
public class KPlanTest {
  static void show(String n, Terrain t){ long t0=System.nanoTime(); FightPlanner.Plan p=FightPlanner.plan(t);
    System.out.printf("%-22s -> %-16s giro=%6.1f espelho=%-5s penal=%.2f (%d ms)%n", n, p.options.name, p.yawOffset, p.mirror, p.penalty, (System.nanoTime()-t0)/1000000);}
  public static void main(String[] a){
    show("aberto", Terrain.OPEN);
    show("parede a 5 na frente", new Terrain(){ public float height(float x,float z){return z>5?4:0;} public float clearance(float x,float z){return z>5?0:8;}});
    show("parede a 4 na direita", new Terrain(){ public float height(float x,float z){return x<-4?4:0;} public float clearance(float x,float z){return x<-4?0:8;}});
    show("sala 9x9 teto 3", new Terrain(){ public float height(float x,float z){return (Math.abs(x)>4.5||Math.abs(z)>4.5)?3:0;} public float clearance(float x,float z){return (Math.abs(x)>4.5||Math.abs(z)>4.5)?0:3;}});
    show("caverna teto 3", new Terrain(){ public float height(float x,float z){return 0;} public float clearance(float x,float z){return 3;}});
    show("corredor 5 largura", new Terrain(){ public float height(float x,float z){return Math.abs(x)>2.5?4:0;} public float clearance(float x,float z){return Math.abs(x)>2.5?0:8;}});
    show("penhasco atras", new Terrain(){ public float height(float x,float z){return z<-3?Float.NaN:0;} public float clearance(float x,float z){return 8;}});
  }}
