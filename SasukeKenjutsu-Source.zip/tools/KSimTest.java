import com.kenjutsu.anim.Pose;
import com.kenjutsu.choreo.Choreography;
import com.kenjutsu.choreo.ChoreographyLibrary;
import com.kenjutsu.choreo.ImpactType;
import com.kenjutsu.combat.CombatState;
import com.kenjutsu.combat.CombatStateMachine;
import com.kenjutsu.combat.SceneFx;
import com.kenjutsu.combat.VirtualActor;
import com.kenjutsu.rig.Skeleton;

import java.util.Random;

/** Teste de lógica: os 4 combos terminam em vitória em qualquer ritmo de clique. */
public class KSimTest {
    static int failures = 0;
    static void check(boolean c, String m) { if (!c) { failures++; if (failures < 40) System.out.println("  FALHA: " + m); } }

    public static void main(String[] a) {
        Skeleton.Rig rig = new Skeleton.Rig();
        for (com.kenjutsu.choreo.FightOptions fo : com.kenjutsu.choreo.FightOptions.TIERS) {
            Choreography c = ChoreographyLibrary.fight(fo);
            System.out.println("== [" + c.name + "] " + c.steps().size() + " etapas");
            check(c.actorCount() == 1, "1v1");
            for (String sc : new String[]{"paced", "spam", "slow"}) {
                int[] imp = {0}, def = {0}, vic = {0};
                CombatStateMachine m = new CombatStateMachine();
                m.setFx(new SceneFx() {
                    public void onImpact(VirtualActor x, ImpactType t) { imp[0]++; }
                    public void onActorDefeated(VirtualActor x) { def[0]++; }
                    public void onVictory() { vic[0]++; }
                });
                m.start(c, 0);
                check(m.state() == CombatState.READY, "READY inicial");
                Pose tmp = new Pose();
                float clock = 0;
                for (int t = 1; t < 4000; t++) {
                    boolean click = sc.equals("spam") || (sc.equals("slow") ? t % 40 == 0 : t % 12 == 0);
                    if (click) m.onClick(clock);
                    clock += 1.6f;
                    m.tick(clock);
                    for (float p = 0; p < 1; p += 0.25f) {
                        float now = clock + p * 1.6f;
                        check(m.player().pose(now, tmp).isFinite(), "pose jogador finita");
                        Skeleton.compute(tmp, false, rig);
                        float[] pp = m.playerPosition(now, new float[2]);
                        check(Float.isFinite(pp[0]) && Float.isFinite(pp[1]), "posição finita");
                        check(Float.isFinite(m.playerFacing(now)) && Float.isFinite(m.actorFacing(now)), "direção finita");
                        for (VirtualActor x : m.actors()) {
                            check(x.pose(now, tmp).isFinite(), "pose ator finita");
                            float[] ap = x.position(now, new float[2]);
                            float d = (float) Math.hypot(ap[0] - pp[0], ap[1] - pp[1]);
                            check(d < 30f, "distância " + d);
                        }
                    }
                    if (m.state() == CombatState.VICTORY && t > 600) break;
                }
                check(m.state() == CombatState.VICTORY, sc + ": VICTORY (" + m.state() + ")");
                check(vic[0] == 1, sc + ": vitória 1x");
                check(def[0] == 1, sc + ": 1 derrota");
                check(m.player().currentClipName().equals("p_victory"), sc + ": clip final " + m.player().currentClipName());
                check(!m.onClick(clock + 10), "clique pós-vitória ignorado");
                System.out.println("  " + sc + ": OK impactos=" + imp[0]);
                m.start(c, clock + 100);
                check(m.state() == CombatState.READY, "reinício READY");
            }
        }
        Random r = new Random(7);
        int prev = -1;
        if (ChoreographyLibrary.variants().size() > 1)
            for (int i = 0; i < 500; i++) { int n = ChoreographyLibrary.pickIndex(r, prev); check(n != prev, "combo repetido"); prev = n; }
        System.out.println(failures == 0 ? "TUDO OK" : ("FALHAS: " + failures));
        System.exit(failures == 0 ? 0 : 1);
    }
}
