import com.kenjutsu.anim.Clip;
import com.kenjutsu.anim.Pose;
import com.kenjutsu.choreo.ActorClips;
import com.kenjutsu.choreo.Choreography;
import com.kenjutsu.choreo.ChoreographyLibrary;
import com.kenjutsu.choreo.PlayerClips;
import com.kenjutsu.combat.CombatState;
import com.kenjutsu.combat.CombatStateMachine;
import com.kenjutsu.combat.VirtualActor;
import com.kenjutsu.rig.Mat4;
import com.kenjutsu.rig.Skeleton;

import java.io.FileWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.List;
import java.util.Locale;

/**
 * Ferramenta de desenvolvimento: exporta vértices JÁ transformados (mesma rotina
 * Skeleton.emit usada no jogo), por camada, mais os pontos da espada.
 * Uso: java KPreview saida.json [filtroRegex]
 */
public class KPreview {

    static StringBuilder sb = new StringBuilder();

    public static void main(String[] args) throws Exception {
        String out = args.length > 0 ? args[0] : "k.json";
        String filter = args.length > 1 ? args[1] : ".*";
        sb.append("{\"sheets\":[");
        boolean first = true;
        for (Class<?> c : new Class<?>[]{PlayerClips.class, ActorClips.class}) {
            for (Field f : c.getFields()) {
                if (!Modifier.isStatic(f.getModifiers()) || f.getType() != Clip.class) continue;
                Clip clip = (Clip) f.get(null);
                if (!clip.name.matches(filter)) continue;
                if (!first) sb.append(',');
                first = false;
                clipSheet(clip, c == PlayerClips.class);
            }
        }
        List<Choreography> vs = ChoreographyLibrary.variants();
        for (int i = 0; i < vs.size(); i++) {
            String name = "combo_" + i;
            if (!name.matches(filter)) continue;
            if (!first) sb.append(',');
            first = false;
            comboSheet(name, vs.get(i));
        }
        sb.append("]}");
        try (FileWriter w = new FileWriter(out)) {
            w.write(sb.toString());
        }
        System.out.println("ok " + out + " " + sb.length() / 1024 + " KB");
    }

    static void num(float f) {
        sb.append(String.format(Locale.ROOT, "%.3f", f));
    }

    static final String[] LAYER_NAMES = {"skin", "skin2", "armor1", "armor2"};

    /** Corpo completo: camadas + espada. tint: 0 jogador, 1 adversário. */
    static void body(double x, double y, double z, float yaw, Pose p, int tint, boolean sword) {
        Skeleton.Rig rig = new Skeleton.Rig();
        Skeleton.compute(p, false, rig);
        Mat4 base = new Mat4().translate((float) x, (float) y, (float) z).mul(Skeleton.bodyMatrix(yaw, p));
        sb.append("{\"tint\":").append(tint).append(",\"layers\":{");
        for (int l = 0; l < Skeleton.LAYERS; l++) {
            if (l > 0) sb.append(',');
            sb.append('"').append(LAYER_NAMES[l]).append("\":[");
            final boolean[] firstV = {true};
            for (int b = 0; b < Skeleton.BONES; b++) {
                Skeleton.emit(base, rig, false, l, b, (vx, vy, vz, u, v, nx, ny, nz) -> {
                    if (!firstV[0]) sb.append(',');
                    firstV[0] = false;
                    num(vx); sb.append(','); num(vy); sb.append(','); num(vz); sb.append(',');
                    num(u); sb.append(','); num(v);
                });
            }
            sb.append(']');
        }
        sb.append('}');
        if (sword) {
            Mat4 s = new Mat4().translate((float) x, (float) y, (float) z)
                    .mul(Skeleton.bodyMatrixBlocks(yaw, p)).mul(Skeleton.swordModelSpace(rig));
            sb.append(",\"sword\":[");
            float[] t = new float[3];
            float[][] pts = {Skeleton.SWORD_POMMEL, Skeleton.SWORD_GUARD, Skeleton.SWORD_TIP};
            for (int i = 0; i < 3; i++) {
                s.transformPoint(pts[i][0], pts[i][1], pts[i][2], t);
                if (i > 0) sb.append(',');
                num(t[0]); sb.append(','); num(t[1]); sb.append(','); num(t[2]);
            }
            sb.append(']');
        }
        sb.append('}');
    }

    static void clipSheet(Clip c, boolean player) {
        sb.append("{\"name\":\"").append(c.name).append("\",\"frames\":[");
        int frames = c.loop ? 4 : 8;
        for (int i = 0; i < frames; i++) {
            float t = c.duration * i / (frames - 1);
            Pose p = new Pose();
            c.sample(t, p);
            if (i > 0) sb.append(',');
            sb.append("{\"label\":\"t=").append(String.format(Locale.ROOT, "%.1f", t)).append("\",\"bodies\":[");
            body(0, 0, 0, 0, p, player ? 0 : 1, true);
            sb.append(',');
            Pose partner = new Pose();
            (player ? ActorClips.GUARD_IDLE : PlayerClips.GUARD_IDLE).sample(0, partner);
            body(0, 0, 1.7, 180, partner, player ? 1 : 0, true);
            sb.append("]}");
        }
        sb.append("]}");
    }

    static void comboSheet(String name, Choreography c) {
        sb.append("{\"name\":\"").append(name).append("\",\"scene\":true,\"title\":\"").append(c.name)
                .append("\",\"frames\":[");
        CombatStateMachine m = new CombatStateMachine();
        m.start(c, 0);
        int t = 0;
        boolean first = true;
        for (int s = 0; s < c.steps().size(); s++) {
            if (m.stepNumber() <= s) m.onClick(t);
            int dur = c.steps().get(s).duration;
            for (int k = 0; k < dur; k++) {
                t++;
                m.tick(t);
                if (t % 2 == 0) {
                    if (!first) sb.append(',');
                    first = false;
                    frame(m, t, "t" + t + " e" + m.stepNumber());
                }
            }
        }
        for (int k = 0; k < 24; k++) { t++; m.tick(t); }
        sb.append(',');
        frame(m, t, m.state() == CombatState.VICTORY ? "vitoria" : "fim");
        sb.append("]}");
    }

    static void frame(CombatStateMachine m, float now, String label) {
        sb.append("{\"label\":\"").append(label).append("\",\"bodies\":[");
        Pose p = new Pose();
        m.playerPose(now, p);
        // arena (f, r) -> preview: z = f, x = -r; direção: yaw = ângulo da arena
        float[] pp = m.playerPosition(now, new float[2]);
        body(-pp[1], 0, pp[0], m.playerFacing(now), p, 0, true);
        for (VirtualActor a : m.actors()) {
            Pose ap = new Pose();
            m.actorPose(a, now, ap);
            float[] q = a.position(now, new float[2]);
            sb.append(',');
            body(-q[1], 0, q[0], m.actorFacing(now), ap, 1, !a.isDisarmed(now));
        }
        sb.append("]}");
    }
}
