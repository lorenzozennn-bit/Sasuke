import com.kenjutsu.anim.Clip;
import com.kenjutsu.anim.Pose;
import com.kenjutsu.choreo.PlayerClips;
import com.kenjutsu.rig.Mat4;
import com.kenjutsu.rig.Skeleton;
import java.util.Locale;

/** Verifica se a lâmina atravessa o corpo do adversário (a D blocos) perto do tick de impacto. */
public class KCheck {
    static float[] seg(Clip c, float t) {
        Pose p = new Pose(); c.sample(t, p);
        Skeleton.Rig rig = new Skeleton.Rig(); Skeleton.compute(p, false, rig);
        Mat4 s = Skeleton.bodyMatrixBlocks(0, p).mul(Skeleton.swordModelSpace(rig));
        float[] g = new float[3], tp = new float[3];
        s.transformPoint(Skeleton.SWORD_GUARD[0], Skeleton.SWORD_GUARD[1], Skeleton.SWORD_GUARD[2], g);
        s.transformPoint(Skeleton.SWORD_TIP[0], Skeleton.SWORD_TIP[1], Skeleton.SWORD_TIP[2], tp);
        return new float[]{g[2], -g[0], g[1], tp[2], -tp[0], tp[1]}; // F R U
    }
    public static void main(String[] a) {
        Object[][] strikes = {
            {PlayerClips.SLASH_DOWN, 4f}, {PlayerClips.SLASH_UP, 3f}, {PlayerClips.SLASH_HORIZ, 3f},
            {PlayerClips.SPIN_SLASH, 6f}, {PlayerClips.THRUST, 4f}, {PlayerClips.FLAT_SLAP, 3f},
            {PlayerClips.IAI_DASH, 5f}, {PlayerClips.FLICK_DISARM, 2f}};
        float D = a.length > 0 ? Float.parseFloat(a[0]) : 1.35f;
        for (Object[] s : strikes) {
            Clip c = (Clip) s[0]; float imp = (Float) s[1];
            StringBuilder sb = new StringBuilder();
            float firstHit = -1, lastHit = -1, hitU = 0;
            for (float t = imp - 1.5f; t <= imp + 1.5f; t += 0.1f) {
                float[] g = seg(c, t);
                // amostra 20 pontos da lâmina
                for (int i = 0; i <= 20; i++) {
                    float k = i / 20f;
                    float F = g[0] + (g[3]-g[0])*k, R = g[1] + (g[4]-g[1])*k, U = g[2] + (g[5]-g[2])*k;
                    if (Math.abs(F - D) < 0.2f && Math.abs(R) < 0.32f && U > 0.65f && U < 1.9f) {
                        if (firstHit < 0) { firstHit = t; hitU = U; }
                        lastHit = t; break;
                    }
                }
            }
            float[] at = seg(c, imp);
            System.out.println(String.format(Locale.ROOT, "%-16s impacto t=%.0f | %s | no impacto: mão F%.2f R%.2f U%.2f  ponta F%.2f R%.2f U%.2f",
                c.name, imp, firstHit < 0 ? "NÃO ACERTA" : String.format(Locale.ROOT, "acerta de t=%.1f a %.1f (altura %.2f)", firstHit, lastHit, hitU),
                at[0], at[1], at[2], at[3], at[4], at[5]));
        }
    }
}
