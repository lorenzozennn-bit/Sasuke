import com.kenjutsu.anim.Pose;
import com.kenjutsu.rig.*;
import com.kenjutsu.choreo.PlayerClips;
import java.util.Locale;
public class KReach {
  public static void main(String[] a) throws Exception {
    Pose p = Pose.from(PlayerClips.GUARD).root(0,0,0).body(0,0,0);
    Skeleton.Rig rig = new Skeleton.Rig(); Skeleton.compute(p, false, rig);
    Mat4 body = Skeleton.bodyMatrixBlocks(0, p);
    float[] t = new float[3];
    Mat4 sh = body.copy().mul(rig.bones[Skeleton.TORSO].copy().translate(-5,-10,0).withScaledTranslation(0.0625f).scale(0.0625f,0.0625f,0.0625f));
    // ombro
    Mat4 s0 = body.copy().scale(0.0625f,0.0625f,0.0625f).mul(rig.bones[Skeleton.TORSO]).translate(-5,-10,0);
    s0.transformPoint(0,0,0,t); System.out.println(String.format(Locale.ROOT,"ombro F=%.2f R=%.2f U=%.2f", t[2], -t[0], t[1]));
    java.lang.reflect.Method m = SwordIK.class.getDeclaredMethod("swordFrame", Mat4.class, Mat4.class, float.class, float.class, float.class, float.class);
    m.setAccessible(true);
    float maxF=-9; String best="";
    for (int x=-180;x<=60;x+=10) for (int y=-90;y<=90;y+=15) for (int z=-180;z<=180;z+=20) for (int e=0;e<=120;e+=20) {
      Mat4 sw = (Mat4) m.invoke(null, body, rig.bones[Skeleton.TORSO], (float)x,(float)y,(float)z,(float)e);
      float[] g=new float[3], tp=new float[3];
      sw.transformPoint(Skeleton.SWORD_GUARD[0],Skeleton.SWORD_GUARD[1],Skeleton.SWORD_GUARD[2],g);
      sw.transformPoint(Skeleton.SWORD_TIP[0],Skeleton.SWORD_TIP[1],Skeleton.SWORD_TIP[2],tp);
      if (tp[2] > maxF) { maxF = tp[2]; best = String.format(Locale.ROOT,"ra(%d,%d,%d) e%d guard F=%.2f R=%.2f U=%.2f tip F=%.2f R=%.2f U=%.2f", x,y,z,e,g[2],-g[0],g[1],tp[2],-tp[0],tp[1]); }
    }
    System.out.println("ponta mais à frente: " + best);
    // comprimento da lâmina
    Mat4 sw = (Mat4) m.invoke(null, body, rig.bones[Skeleton.TORSO], 0f,0f,0f,0f);
    float[] g=new float[3], tp=new float[3], pm=new float[3];
    sw.transformPoint(Skeleton.SWORD_GUARD[0],Skeleton.SWORD_GUARD[1],Skeleton.SWORD_GUARD[2],g);
    sw.transformPoint(Skeleton.SWORD_TIP[0],Skeleton.SWORD_TIP[1],Skeleton.SWORD_TIP[2],tp);
    sw.transformPoint(Skeleton.SWORD_POMMEL[0],Skeleton.SWORD_POMMEL[1],Skeleton.SWORD_POMMEL[2],pm);
    System.out.println(String.format(Locale.ROOT,"lâmina %.2f  cabo %.2f  guarda F=%.2f R=%.2f U=%.2f", Math.hypot(Math.hypot(tp[0]-g[0],tp[1]-g[1]),tp[2]-g[2]), Math.hypot(Math.hypot(pm[0]-g[0],pm[1]-g[1]),pm[2]-g[2]), g[2],-g[0],g[1]));
  }
}
