import com.kenjutsu.anim.Pose;
import com.kenjutsu.rig.SwordIK;
import com.kenjutsu.choreo.PlayerClips;
import java.util.Locale;
public class KIKTest {
  public static void main(String[] a) {
    float[][][] cases = {
      {{0.1f, 0.33f, 0.72f}, {0.7f, 0.1f, -0.7f}},     // guarda baixa: lâmina para frente-baixo
      {{0.1f, 0.35f, 1.75f}, {-0.6f, 0.1f, 0.8f}},      // preparação acima do ombro direito
      {{0.85f, 0.15f, 1.3f}, {0.8f, -0.3f, -0.35f}},    // contato do kesagiri no ombro
      {{0.6f, -0.3f, 0.8f}, {0.5f, -0.7f, -0.5f}},      // fim do corte embaixo à esquerda
      {{0.85f, 0.05f, 1.2f}, {1f, 0f, 0f}},             // estocada horizontal
      {{0.4f, 0.3f, 1.9f}, {0.1f, -1f, 0.05f}},         // apara alta horizontal
    };
    for (float[][] c : cases) {
      long t0 = System.nanoTime();
      Pose p = Pose.from(PlayerClips.GUARD);
      p.off(0,0,0.3f);
      SwordIK.Result r = SwordIK.solveDir(p, c[0], c[1], false);
      System.out.println(String.format(Locale.ROOT, "ra(%.0f, %.0f, %.0f) cot %.0f tronco(%.0f,%.0f) erro %.3f (%.1f ms)", r.v[0], r.v[1], r.v[2], r.v[3], r.v[4], r.v[5], r.error, (System.nanoTime()-t0)/1e6));
    }
  }
}
