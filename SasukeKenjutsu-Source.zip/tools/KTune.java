import com.kenjutsu.anim.Pose;
import com.kenjutsu.choreo.PlayerClips;
import com.kenjutsu.rig.SwordIK;
import java.util.Locale;
/** Resolve poses de contato pontuais e imprime os ângulos para colar nos clipes. */
public class KTune {
  static void go(String name, Pose base, float[] guard, float[] dir, boolean local) {
    Pose p = Pose.from(base);
    SwordIK.Result r = SwordIK.solveDir(p, guard, dir, local);
    System.out.println(String.format(Locale.ROOT, "%-22s .body(%.0f, %.0f, ...) .ra(%.0f, %.0f, %.0f) cotovelo %.0f   erro %.3f", name, r.v[4], r.v[5], r.v[0], r.v[1], r.v[2], r.v[3], r.error));
  }
  public static void main(String[] a) {
    Pose G = PlayerClips.GUARD;
    go("iai pronto", Pose.from(G).root(-15,0,0).body(28,0,0).knees(85,70).ll(-45,0,-4).rl(35,0,6), new float[]{-0.05f,0.4f,0.75f}, new float[]{-1f,0.15f,-0.25f}, true);
    go("iai entra", Pose.from(G).root(0,0,0).body(24,0,0).knees(60,40).ll(-55,0,-4).rl(45,0,6), new float[]{0.45f,0.6f,1.1f}, new float[]{0.75f,0.65f,0.05f}, true);
    go("iai passa", Pose.from(G).root(0,0,0).body(22,0,0).knees(65,45).ll(-50,0,-4).rl(40,0,6), new float[]{0.15f,0.75f,1.1f}, new float[]{-0.55f,0.85f,0f}, true);
    go("iai final", Pose.from(G).root(0,0,0).body(10,0,0).knees(35,30), new float[]{-0.05f,0.55f,0.85f}, new float[]{-0.7f,0.4f,-0.6f}, true);
  }
}
