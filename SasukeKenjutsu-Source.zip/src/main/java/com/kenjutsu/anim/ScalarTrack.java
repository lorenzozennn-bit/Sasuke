package com.kenjutsu.anim;

/**
 * Valor escalar animado (distância de um ator, direção do jogador...).
 * Quando {@code angular} é verdadeiro, interpola pelo menor arco.
 */
public final class ScalarTrack {

    private final boolean angular;
    private float from;
    private float to;
    private float start;
    private float duration;
    private Ease ease = Ease.SMOOTH;

    public ScalarTrack(boolean angular, float initial) {
        this.angular = angular;
        this.from = initial;
        this.to = initial;
    }

    public void reset(float value) {
        from = value;
        to = value;
        duration = 0.0F;
    }

    public void moveTo(float target, float now, float ticks) {
        moveTo(target, now, ticks, Ease.SMOOTH);
    }

    public void moveTo(float target, float now, float ticks, Ease ease) {
        this.ease = ease == null ? Ease.SMOOTH : ease;
        float current = value(now);
        from = current;
        if (angular) {
            target = current + Pose.wrapDegrees(target - current);
        }
        to = target;
        start = now;
        duration = Math.max(0.0F, ticks);
    }

    public float target() {
        return to;
    }

    public float value(float now) {
        if (duration <= 0.0F) return to;
        float t = (now - start) / duration;
        if (t <= 0.0F) return from;
        if (t >= 1.0F) return to;
        return from + (to - from) * ease.apply(t);
    }
}
