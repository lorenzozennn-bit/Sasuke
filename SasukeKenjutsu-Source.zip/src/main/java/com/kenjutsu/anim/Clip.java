package com.kenjutsu.anim;

import java.util.ArrayList;
import java.util.List;

/**
 * Clipe de animação: sequência ordenada de keyframes, amostrado com tempo
 * contínuo (ticks + partialTicks).
 *
 * Interpolação: spline cúbica de Hermite com tangentes monotônicas
 * (Fritsch–Carlson). A velocidade de cada articulação é CONTÍNUA ao passar por
 * um keyframe (o movimento flui, não "para" em cada pose), sem ultrapassar os
 * valores das poses (sem tremedeira nem membro passando do ponto).
 *
 * A curva do segmento muda o caráter do movimento:
 *  - SMOOTH: fluido, tangentes calculadas pelos vizinhos;
 *  - OUT: golpe — sai explosivo e entrega a velocidade ao follow-through;
 *  - IN: queda — começa natural e chega acelerando;
 *  - LINEAR / RUN: interpolação direta com a curva indicada.
 */
public final class Clip {

    public final String name;
    private final Keyframe[] keys;
    /** Tangente (unidades por tick) de cada canal em cada keyframe. */
    private final float[][] tan;
    public final float duration;
    public final boolean loop;

    private Clip(String name, List<Keyframe> keys, boolean loop) {
        this.name = name;
        this.keys = keys.toArray(new Keyframe[0]);
        this.duration = this.keys[this.keys.length - 1].time;
        this.loop = loop;
        this.tan = computeTangents();
    }

    private float[][] computeTangents() {
        int n = keys.length;
        float[][] m = new float[n][Pose.SIZE];
        for (int k = 0; k < n; k++) {
            int kp, kn;
            float dtp, dtn;
            if (k > 0 && k < n - 1) {
                kp = k - 1; kn = k + 1;
                dtp = keys[k].time - keys[kp].time;
                dtn = keys[kn].time - keys[k].time;
            } else if (loop && n > 2) {
                // primeiro/último keyframe coincidem num loop: vizinhos são o penúltimo e o segundo
                kp = n - 2; kn = 1;
                dtp = keys[n - 1].time - keys[n - 2].time;
                dtn = keys[1].time - keys[0].time;
            } else {
                continue; // extremos de clipe sem loop: partem/chegam em repouso
            }
            if (dtp <= 0.0F || dtn <= 0.0F) continue;
            for (int i = 0; i < Pose.SIZE; i++) {
                float d0 = (keys[k].pose.v[i] - keys[kp].pose.v[i]) / dtp;
                float d1 = (keys[kn].pose.v[i] - keys[k].pose.v[i]) / dtn;
                if (d0 * d1 <= 0.0F) {
                    m[k][i] = 0.0F; // extremo local: pausa natural (antecipação/fim do arco)
                } else {
                    // média harmônica ponderada (Fritsch–Butland): monotônica por construção
                    float w0 = 2.0F * dtn + dtp, w1 = dtn + 2.0F * dtp;
                    m[k][i] = (w0 + w1) / (w0 / d0 + w1 / d1);
                }
            }
        }
        return m;
    }

    public static Builder build(String name) {
        return new Builder(name);
    }

    public int keyCount() {
        return keys.length;
    }

    public Pose firstPose() {
        return keys[0].pose;
    }

    public Pose lastPose() {
        return keys[keys.length - 1].pose;
    }

    /** Escreve em {@code out} a pose no instante {@code t} (ticks desde o início do clipe). */
    public void sample(float t, Pose out) {
        if (loop && duration > 0.0F) {
            t = t % duration;
            if (t < 0.0F) t += duration;
        }
        if (t <= keys[0].time) {
            out.set(keys[0].pose);
            return;
        }
        Keyframe last = keys[keys.length - 1];
        if (t >= last.time) {
            out.set(last.pose);
            return;
        }
        for (int k = 1; k < keys.length; k++) {
            Keyframe b = keys[k];
            if (t <= b.time) {
                segment(k, t, out);
                return;
            }
        }
        out.set(last.pose);
    }

    private void segment(int k, float t, Pose out) {
        Keyframe a = keys[k - 1], b = keys[k];
        float span = b.time - a.time;
        if (span <= 0.0F) {
            out.set(b.pose);
            return;
        }
        float u = (t - a.time) / span;
        Ease e = b.ease;
        if (e == Ease.LINEAR || e == Ease.RUN) {
            Pose.lerp(a.pose, b.pose, e.apply(u), out);
            return;
        }
        float u2 = u * u, u3 = u2 * u;
        float h00 = 2 * u3 - 3 * u2 + 1, h10 = u3 - 2 * u2 + u, h01 = -2 * u3 + 3 * u2, h11 = u3 - u2;
        for (int i = 0; i < Pose.SIZE; i++) {
            float p0 = a.pose.v[i], p1 = b.pose.v[i];
            float c = p1 - p0; // variação no segmento
            float m0, m1;
            if (e == Ease.OUT) {
                m0 = 2.4F * c;              // saída explosiva
                m1 = tan[k][i] * span;      // velocidade que segue no follow-through
            } else if (e == Ease.IN) {
                m0 = tan[k - 1][i] * span;
                m1 = 2.4F * c;              // chega acelerando
            } else {
                m0 = tan[k - 1][i] * span;
                m1 = tan[k][i] * span;
            }
            // Fritsch–Carlson: sem ultrapassar as poses
            if (c == 0.0F) {
                m0 = 0.0F;
                m1 = 0.0F;
            } else {
                float al = m0 / c, be = m1 / c;
                if (al < 0.0F) { m0 = 0.0F; al = 0.0F; }
                if (be < 0.0F) { m1 = 0.0F; be = 0.0F; }
                float r = al * al + be * be;
                if (r > 9.0F) {
                    float s = 3.0F / (float) Math.sqrt(r);
                    m0 *= s;
                    m1 *= s;
                }
            }
            out.v[i] = h00 * p0 + h10 * m0 + h01 * p1 + h11 * m1;
        }
    }

    public static final class Builder {
        private final String name;
        private final List<Keyframe> keys = new ArrayList<Keyframe>();
        private boolean loop;

        private Builder(String name) {
            this.name = name;
        }

        public Builder key(float time, Pose pose) {
            return key(time, pose, Ease.SMOOTH);
        }

        public Builder key(float time, Pose pose, Ease ease) {
            if (!keys.isEmpty() && time < keys.get(keys.size() - 1).time) {
                throw new IllegalArgumentException("keyframes fora de ordem no clipe " + name);
            }
            keys.add(new Keyframe(time, pose, ease));
            return this;
        }

        public Builder loop() {
            this.loop = true;
            return this;
        }

        public Clip done() {
            if (keys.isEmpty()) throw new IllegalStateException("clipe sem keyframes: " + name);
            return new Clip(name, keys, loop);
        }
    }
}
