package com.kenjutsu.anim;

/**
 * Trilha de animação de um corpo. Toca um clipe por vez e faz a transição a
 * partir do clipe anterior AINDA EM MOVIMENTO (não de uma pose congelada):
 * o golpe seguinte "pega" o corpo no meio do embalo, como numa luta de anime.
 *
 * Camada de sobreposição (overlapping action): o braço esquerdo e a cabeça
 * seguem o corpo com um pequeno atraso, então nada se move em bloco. O braço
 * da espada não tem atraso (precisão do corte).
 */
public final class AnimTrack {

    private static final float LAG_LEFT_ARM = 1.4F;
    private static final float LAG_HEAD = 0.6F;

    private Clip clip;
    private float start;
    private float blendTicks;
    private boolean blending;

    // Origem da transição: clipe anterior tocando ao vivo, ou pose congelada
    // (quando a troca acontece no meio de outra transição).
    private Clip prevClip;
    private float prevStart;
    private boolean prevFrozen;
    private final Pose frozen = new Pose();

    private final Pose scratch = new Pose();
    private final Pose fromPose = new Pose();
    private final Pose lagPose = new Pose();

    /** Troca de clipe com transição suave a partir do movimento atual. */
    public void play(Clip next, float now, float blend) {
        if (next == null) return;
        if (clip != null && blend > 0.0F) {
            float t = now - start;
            if (blending && t < blendTicks) {
                sampleBase(now, frozen);
                prevFrozen = true;
            } else {
                prevFrozen = false;
            }
            prevClip = clip;
            prevStart = start;
            blending = true;
        } else {
            blending = false;
        }
        clip = next;
        start = now;
        blendTicks = blend;
    }

    /** Troca imediata, sem transição (usada ao montar a cena). */
    public void snap(Clip next, float now) {
        clip = next;
        start = now;
        blending = false;
    }

    public Clip clip() {
        return clip;
    }

    public float startTime() {
        return start;
    }

    public boolean isFinished(float now) {
        return clip != null && !clip.loop && now - start >= clip.duration;
    }

    /** Pose final (com sobreposição). Sem efeitos colaterais visíveis: pode ser amostrada em qualquer instante. */
    public Pose sample(float now, Pose out) {
        if (clip == null) return out;
        sampleBase(now, out);
        sampleBase(now - LAG_LEFT_ARM, lagPose);
        copy(lagPose, out, Pose.L_ARM, 3);
        out.v[Pose.L_ELBOW] = lagPose.v[Pose.L_ELBOW];
        sampleBase(now - LAG_HEAD, lagPose);
        copy(lagPose, out, Pose.HEAD, 3);
        return out;
    }

    private static void copy(Pose from, Pose to, int index, int n) {
        System.arraycopy(from.v, index, to.v, index, n);
    }

    private void sampleBase(float now, Pose out) {
        float t = now - start;
        if (t < 0.0F) t = 0.0F;
        clip.sample(t, out);
        if (blending && t < blendTicks) {
            if (prevFrozen || prevClip == null) {
                fromPose.set(frozen);
            } else {
                prevClip.sample(Math.max(0.0F, now - prevStart), fromPose);
            }
            Pose.blendWrapped(fromPose, out, Ease.SMOOTH.apply(t / blendTicks), out);
        }
    }
}
