package com.kenjutsu.anim;

/**
 * Trilha de animação de um corpo. Toca um clipe por vez e faz crossfade
 * automático a partir da pose anterior, para que nenhuma transição "quebre".
 */
public final class AnimTrack {

    private Clip clip;
    private float start;
    private final Pose from = new Pose();
    private final Pose scratch = new Pose();
    private float blendTicks;
    private boolean blending;

    /** Troca de clipe com transição suave a partir da pose atual. */
    public void play(Clip next, float now, float blend) {
        if (next == null) return;
        if (clip != null && blend > 0.0F) {
            sample(now, scratch);
            from.set(scratch);
            blending = true;
        } else {
            blending = false;
        }
        clip = next;
        start = now;
        blendTicks = blend;
    }

    /** Troca imediata, sem transição (usada ao montar a cena). */
    public void snap(Clip next, float now) {
        clip = next;
        start = now;
        blending = false;
    }

    public Clip clip() {
        return clip;
    }

    public float startTime() {
        return start;
    }

    public boolean isFinished(float now) {
        return clip != null && !clip.loop && now - start >= clip.duration;
    }

    public Pose sample(float now, Pose out) {
        if (clip == null) {
            return out;
        }
        float t = now - start;
        if (t < 0.0F) t = 0.0F;
        clip.sample(t, out);
        // Sem efeitos colaterais: pode ser amostrado em qualquer instante (rastro da espada).
        if (blending && t < blendTicks) {
            Pose.blendWrapped(from, out, Ease.SMOOTH.apply(t / blendTicks), out);
        }
        return out;
    }
}
