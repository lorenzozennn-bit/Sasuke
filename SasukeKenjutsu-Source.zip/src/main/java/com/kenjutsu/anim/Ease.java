package com.kenjutsu.anim;

/** Curvas de aceleração aplicadas ao segmento que chega em um keyframe. */
public enum Ease {
    LINEAR,
    /** Suave na entrada e na saída. */
    SMOOTH,
    /** Explosivo: começa rápido e desacelera (golpes). */
    OUT,
    /** Começa lento e acelera (quedas). */
    IN,
    /** Corrida: acelera, mantém velocidade constante e freia (perfil trapezoidal). */
    RUN;

    private static final float RAMP = 0.2F;

    public float apply(float t) {
        if (t <= 0.0F) return 0.0F;
        if (t >= 1.0F) return 1.0F;
        switch (this) {
            case SMOOTH:
                return t * t * (3.0F - 2.0F * t);
            case OUT: {
                float u = 1.0F - t;
                return 1.0F - u * u * u;
            }
            case IN:
                return t * t * t;
            case RUN: {
                float vmax = 1.0F / (1.0F - RAMP);
                if (t < RAMP) return vmax * t * t / (2.0F * RAMP);
                if (t > 1.0F - RAMP) {
                    float u = 1.0F - t;
                    return 1.0F - vmax * u * u / (2.0F * RAMP);
                }
                return vmax * (t - RAMP * 0.5F);
            }
            case LINEAR:
            default:
                return t;
        }
    }
}
