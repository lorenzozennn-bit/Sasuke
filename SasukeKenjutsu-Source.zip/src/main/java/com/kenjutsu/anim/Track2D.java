package com.kenjutsu.anim;

/**
 * Posição animada no chão da arena (f = frente, r = direita, em blocos).
 * Move em linha reta ou em arco (órbita em volta de um centro).
 * Amostragem sem efeitos colaterais: pode ser lida em qualquer instante.
 */
public final class Track2D {

    private float fx, fz, tx, tz;
    private float start, dur;
    private Ease ease = Ease.SMOOTH;
    private boolean arc;
    private float cx, cz, sweep;
    private final float[] tmp = new float[2];

    public Track2D(float x, float z) {
        reset(x, z);
    }

    public void reset(float x, float z) {
        fx = tx = x;
        fz = tz = z;
        dur = 0.0F;
        arc = false;
    }

    public void moveTo(float x, float z, float now, float ticks, Ease e) {
        value(now, tmp);
        fx = tmp[0];
        fz = tmp[1];
        tx = x;
        tz = z;
        start = now;
        dur = Math.max(0.0F, ticks);
        ease = e == null ? Ease.SMOOTH : e;
        arc = false;
    }

    /** Gira em volta de (cx, cz) por {@code deg} graus (positivo: da frente para a direita). */
    public void orbit(float cx, float cz, float deg, float now, float ticks, Ease e) {
        value(now, tmp);
        fx = tmp[0];
        fz = tmp[1];
        this.cx = cx;
        this.cz = cz;
        sweep = deg;
        float[] end = rotate(fx, fz, cx, cz, deg, new float[2]);
        tx = end[0];
        tz = end[1];
        start = now;
        dur = Math.max(0.0F, ticks);
        ease = e == null ? Ease.SMOOTH : e;
        arc = true;
    }

    public float[] value(float now, float[] out) {
        if (dur <= 0.0F || now >= start + dur) {
            out[0] = tx;
            out[1] = tz;
            return out;
        }
        if (now <= start) {
            out[0] = fx;
            out[1] = fz;
            return out;
        }
        float k = ease.apply((now - start) / dur);
        if (arc) return rotate(fx, fz, cx, cz, sweep * k, out);
        out[0] = fx + (tx - fx) * k;
        out[1] = fz + (tz - fz) * k;
        return out;
    }

    public static float[] rotate(float x, float z, float cx, float cz, float deg, float[] out) {
        double a = Math.toRadians(deg);
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        float dx = x - cx, dz = z - cz;
        out[0] = cx + dx * c - dz * s;
        out[1] = cz + dx * s + dz * c;
        return out;
    }
}
