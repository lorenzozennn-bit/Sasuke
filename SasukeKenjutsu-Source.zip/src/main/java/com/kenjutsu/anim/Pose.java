package com.kenjutsu.anim;

/**
 * Pose completa de um corpo humanoide articulado (jogador ou ator virtual).
 *
 * Esqueleto: quadril -> tronco (gira na cintura) -> cabeça e braços;
 *            quadril -> pernas. Braços têm cotovelo, pernas têm joelho.
 *
 * Ângulos em GRAUS, convenção do ModelBiped (ordem de aplicação Z, Y, X):
 *  - BODY: rotação do tronco na cintura. X positivo inclina para frente,
 *          Y positivo leva o ombro esquerdo à frente.
 *  - HEAD, R_ARM, L_ARM: relativos ao tronco. LEGS: relativos ao quadril.
 *  - Braço/perna: X negativo levanta para frente. Z positivo afasta o lado
 *    direito do corpo; Z negativo afasta o esquerdo. Y negativo leva o braço
 *    direito para dentro (gancho); Y positivo leva o esquerdo para dentro.
 *  - Cabeça: X negativo olha para cima; Y positivo olha para a direita.
 *  - R_ELBOW/L_ELBOW/R_KNEE/L_KNEE: dobra em graus (0 = esticado, positivo dobra).
 *
 * Transformação raiz (corpo inteiro, apenas visual):
 *  - ROOT_YAW   positivo gira o corpo para a esquerda.
 *  - ROOT_PITCH positivo inclina para frente, negativo para trás.
 *  - ROOT_ROLL  positivo inclina para a direita.
 *  - OFF_X/OFF_Y/OFF_F deslocamento em blocos (direita / cima / frente).
 *  - PIVOT_Y altura (blocos) do pivô de pitch/roll. 0 = pés.
 */
public final class Pose {

    public static final int HEAD = 0;
    public static final int BODY = 3;
    public static final int R_ARM = 6;
    public static final int L_ARM = 9;
    public static final int R_LEG = 12;
    public static final int L_LEG = 15;
    public static final int ROOT_YAW = 18;
    public static final int ROOT_PITCH = 19;
    public static final int ROOT_ROLL = 20;
    public static final int OFF_X = 21;
    public static final int OFF_Y = 22;
    public static final int OFF_F = 23;
    public static final int PIVOT_Y = 24;
    public static final int R_ELBOW = 25;
    public static final int L_ELBOW = 26;
    public static final int R_KNEE = 27;
    public static final int L_KNEE = 28;
    public static final int SIZE = 29;

    final float[] v = new float[SIZE];

    public Pose() {
    }

    /** Cria uma cópia editável de outra pose. */
    public static Pose from(Pose base) {
        Pose p = new Pose();
        System.arraycopy(base.v, 0, p.v, 0, SIZE);
        return p;
    }

    public Pose copy() {
        return from(this);
    }

    public void set(Pose other) {
        System.arraycopy(other.v, 0, v, 0, SIZE);
    }

    public float get(int index) {
        return v[index];
    }

    /** Soma um valor a um canal (camadas procedurais). */
    public void add(int index, float delta) {
        v[index] += delta;
    }

    private Pose set3(int i, float x, float y, float z) {
        v[i] = x;
        v[i + 1] = y;
        v[i + 2] = z;
        return this;
    }

    public Pose head(float x, float y, float z) { return set3(HEAD, x, y, z); }
    public Pose body(float x, float y, float z) { return set3(BODY, x, y, z); }
    public Pose ra(float x, float y, float z) { return set3(R_ARM, x, y, z); }
    public Pose la(float x, float y, float z) { return set3(L_ARM, x, y, z); }
    public Pose rl(float x, float y, float z) { return set3(R_LEG, x, y, z); }
    public Pose ll(float x, float y, float z) { return set3(L_LEG, x, y, z); }

    public Pose root(float yaw, float pitch, float roll) {
        v[ROOT_YAW] = yaw;
        v[ROOT_PITCH] = pitch;
        v[ROOT_ROLL] = roll;
        return this;
    }

    public Pose yaw(float yaw) {
        v[ROOT_YAW] = yaw;
        return this;
    }

    public Pose off(float right, float up, float forward) {
        v[OFF_X] = right;
        v[OFF_Y] = up;
        v[OFF_F] = forward;
        return this;
    }

    public Pose pivot(float y) {
        v[PIVOT_Y] = y;
        return this;
    }

    public Pose elbows(float right, float left) {
        v[R_ELBOW] = right;
        v[L_ELBOW] = left;
        return this;
    }

    public Pose knees(float right, float left) {
        v[R_KNEE] = right;
        v[L_KNEE] = left;
        return this;
    }

    /** Interpolação linear simples (usada entre keyframes de um mesmo clipe). */
    public static void lerp(Pose a, Pose b, float t, Pose out) {
        for (int i = 0; i < SIZE; i++) {
            out.v[i] = a.v[i] + (b.v[i] - a.v[i]) * t;
        }
    }

    /**
     * Interpolação para transições entre clipes: os ângulos raiz de "a" são
     * normalizados para o múltiplo de 360 mais próximo de "b", evitando que um
     * giro de 360° seja "desfeito" visualmente na transição.
     */
    public static void blendWrapped(Pose a, Pose b, float t, Pose out) {
        for (int i = 0; i < SIZE; i++) {
            float from = a.v[i];
            float to = b.v[i];
            if (i == ROOT_YAW || i == ROOT_PITCH || i == ROOT_ROLL) {
                from = to + wrapDegrees(from - to);
            }
            out.v[i] = from + (to - from) * t;
        }
    }

    /** Normaliza para o intervalo [-180, 180). */
    public static float wrapDegrees(float deg) {
        float d = deg % 360.0F;
        if (d >= 180.0F) d -= 360.0F;
        if (d < -180.0F) d += 360.0F;
        return d;
    }

    public boolean isFinite() {
        for (int i = 0; i < SIZE; i++) {
            if (Float.isNaN(v[i]) || Float.isInfinite(v[i])) return false;
        }
        return true;
    }
}
