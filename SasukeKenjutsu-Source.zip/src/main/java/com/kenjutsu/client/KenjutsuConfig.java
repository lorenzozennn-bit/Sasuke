package com.kenjutsu.client;

import net.neoforged.neoforge.common.ModConfigSpec;

/** config/kenjutsu-client.toml */
public final class KenjutsuConfig {

    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();

    public static final ModConfigSpec.DoubleValue FIGHT_SPEED = B
            .comment("Velocidade das animações de luta (1.0 = normal, 1.6 = rápido, 2.0 = muito rápido).")
            .defineInRange("fightSpeed", 1.6D, 0.5D, 3.0D);

    public static final ModConfigSpec.BooleanValue AUTO_THIRD_PERSON = B
            .comment("Muda para a câmera em terceira pessoa ao ativar.")
            .define("autoThirdPerson", true);

    public static final ModConfigSpec.BooleanValue HIT_STOP = B
            .comment("Micropausa nos impactos fortes e nos choques de lâmina.")
            .define("hitStop", true);

    public static final ModConfigSpec.BooleanValue SWORD_TRAIL = B
            .comment("Rastro de luz da espada nos cortes rápidos.")
            .define("swordTrail", true);

    public static final ModConfigSpec SPEC = B.build();

    private KenjutsuConfig() {
    }
}
