package com.kenjutsu.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

/** V liga/desliga, R reinicia (alteráveis em Opções > Controles). */
public final class KeyBindings {

    public static final String CATEGORY = "key.categories.kenjutsu";

    public static final KeyMapping TOGGLE = new KeyMapping("key.kenjutsu.toggle", KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, CATEGORY);
    public static final KeyMapping RESTART = new KeyMapping("key.kenjutsu.restart", KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, CATEGORY);

    private KeyBindings() {
    }

    public static void register(RegisterKeyMappingsEvent event) {
        event.register(TOGGLE);
        event.register(RESTART);
    }

    static void poll() {
        KenjutsuSession s = KenjutsuSession.get();
        while (TOGGLE.consumeClick()) s.toggle();
        while (RESTART.consumeClick()) s.restart();
    }
}
