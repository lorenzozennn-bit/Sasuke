package com.kenjutsu.client;

import com.kenjutsu.anim.Pose;
import com.kenjutsu.combat.CombatStateMachine;
import com.kenjutsu.combat.VirtualActor;
import com.kenjutsu.rig.FlyingSword;
import com.kenjutsu.rig.Mat4;
import com.kenjutsu.rig.Skeleton;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.PlayerModelPart;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.IdentityHashMap;
import java.util.Map;

/**
 * Desenha a cena inteira (personagem, adversário, espadas, rastro) a partir do
 * evento de renderização do jogador local. Toda a geometria vem do esqueleto
 * em Java puro (com.kenjutsu.rig), o mesmo usado na pré-visualização.
 */
final class SceneRenderer {

    private static final ResourceLocation STEVE =
            ResourceLocation.withDefaultNamespace("textures/entity/player/wide/steve.png");
    private static final ResourceLocation ARMOR_1 =
            ResourceLocation.withDefaultNamespace("textures/models/armor/netherite_layer_1.png");
    private static final ResourceLocation ARMOR_2 =
            ResourceLocation.withDefaultNamespace("textures/models/armor/netherite_layer_2.png");

    private final ItemStack sword = new ItemStack(Items.NETHERITE_SWORD);
    private final Pose pose = new Pose();
    private final Skeleton.Rig rig = new Skeleton.Rig();
    private final double[] adv = new double[2];
    private final double[] rel = new double[3];
    private final Map<VirtualActor, Mat4> disarmStart = new IdentityHashMap<VirtualActor, Mat4>();
    private final SwordTrail trail = new SwordTrail();

    void render(PoseStack ps, MultiBufferSource buf, int playerLight, float partial, AbstractClientPlayer player) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        KenjutsuSession session = KenjutsuSession.get();
        CombatStateMachine m = session.machine();
        float now = session.now(partial);

        // ------------------------------------------------ personagem
        session.playerAdvanceOffset(partial, adv);
        double baseX = Mth.lerp(partial, player.xo, player.getX());
        double baseY = Mth.lerp(partial, player.yo, player.getY());
        double baseZ = Mth.lerp(partial, player.zo, player.getZ());
        int light = lightAt(mc, baseX + adv[0], baseY, baseZ + adv[1]);
        boolean slim = player.getSkin().model() == PlayerSkin.Model.SLIM;
        m.player().pose(now, pose);
        Mat4 body = new Mat4().translate((float) adv[0], 0, (float) adv[1])
                .mul(Skeleton.bodyMatrixBlocks(session.playerRenderYaw(partial), pose));
        boolean[] wear = {
                player.isModelPartShown(PlayerModelPart.HAT),
                player.isModelPartShown(PlayerModelPart.JACKET),
                player.isModelPartShown(PlayerModelPart.RIGHT_SLEEVE),
                player.isModelPartShown(PlayerModelPart.LEFT_SLEEVE),
                player.isModelPartShown(PlayerModelPart.RIGHT_PANTS_LEG),
                player.isModelPartShown(PlayerModelPart.LEFT_PANTS_LEG)};
        drawBody(ps, buf, body, slim, player.getSkin().texture(), light, OverlayTexture.NO_OVERLAY, wear);
        drawSwordInHand(ps, buf, body, light, mc);
        if (KenjutsuConfig.SWORD_TRAIL.get()) {
            trail.draw(ps, buf, session, now, partial);
        }

        // ------------------------------------------------ adversário(s)
        for (VirtualActor a : m.actors()) {
            session.actorRelativePos(a, partial, rel);
            int al = lightAt(mc, baseX + rel[0], baseY, baseZ + rel[2]);
            float hurt = a.hurtAmount(now);
            int overlay = OverlayTexture.pack(OverlayTexture.u(0.0F), OverlayTexture.v(hurt > 0.0F));
            a.pose(now, pose);
            float yaw = session.actorYaw(a);
            Mat4 abody = new Mat4().translate((float) rel[0], (float) rel[1], (float) rel[2])
                    .mul(Skeleton.bodyMatrixBlocks(yaw, pose));
            drawBody(ps, buf, abody, false, STEVE, al, overlay, null);
            if (!a.isDisarmed(now)) {
                disarmStart.remove(a);
                drawSwordInHand(ps, buf, abody, al, mc);
            } else {
                drawFlyingSword(ps, buf, a, now, yaw, rel, al, mc);
            }
        }
    }

    private static int lightAt(Minecraft mc, double x, double y, double z) {
        return LevelRenderer.getLightColor(mc.level, BlockPos.containing(x, y + 1.0, z));
    }

    /** Pele, camadas externas e as duas camadas da armadura de netherite. */
    private void drawBody(PoseStack ps, MultiBufferSource buf, Mat4 bodyBlocks, boolean slim, ResourceLocation skin,
                          int light, int overlay, boolean[] wear) {
        Skeleton.compute(pose, slim, rig);
        Mat4 px = bodyBlocks.copy().scale(0.0625F, 0.0625F, 0.0625F);
        PoseStack.Pose last = ps.last();

        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(skin));
        emitLayer(vc, last, px, slim, Skeleton.SKIN, light, overlay, null);
        emitLayer(vc, last, px, slim, Skeleton.SKIN_OUTER, light, overlay, wear);

        VertexConsumer a1 = buf.getBuffer(RenderType.armorCutoutNoCull(ARMOR_1));
        emitLayer(a1, last, px, slim, Skeleton.ARMOR_OUTER, light, overlay, null);
        VertexConsumer a2 = buf.getBuffer(RenderType.armorCutoutNoCull(ARMOR_2));
        emitLayer(a2, last, px, slim, Skeleton.ARMOR_INNER, light, overlay, null);
    }

    private static final int[] WEAR_OF_BONE = {1, 0, 2, 2, 3, 3, 4, 4, 5, 5};

    private void emitLayer(VertexConsumer vc, PoseStack.Pose last, Mat4 px, boolean slim, int layer,
                           int light, int overlay, boolean[] wear) {
        for (int b = 0; b < Skeleton.BONES; b++) {
            if (wear != null && !wear[WEAR_OF_BONE[b]]) continue;
            Skeleton.emit(px, rig, slim, layer, b, (x, y, z, u, v, nx, ny, nz) ->
                    vc.addVertex(last, x, y, z)
                            .setColor(0xFFFFFFFF)
                            .setUv(u, v)
                            .setOverlay(overlay)
                            .setLight(light)
                            .setNormal(last, nx, ny, nz));
        }
    }

    /** Espada na mão direita: mesmo quadro de mão que o ItemInHandLayer usa. */
    private void drawSwordInHand(PoseStack ps, MultiBufferSource buf, Mat4 bodyBlocks, int light, Minecraft mc) {
        Mat4 hand = bodyBlocks.copy().mul(Skeleton.rightHandItemFrame(rig));
        ps.pushPose();
        mul(ps, hand);
        mc.getItemRenderer().renderStatic(sword, ItemDisplayContext.THIRD_PERSON_RIGHT_HAND, light,
                OverlayTexture.NO_OVERLAY, ps, buf, mc.level, 0);
        ps.popPose();
    }

    /** Espada arrancada: voa girando e fica cravada no chão. */
    private void drawFlyingSword(PoseStack ps, MultiBufferSource buf, VirtualActor a, float now, float yaw,
                                 double[] relPos, int light, Minecraft mc) {
        Mat4 start = disarmStart.get(a);
        if (start == null) {
            float t0 = now - a.disarmedFor(now);
            Pose p0 = new Pose();
            a.pose(t0, p0);
            Skeleton.Rig r0 = new Skeleton.Rig();
            Skeleton.compute(p0, false, r0);
            start = Skeleton.bodyMatrixBlocks(yaw, p0).mul(Skeleton.swordModelSpace(r0));
            disarmStart.put(a, start);
        }
        double w = Math.toRadians(KenjutsuSession.get().arenaYaw());
        float sideX = (float) -Math.cos(w), sideZ = (float) -Math.sin(w);
        Mat4 model = FlyingSword.matrix(start, sideX, sideZ, a.disarmedFor(now));
        Mat4 full = new Mat4().translate((float) relPos[0], (float) relPos[1], (float) relPos[2])
                .mul(model).translate(0.5F, 0.5F, 0.5F);
        ps.pushPose();
        mul(ps, full);
        mc.getItemRenderer().renderStatic(sword, ItemDisplayContext.NONE, light, OverlayTexture.NO_OVERLAY,
                ps, buf, mc.level, 0);
        ps.popPose();
    }

    static void mul(PoseStack ps, Mat4 m) {
        Matrix4f j = new Matrix4f().set(m.m);
        PoseStack.Pose last = ps.last();
        last.pose().mul(j);
        last.normal().mul(new Matrix3f(j));
    }
}
