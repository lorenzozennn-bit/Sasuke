package com.kenjutsu.client;

import com.kenjutsu.anim.Pose;
import com.kenjutsu.combat.CombatStateMachine;
import com.kenjutsu.rig.Mat4;
import com.kenjutsu.rig.Skeleton;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;

import java.util.Random;

/**
 * Chidori na lâmina: raios azuis tremulando ao longo da espada, arcos curtos
 * saltando dela e, nas arrancadas, um rastro de raios no caminho percorrido.
 * Os raios mudam de forma ~8 vezes por segundo (semente pelo tempo da cena),
 * então são idênticos em qualquer FPS e não dependem de estado.
 */
final class LightningFx {

    private static final float CORE_W = 0.018F;
    private static final float GLOW_W = 0.06F;

    private final Pose pose = new Pose();
    private final Skeleton.Rig rig = new Skeleton.Rig();
    private final float[] g = new float[3];
    private final float[] t = new float[3];
    private final Random rnd = new Random();
    private final double[] off = new double[2];

    void draw(PoseStack ps, MultiBufferSource buf, KenjutsuSession session, float now) {
        CombatStateMachine m = session.machine();
        float c = m.playerCharge(now);
        if (c <= 0.0F) return;
        VertexConsumer vc = buf.getBuffer(RenderType.lightning());
        PoseStack.Pose last = ps.last();
        long frame = (long) Math.floor(now * 2.5F);

        // ---- espada
        m.playerPose(now, pose);
        Skeleton.compute(pose, false, rig);
        Mat4 s = Skeleton.bodyMatrixBlocks(session.playerYawAt(now), pose).mul(Skeleton.swordModelSpace(rig));
        s.transformPoint(Skeleton.SWORD_GUARD[0], Skeleton.SWORD_GUARD[1], 0.5F, g);
        s.transformPoint(Skeleton.SWORD_TIP[0], Skeleton.SWORD_TIP[1], 0.5F, t);
        for (int b = 0; b < 3; b++) {
            rnd.setSeed(frame * 31L + b * 7919L);
            float[] tip = {t[0] + (t[0] - g[0]) * 0.15F, t[1] + (t[1] - g[1]) * 0.15F, t[2] + (t[2] - g[2]) * 0.15F};
            bolt(vc, last, g, tip, 7, 0.07F, c);
        }
        // arcos curtos saltando da lâmina
        rnd.setSeed(frame * 131L + 17L);
        int arcs = 2 + (int) (c * 3);
        for (int i = 0; i < arcs; i++) {
            float k = rnd.nextFloat();
            float[] a = {g[0] + (t[0] - g[0]) * k, g[1] + (t[1] - g[1]) * k, g[2] + (t[2] - g[2]) * k};
            float[] e = {a[0] + (rnd.nextFloat() - 0.5F) * 0.7F, a[1] + (rnd.nextFloat() - 0.3F) * 0.6F,
                    a[2] + (rnd.nextFloat() - 0.5F) * 0.7F};
            bolt(vc, last, a, e, 4, 0.06F, c * 0.8F);
        }

        // ---- rastro de raios nas arrancadas
        float speed = m.playerSpeed(now);
        if (speed > 0.15F) {
            float k = Math.min(1.0F, (speed - 0.15F) / 0.4F) * c;
            for (int strand = 0; strand < 3; strand++) {
                rnd.setSeed(frame * 977L + strand * 104729L);
                int n = 9;
                float[][] pts = new float[n][3];
                for (int i = 0; i < n; i++) {
                    session.playerOffset(now - i * 0.9F, now, off);
                    pts[i][0] = (float) off[0] + (rnd.nextFloat() - 0.5F) * 0.5F;
                    pts[i][1] = 0.35F + strand * 0.35F + (rnd.nextFloat() - 0.5F) * 0.3F;
                    pts[i][2] = (float) off[1] + (rnd.nextFloat() - 0.5F) * 0.5F;
                }
                for (int i = 0; i < n - 1; i++) {
                    float fade = k * (1.0F - i / (float) (n - 1));
                    if (fade > 0.03F) bolt(vc, last, pts[i], pts[i + 1], 3, 0.08F, fade);
                }
            }
        }
    }

    /** Raio quebrado entre a e b: núcleo branco-azulado e brilho azul. */
    private void bolt(VertexConsumer vc, PoseStack.Pose last, float[] a, float[] b, int segs, float amp, float alpha) {
        float[] prev = a.clone();
        for (int i = 1; i <= segs; i++) {
            float k = i / (float) segs;
            float[] p = {a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k};
            if (i < segs) {
                p[0] += (rnd.nextFloat() - 0.5F) * 2 * amp;
                p[1] += (rnd.nextFloat() - 0.5F) * 2 * amp;
                p[2] += (rnd.nextFloat() - 0.5F) * 2 * amp;
            }
            ribbon(vc, last, prev, p, GLOW_W, 0.25F, 0.45F, 1.0F, alpha * 0.45F);
            ribbon(vc, last, prev, p, CORE_W, 0.85F, 0.93F, 1.0F, alpha);
            prev = p;
        }
    }

    /** Dois quads cruzados (visíveis de qualquer ângulo), nas duas faces. */
    private static void ribbon(VertexConsumer vc, PoseStack.Pose last, float[] p, float[] q, float w,
                               float r, float gr, float bl, float al) {
        float dx = q[0] - p[0], dy = q[1] - p[1], dz = q[2] - p[2];
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-4F) return;
        dx /= len; dy /= len; dz /= len;
        // a = d x up (ou d x X quando d é vertical)
        float ax = -dz, ay = 0, az = dx;
        float al2 = (float) Math.sqrt(ax * ax + az * az);
        if (al2 < 1e-3F) { ax = 0; ay = dz; az = -dy; al2 = (float) Math.sqrt(ay * ay + az * az); }
        ax /= al2; ay /= al2; az /= al2;
        float bx = dy * az - dz * ay, by = dz * ax - dx * az, bz = dx * ay - dy * ax;
        quad(vc, last, p, q, ax * w, ay * w, az * w, r, gr, bl, al);
        quad(vc, last, p, q, bx * w, by * w, bz * w, r, gr, bl, al);
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose last, float[] p, float[] q, float ox, float oy, float oz,
                             float r, float g, float b, float a) {
        vc.addVertex(last, p[0] - ox, p[1] - oy, p[2] - oz).setColor(r, g, b, a);
        vc.addVertex(last, p[0] + ox, p[1] + oy, p[2] + oz).setColor(r, g, b, a);
        vc.addVertex(last, q[0] + ox, q[1] + oy, q[2] + oz).setColor(r, g, b, a);
        vc.addVertex(last, q[0] - ox, q[1] - oy, q[2] - oz).setColor(r, g, b, a);
        vc.addVertex(last, q[0] - ox, q[1] - oy, q[2] - oz).setColor(r, g, b, a);
        vc.addVertex(last, q[0] + ox, q[1] + oy, q[2] + oz).setColor(r, g, b, a);
        vc.addVertex(last, p[0] + ox, p[1] + oy, p[2] + oz).setColor(r, g, b, a);
        vc.addVertex(last, p[0] - ox, p[1] - oy, p[2] - oz).setColor(r, g, b, a);
    }
}
