package com.kenjutsu.client;

import com.kenjutsu.choreo.ImpactType;
import com.kenjutsu.combat.SceneFx;
import com.kenjutsu.combat.VirtualActor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;

/**
 * Efeitos locais (só no cliente): sons, faíscas e micropausa. Nada é enviado
 * ao servidor e nenhuma entidade é criada.
 */
final class ClientFx implements SceneFx {

    private final KenjutsuSession session;
    private final double[] pos = new double[3];
    private final double[] adv = new double[2];

    ClientFx(KenjutsuSession session) {
        this.session = session;
    }

    @Override
    public void onImpact(VirtualActor actor, ImpactType type) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        LocalPlayer player = mc.player;
        if (level == null || player == null) return;
        RandomSource rnd = level.random;

        session.actorWorldPos(actor, session.now(0.0F), pos);
        double px = player.getX(), pz = player.getZ();
        // ponto de contato: entre os dois, na altura do peito
        double hx = pos[0] + (px - pos[0]) * 0.35, hz = pos[2] + (pz - pos[2]) * 0.35;
        double hy = player.getY() + 1.25;
        float pitch = 0.9F + rnd.nextFloat() * 0.2F;

        switch (type) {
            case SLASH:
                play(level, hx, hy, hz, SoundEvents.PLAYER_ATTACK_SWEEP, 0.9F, 1.1F * pitch);
                play(level, hx, hy, hz, SoundEvents.PLAYER_ATTACK_STRONG, 0.6F, 1.25F);
                burst(level, ParticleTypes.CRIT, hx, hy, hz, 8, 0.5);
                burst(level, ParticleTypes.ELECTRIC_SPARK, hx, hy, hz, 6, 0.35);
                break;
            case HEAVY:
                play(level, hx, hy, hz, SoundEvents.PLAYER_ATTACK_CRIT, 1.0F, 0.85F * pitch);
                play(level, hx, hy, hz, SoundEvents.PLAYER_ATTACK_SWEEP, 1.0F, 0.75F);
                burst(level, ParticleTypes.CRIT, hx, hy, hz, 16, 0.7);
                burst(level, ParticleTypes.ELECTRIC_SPARK, hx, hy, hz, 12, 0.5);
                level.addParticle(ParticleTypes.SWEEP_ATTACK, hx, hy, hz, 0, 0, 0);
                session.hitStop(3.0F);
                break;
            case CLASH:
                play(level, hx, hy + 0.2, hz, SoundEvents.ANVIL_LAND, 0.35F, 1.9F + rnd.nextFloat() * 0.1F);
                burst(level, ParticleTypes.FLAME, hx, hy + 0.2, hz, 18, 0.45); // faíscas vermelhas do choque
                burst(level, ParticleTypes.LAVA, hx, hy + 0.2, hz, 3, 0.2);
                play(level, hx, hy + 0.2, hz, SoundEvents.PLAYER_ATTACK_SWEEP, 0.7F, 1.4F);
                burst(level, ParticleTypes.ELECTRIC_SPARK, hx, hy + 0.2, hz, 22, 0.6);
                burst(level, ParticleTypes.CRIT, hx, hy + 0.2, hz, 10, 0.5);
                session.hitStop(2.5F);
                break;
            case DISARM:
                play(level, hx, hy, hz, SoundEvents.ANVIL_LAND, 0.4F, 1.6F);
                play(level, hx, hy, hz, SoundEvents.PLAYER_ATTACK_KNOCKBACK, 0.8F, 1.2F);
                burst(level, ParticleTypes.ELECTRIC_SPARK, hx, hy, hz, 16, 0.5);
                session.hitStop(2.0F);
                break;
            case KICK:
                play(level, hx, hy, hz, SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1.0F, 0.9F);
                play(level, hx, hy, hz, SoundEvents.PLAYER_ATTACK_STRONG, 0.8F, 0.8F);
                burst(level, ParticleTypes.CRIT, hx, hy - 0.2, hz, 10, 0.5);
                session.hitStop(2.0F);
                break;
            case SHOCK:
                play(level, hx, hy, hz, SoundEvents.LIGHTNING_BOLT_IMPACT, 0.9F, 1.3F);
                play(level, hx, hy, hz, SoundEvents.PLAYER_ATTACK_CRIT, 1.0F, 0.8F);
                burst(level, ParticleTypes.ELECTRIC_SPARK, hx, hy, hz, 40, 0.9);
                burst(level, ParticleTypes.CRIT, hx, hy, hz, 14, 0.7);
                level.addParticle(ParticleTypes.SWEEP_ATTACK, hx, hy, hz, 0, 0, 0);
                session.hitStop(3.5F);
                break;
            case CHARGE: {
                double cx = px, cy = player.getY() + 0.9, cz = pz;
                play(level, cx, cy, cz, SoundEvents.LIGHTNING_BOLT_IMPACT, 0.45F, 2.0F);
                burst(level, ParticleTypes.ELECTRIC_SPARK, cx, cy, cz, 16, 0.4);
                break;
            }
            case PLAYER_HIT: {
                // a lâmina dele acerta você: faíscas vermelhas no seu ombro e você recua
                double sx = px + (hx - px) * 0.25, sy = player.getY() + 1.35, sz = pz + (hz - pz) * 0.25;
                play(level, sx, sy, sz, SoundEvents.PLAYER_HURT, 0.9F, 1.0F);
                play(level, sx, sy, sz, SoundEvents.PLAYER_ATTACK_STRONG, 0.7F, 0.9F);
                burst(level, ParticleTypes.FLAME, sx, sy, sz, 14, 0.4);
                burst(level, ParticleTypes.CRIT, sx, sy, sz, 10, 0.5);
                session.hitStop(2.5F);
                break;
            }
            case MISS:
                play(level, hx, hy, hz, SoundEvents.PLAYER_ATTACK_NODAMAGE, 0.8F, 1.3F);
                break;
            case NONE:
            default:
                break;
        }
    }

    /**
     * Poeira do cenário: nas arrancadas, derrapadas e quedas, levanta partículas
     * do bloco real em que cada um está pisando (areia, neve, terra, pedra...).
     */
    void tickGround(float now) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        RandomSource r = mc.level.random;
        float ps = session.machine().playerSpeed(now);
        if (ps > 0.3F && mc.player.onGround()) {
            dust(mc, mc.player.getX(), mc.player.getY(), mc.player.getZ(), Math.min(6, (int) (ps * 6)), r);
        }
        for (com.kenjutsu.combat.VirtualActor a : session.machine().actors()) {
            float[] p0 = a.position(now, new float[2]), p1 = a.position(now - 1.0F, new float[2]);
            float as = (float) Math.hypot(p0[0] - p1[0], p0[1] - p1[1]);
            if (as > 0.3F) {
                session.actorWorldPos(a, now, pos);
                dust(mc, pos[0], pos[1], pos[2], Math.min(6, (int) (as * 6)), r);
            }
        }
    }

    private static void dust(Minecraft mc, double x, double y, double z, int n, RandomSource r) {
        net.minecraft.core.BlockPos below = net.minecraft.core.BlockPos.containing(x, y - 0.2, z);
        net.minecraft.world.level.block.state.BlockState state = mc.level.getBlockState(below);
        if (state.isAir()) return;
        net.minecraft.core.particles.BlockParticleOption opt =
                new net.minecraft.core.particles.BlockParticleOption(ParticleTypes.BLOCK, state);
        for (int i = 0; i < n; i++) {
            mc.level.addParticle(opt, x + (r.nextDouble() - 0.5) * 0.6, y + 0.1, z + (r.nextDouble() - 0.5) * 0.6,
                    (r.nextDouble() - 0.5) * 0.3, 0.15 + r.nextDouble() * 0.15, (r.nextDouble() - 0.5) * 0.3);
        }
    }

    /** Faíscas elétricas saindo do personagem enquanto o Chidori está aceso (1x por tick). */
    void tickCharge(float now) {
        float c = session.machine().playerCharge(now);
        if (c <= 0.0F) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        RandomSource r = mc.level.random;
        int n = 1 + (int) (c * 2);
        for (int i = 0; i < n; i++) {
            mc.level.addParticle(ParticleTypes.ELECTRIC_SPARK,
                    mc.player.getX() + (r.nextDouble() - 0.5) * 1.2,
                    mc.player.getY() + 0.4 + r.nextDouble() * 1.0,
                    mc.player.getZ() + (r.nextDouble() - 0.5) * 1.2,
                    (r.nextDouble() - 0.5) * 0.3, r.nextDouble() * 0.2, (r.nextDouble() - 0.5) * 0.3);
        }
    }

    @Override
    public void onActorDefeated(VirtualActor actor) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        session.actorWorldPos(actor, session.now(0.0F), pos);
        play(mc.level, pos[0], pos[1], pos[2], SoundEvents.PLAYER_BIG_FALL, 0.9F, 0.8F);
    }

    @Override
    public void onVictory() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        LocalPlayer p = mc.player;
        play(mc.level, p.getX(), p.getY() + 1, p.getZ(), SoundEvents.PLAYER_ATTACK_SWEEP, 0.5F, 0.6F);
    }

    private static void play(ClientLevel level, double x, double y, double z, SoundEvent sound, float vol, float pitch) {
        level.playLocalSound(x, y, z, sound, SoundSource.PLAYERS, vol, pitch, false);
    }

    private static void burst(ClientLevel level, ParticleOptions type, double x, double y, double z, int n, double spread) {
        RandomSource r = level.random;
        for (int i = 0; i < n; i++) {
            level.addParticle(type, x + (r.nextDouble() - 0.5) * 0.3, y + (r.nextDouble() - 0.5) * 0.3,
                    z + (r.nextDouble() - 0.5) * 0.3,
                    (r.nextDouble() - 0.5) * spread, r.nextDouble() * spread * 0.6, (r.nextDouble() - 0.5) * spread);
        }
    }
}
