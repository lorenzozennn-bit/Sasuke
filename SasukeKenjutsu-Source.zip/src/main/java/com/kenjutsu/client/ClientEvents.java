package com.kenjutsu.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.AbstractClientPlayer;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.RenderPlayerEvent;
import net.neoforged.neoforge.event.level.LevelEvent;

/** Eventos do cliente: ticks, teclas, clique e desenho da cena. */
public final class ClientEvents {

    private final SceneRenderer renderer = new SceneRenderer();

    @SubscribeEvent
    public void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.level != null) {
            KeyBindings.poll();
        }
        KenjutsuSession.get().clientTick(mc);
    }

    /** Clique esquerdo (ataque). Não é cancelado: mineração e ataques vanilla continuam. */
    @SubscribeEvent
    public void onInteraction(InputEvent.InteractionKeyMappingTriggered event) {
        if (event.isAttack()) {
            KenjutsuSession.get().onLeftClick();
        }
    }

    /**
     * Substitui apenas o DESENHO do jogador local enquanto ativo. Posição,
     * hitbox e física continuam vanilla. HIGHEST: cancela antes de outros mods.
     */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onRenderPlayer(RenderPlayerEvent.Pre event) {
        KenjutsuSession session = KenjutsuSession.get();
        if (!session.isEnabled()) return;
        Minecraft mc = Minecraft.getInstance();
        if (event.getEntity() != mc.player) return;
        // Prévia do inventário: mantém o desenho vanilla.
        if (mc.screen instanceof InventoryScreen || mc.screen instanceof CreativeModeInventoryScreen) return;
        event.setCanceled(true);
        renderer.render(event.getPoseStack(), event.getMultiBufferSource(), event.getPackedLight(),
                event.getPartialTick(), (AbstractClientPlayer) event.getEntity());
    }

    @SubscribeEvent
    public void onLevelUnload(LevelEvent.Unload event) {
        if (event.getLevel().isClientSide()) {
            KenjutsuSession.get().deactivate(true);
        }
    }
}
