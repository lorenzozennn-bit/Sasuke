package com.kenjutsu.client;

import com.kenjutsu.choreo.Terrain;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Leitura do cenário: uma grade de 41×41 colunas em volta do jogador com a
 * altura do chão em que dá para ficar de pé e o espaço livre acima dele.
 * Feita uma vez quando a luta começa (alguns milhares de consultas de bloco).
 */
final class WorldTerrain implements Terrain {

    private static final int R = 20;
    private static final int N = 2 * R + 1;
    private static final int UP = 3, DOWN = 8, MAX_CLEAR = 8;

    private final float[] height = new float[N * N];
    private final float[] clear = new float[N * N];

    private WorldTerrain() {
    }

    static WorldTerrain scan(ClientLevel level, double ox, double oy, double oz) {
        WorldTerrain t = new WorldTerrain();
        int bx = Mth.floor(ox), bz = Mth.floor(oz), by = Mth.floor(oy);
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                int x = bx + i - R, z = bz + j - R;
                float h = Float.NaN, c = 0.0F;
                for (int y = by + UP; y >= by - DOWN; y--) {
                    if (solid(level, x, y, z) && !solid(level, x, y + 1, z) && !solid(level, x, y + 2, z)) {
                        h = (float) (y + top(level, x, y, z) - oy);
                        int free = 0;
                        while (free < MAX_CLEAR && !solid(level, x, y + 1 + free, z)) free++;
                        c = free;
                        break;
                    }
                }
                t.height[i * N + j] = h;
                t.clear[i * N + j] = c;
            }
        }
        return t;
    }

    private static boolean solid(ClientLevel level, int x, int y, int z) {
        BlockPos pos = BlockPos.containing(x, y, z);
        BlockState s = level.getBlockState(pos);
        return !s.getCollisionShape(level, pos).isEmpty();
    }

    private static double top(ClientLevel level, int x, int y, int z) {
        BlockPos pos = BlockPos.containing(x, y, z);
        VoxelShape shape = level.getBlockState(pos).getCollisionShape(level, pos);
        return shape.max(Direction.Axis.Y);
    }

    private int index(float dx, float dz) {
        int i = Math.round(dx) + R, j = Math.round(dz) + R;
        if (i < 0 || j < 0 || i >= N || j >= N) return -1;
        return i * N + j;
    }

    @Override
    public float height(float dx, float dz) {
        int k = index(dx, dz);
        return k < 0 ? 0.0F : height[k];
    }

    @Override
    public float clearance(float dx, float dz) {
        int k = index(dx, dz);
        return k < 0 ? MAX_CLEAR : clear[k];
    }
}
