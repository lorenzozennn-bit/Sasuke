package com.kenjutsu.client;

import com.kenjutsu.choreo.ChoreographyLibrary;
import com.kenjutsu.combat.CombatState;
import com.kenjutsu.combat.CombatStateMachine;
import com.kenjutsu.combat.VirtualActor;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

import java.util.Random;

/**
 * Sessão de kenjutsu do jogador local: liga/desliga, relógio da cena (com
 * velocidade e micropausa), arena e ponte entre a lógica e o Minecraft.
 */
public final class KenjutsuSession {

    private static final KenjutsuSession INSTANCE = new KenjutsuSession();

    private final CombatStateMachine machine = new CombatStateMachine();
    private final ClientFx fx = new ClientFx(this);
    private final Random random = new Random();

    private boolean enabled;
    private float clock;
    private float speed = 1.6F;
    private float hitStop;
    private float arenaYaw;
    private CameraType savedCamera;
    private boolean savedNoCulling;
    private ClientLevel boundLevel;
    private int lastVariant = -1;

    private KenjutsuSession() {
        machine.setFx(fx);
    }

    public static KenjutsuSession get() {
        return INSTANCE;
    }

    // ------------------------------------------------------------ comandos

    public void toggle() {
        if (enabled) deactivate(false);
        else activate();
    }

    private void activate() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        enabled = true;
        boundLevel = mc.level;
        savedCamera = null;
        if (KenjutsuConfig.AUTO_THIRD_PERSON.get() && mc.options.getCameraType().isFirstPerson()) {
            savedCamera = mc.options.getCameraType();
            mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
        }
        // O personagem é desenhado na posição visual (que avança); não deixa o
        // jogo descartá-lo quando a posição real sai da tela.
        savedNoCulling = mc.player.noCulling;
        mc.player.noCulling = true;
        rebuild();
        status("§5Kenjutsu ATIVADO §7(" + comboName() + ") §f- clique esquerdo para lutar");
    }

    public void deactivate(boolean silent) {
        if (!enabled) return;
        enabled = false;
        machine.stop();
        hitStop = 0;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.noCulling = savedNoCulling;
        if (savedCamera != null && mc.options.getCameraType() == CameraType.THIRD_PERSON_BACK) {
            mc.options.setCameraType(savedCamera);
        }
        savedCamera = null;
        boundLevel = null;
        if (!silent) status("§7Kenjutsu desativado");
    }

    public void restart() {
        if (!enabled) {
            status("§7Ative o Kenjutsu primeiro (tecla " + KeyBindings.TOGGLE.getTranslatedKeyMessage().getString() + ")");
            return;
        }
        rebuild();
        status("§dLuta reiniciada §7(" + comboName() + ")");
    }

    private void rebuild() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        speed = KenjutsuConfig.FIGHT_SPEED.get().floatValue();
        arenaYaw = mc.player.getYRot();
        hitStop = 0;
        lastVariant = ChoreographyLibrary.pickIndex(random, lastVariant);
        machine.stop();
        machine.start(ChoreographyLibrary.variants().get(lastVariant), clock);
    }

    /** Clique esquerdo em jogo. Nunca cancela a ação vanilla. */
    void onLeftClick() {
        if (enabled) machine.onClick(clock);
    }

    void clientTick(Minecraft mc) {
        if (!enabled) return;
        if (mc.level == null || mc.player == null || mc.level != boundLevel) {
            deactivate(true);
            return;
        }
        if (mc.isPaused()) return;
        CombatState before = machine.state();
        float step = speed;
        if (hitStop > 0) {
            step *= 0.12F;
            hitStop -= 1.0F;
        }
        clock += step;
        machine.tick(clock);
        if (before != CombatState.VICTORY && machine.state() == CombatState.VICTORY) {
            status("§5Vitória. §7Pressione " + KeyBindings.RESTART.getTranslatedKeyMessage().getString()
                    + " para lutar de novo");
        }
    }

    /** Micropausa (em ticks do jogo) nos impactos fortes. */
    void hitStop(float ticks) {
        if (KenjutsuConfig.HIT_STOP.get()) hitStop = Math.max(hitStop, ticks);
    }

    private String comboName() {
        return machine.choreography() == null ? "" : machine.choreography().name;
    }

    void status(String msg) {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p != null) p.displayClientMessage(Component.literal(msg), true);
    }

    // ------------------------------------------------------------ leitura

    public boolean isEnabled() {
        return enabled && machine.isActive();
    }

    public CombatStateMachine machine() {
        return machine;
    }

    /** Tempo da cena. Na micropausa o tempo quase para (inclusive entre ticks). */
    public float now(float partialTicks) {
        float rate = hitStop > 0 ? speed * 0.12F : speed;
        return clock + partialTicks * rate;
    }

    public float arenaYaw() {
        return arenaYaw;
    }

    public float playerRenderYaw(float partialTicks) {
        return arenaYaw + machine.player().facing(now(partialTicks));
    }

    /** Deslocamento visual do personagem (dx, dz) causado pela corrida/avanço. */
    public void playerAdvanceOffset(float partialTicks, double[] out) {
        double w = Math.toRadians(arenaYaw);
        double d = machine.playerAdvance(now(partialTicks));
        out[0] = -Math.sin(w) * d;
        out[1] = Math.cos(w) * d;
    }

    /** Usado pelo mixin da câmera: deslocamento a aplicar, ou null. */
    public double[] cameraOffset(float partialTicks) {
        if (!isEnabled()) return null;
        double[] o = new double[2];
        playerAdvanceOffset(partialTicks, o);
        return (o[0] == 0 && o[1] == 0) ? null : o;
    }

    /** Posição do ator (pés) RELATIVA à posição interpolada real do jogador. */
    public void actorRelativePos(VirtualActor actor, float partialTicks, double[] out) {
        double w = Math.toRadians(arenaYaw + actor.angle);
        double r = actor.radius(now(partialTicks));
        out[0] = -Math.sin(w) * r;
        out[1] = 0;
        out[2] = Math.cos(w) * r;
    }

    public float actorYaw(VirtualActor actor) {
        return arenaYaw + actor.angle + 180.0F;
    }

    /** Posição de mundo do ator (para sons/partículas/luz). */
    public void actorWorldPos(VirtualActor actor, float partialTicks, double[] out) {
        LocalPlayer p = Minecraft.getInstance().player;
        actorRelativePos(actor, partialTicks, out);
        out[0] += Mth.lerp(partialTicks, p.xo, p.getX());
        out[1] += Mth.lerp(partialTicks, p.yo, p.getY());
        out[2] += Mth.lerp(partialTicks, p.zo, p.getZ());
    }
}
