package com.kenjutsu.client;

import com.kenjutsu.choreo.ChoreographyLibrary;
import com.kenjutsu.combat.CombatState;
import com.kenjutsu.combat.CombatStateMachine;
import com.kenjutsu.combat.VirtualActor;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.Random;

/**
 * Sessão de kenjutsu do jogador local: liga/desliga, relógio da cena, arena e
 * ponte entre a lógica e o Minecraft.
 *
 * A arena é ancorada no mundo onde a luta começa (posição e direção do
 * jogador). O jogador REAL se move pelo cenário seguindo a coreografia (com
 * colisão e gravidade normais) e, quando a luta acaba, fica onde ela terminou.
 * O adversário é só visual e acompanha o relevo do terreno.
 */
public final class KenjutsuSession {

    private static final KenjutsuSession INSTANCE = new KenjutsuSession();
    /** Maior correção de posição por tick (blocos), para nunca "teleportar". */
    private static final double MAX_STEP = 2.5;

    private final CombatStateMachine machine = new CombatStateMachine();
    private final ClientFx fx = new ClientFx(this);
    private final Random random = new Random();

    private boolean enabled;
    private float clock;
    private float speed = 1.6F;
    private float hitStop;
    private float arenaYaw;
    private double originX, originY, originZ;
    private CameraType savedCamera;
    private boolean savedNoCulling;
    private ClientLevel boundLevel;
    private int lastVariant = -1;
    private boolean released;
    private double victoryX, victoryZ;

    private final float[] fa = new float[2], fb = new float[2];

    private KenjutsuSession() {
        machine.setFx(fx);
    }

    public static KenjutsuSession get() {
        return INSTANCE;
    }

    // ------------------------------------------------------------ comandos

    public void toggle() {
        if (enabled) deactivate(false);
        else activate();
    }

    private void activate() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        enabled = true;
        boundLevel = mc.level;
        savedCamera = null;
        if (KenjutsuConfig.AUTO_THIRD_PERSON.get() && mc.options.getCameraType().isFirstPerson()) {
            savedCamera = mc.options.getCameraType();
            mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
        }
        savedNoCulling = mc.player.noCulling;
        mc.player.noCulling = true; // o adversário é desenhado junto com o jogador
        rebuild();
        status("§5Kenjutsu ATIVADO §7(" + comboName() + ") §f- clique esquerdo para lutar");
    }

    public void deactivate(boolean silent) {
        if (!enabled) return;
        enabled = false;
        machine.stop();
        hitStop = 0;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.noCulling = savedNoCulling;
        if (savedCamera != null && mc.options.getCameraType() == CameraType.THIRD_PERSON_BACK) {
            mc.options.setCameraType(savedCamera);
        }
        savedCamera = null;
        boundLevel = null;
        if (!silent) status("§7Kenjutsu desativado");
    }

    public void restart() {
        if (!enabled) {
            status("§7Ative o Kenjutsu primeiro (tecla " + KeyBindings.TOGGLE.getTranslatedKeyMessage().getString() + ")");
            return;
        }
        rebuild();
        status("§dNova luta §7(" + comboName() + ")");
    }

    /** Nova arena onde o jogador está agora, olhando para onde ele olha. */
    private void rebuild() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        speed = KenjutsuConfig.FIGHT_SPEED.get().floatValue();
        arenaYaw = mc.player.getYRot();
        originX = mc.player.getX();
        originY = mc.player.getY();
        originZ = mc.player.getZ();
        hitStop = 0;
        released = false;
        lastVariant = ChoreographyLibrary.pickIndex(random, lastVariant);
        machine.stop();
        machine.start(ChoreographyLibrary.variants().get(lastVariant), clock);
    }

    void onLeftClick() {
        if (enabled) machine.onClick(clock);
    }

    void clientTick(Minecraft mc) {
        if (!enabled) return;
        if (mc.level == null || mc.player == null || mc.level != boundLevel) {
            deactivate(true);
            return;
        }
        if (mc.isPaused()) return;
        CombatState before = machine.state();
        float step = rate();
        if (hitStop > 0) hitStop -= 1.0F;
        clock += step;
        machine.tick(clock);
        fx.tickCharge(clock);
        if (isFighting()) movePlayer(mc.player);
        if (machine.state() == CombatState.VICTORY && !released) {
            if (before != CombatState.VICTORY) {
                victoryX = mc.player.getX();
                victoryZ = mc.player.getZ();
            } else if (Math.abs(mc.player.getX() - victoryX) + Math.abs(mc.player.getZ() - victoryZ) > 0.05) {
                released = true; // andou depois da vitória: volta ao modelo normal do jogo
            }
        }
        if (before != CombatState.VICTORY && machine.state() == CombatState.VICTORY) {
            status("§5Vitória. §7Pressione " + KeyBindings.RESTART.getTranslatedKeyMessage().getString()
                    + " para lutar de novo aqui");
        }
    }

    /**
     * Leva o jogador real até onde a coreografia o coloca no FIM do próximo
     * tick: a interpolação de renderização (posição anterior → atual) fica em
     * sincronia com o relógio das animações. Usa o movimento normal da
     * entidade: paredes e blocos bloqueiam, degraus são subidos, a gravidade
     * continua valendo.
     */
    private void movePlayer(LocalPlayer p) {
        machine.playerPosition(clock + rate(), fa);
        double tx = originX + worldX(fa[0], fa[1]);
        double tz = originZ + worldZ(fa[0], fa[1]);
        double dx = tx - p.getX(), dz = tz - p.getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len > MAX_STEP) {
            dx *= MAX_STEP / len;
            dz *= MAX_STEP / len;
        }
        Vec3 v = p.getDeltaMovement();
        p.setDeltaMovement(0.0, v.y, 0.0);
        if (len > 1.0E-4) p.move(MoverType.SELF, new Vec3(dx, 0.0, dz));
    }

    /** Durante a luta (antes da vitória) a coreografia controla o jogador. */
    public boolean isFighting() {
        CombatState s = machine.state();
        return enabled && (s == CombatState.READY || s == CombatState.PLAYING);
    }

    /** Depois da vitória, quando o jogador sai andando, o corpo volta ao modelo vanilla. */
    public boolean drawsPlayer() {
        return !released;
    }

    private float rate() {
        return hitStop > 0 ? speed * 0.12F : speed;
    }

    void hitStop(float ticks) {
        if (KenjutsuConfig.HIT_STOP.get()) hitStop = Math.max(hitStop, ticks);
    }

    private String comboName() {
        return machine.choreography() == null ? "" : machine.choreography().name;
    }

    void status(String msg) {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p != null) p.displayClientMessage(Component.literal(msg), true);
    }

    // ------------------------------------------------------------ arena -> mundo

    /** Componente X no mundo de um vetor (f, r) da arena. */
    double worldX(float f, float r) {
        double w = Math.toRadians(arenaYaw);
        return f * -Math.sin(w) + r * -Math.cos(w);
    }

    double worldZ(float f, float r) {
        double w = Math.toRadians(arenaYaw);
        return f * Math.cos(w) + r * -Math.sin(w);
    }

    // ------------------------------------------------------------ leitura

    public boolean isEnabled() {
        return enabled && machine.isActive();
    }

    public CombatStateMachine machine() {
        return machine;
    }

    /** Tempo da cena. Na micropausa o tempo quase para (inclusive entre ticks). */
    public float now(float partialTicks) {
        return clock + partialTicks * rate();
    }

    public float arenaYaw() {
        return arenaYaw;
    }

    public float playerYawAt(float t) {
        return arenaYaw + machine.playerFacing(t);
    }

    public float actorYawAt(float t) {
        return arenaYaw + machine.actorFacing(t);
    }

    /**
     * Deslocamento no mundo (dx, dz) entre onde o jogador estava no instante
     * {@code t} e onde está em {@code now} — usado para vultos, rastro e raios,
     * relativos ao corpo desenhado agora.
     */
    public void playerOffset(float t, float now, double[] out) {
        machine.playerPosition(t, fa);
        machine.playerPosition(now, fb);
        float df = fa[0] - fb[0], dr = fa[1] - fb[1];
        out[0] = worldX(df, dr);
        out[1] = worldZ(df, dr);
    }

    /** Posição do adversário no mundo (pés), apoiado no terreno. */
    public void actorWorldPos(VirtualActor actor, float t, double[] out) {
        actor.position(t, fa);
        out[0] = originX + worldX(fa[0], fa[1]);
        out[2] = originZ + worldZ(fa[0], fa[1]);
        LocalPlayer p = Minecraft.getInstance().player;
        double ref = p != null ? p.getY() : originY;
        out[1] = groundY(out[0], out[2], ref);
    }

    /** Posição do adversário relativa ao corpo desenhado do jogador. */
    public void actorRelativePos(VirtualActor actor, float partialTicks, net.minecraft.world.entity.Entity player,
                                 double[] out) {
        actorWorldPos(actor, now(partialTicks), out);
        out[0] -= Mth.lerp(partialTicks, player.xo, player.getX());
        out[1] -= Mth.lerp(partialTicks, player.yo, player.getY());
        out[2] -= Mth.lerp(partialTicks, player.zo, player.getZ());
    }

    /** Altura do chão em (x, z), procurando perto da altura de referência. */
    static double groundY(double x, double z, double refY) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return refY;
        int top = Mth.floor(refY) + 2;
        for (int y = top; y >= top - 8; y--) {
            BlockPos pos = BlockPos.containing(x, y, z);
            BlockState state = level.getBlockState(pos);
            VoxelShape shape = state.getCollisionShape(level, pos);
            if (!shape.isEmpty()) {
                double h = pos.getY() + shape.max(Direction.Axis.Y);
                if (h <= refY + 2.6) return h;
            }
        }
        return refY;
    }
}
