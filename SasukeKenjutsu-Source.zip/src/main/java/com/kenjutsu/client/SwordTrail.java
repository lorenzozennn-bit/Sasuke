package com.kenjutsu.client;

import com.kenjutsu.anim.Pose;
import com.kenjutsu.combat.CombatStateMachine;
import com.kenjutsu.rig.Mat4;
import com.kenjutsu.rig.Skeleton;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;

/**
 * Rastro de luz da espada do jogador, no estilo anime. Em vez de guardar
 * posições de quadros anteriores, reamostra a animação em instantes passados:
 * o rastro fica idêntico em qualquer FPS e só aparece quando a lâmina se move
 * rápido (cortes), sumindo sozinho quando ela desacelera.
 */
final class SwordTrail {

    private static final int SAMPLES = 9;
    private static final float STEP = 0.35F;      // ticks de cena entre amostras
    private static final float MIN_SPEED = 0.10F; // blocos por amostra para começar a aparecer
    private static final float FULL_SPEED = 0.30F;

    private final float[][] guard = new float[SAMPLES][3];
    private final float[][] tip = new float[SAMPLES][3];
    private final Pose pose = new Pose();
    private final double[] off = new double[2];
    private final Skeleton.Rig rig = new Skeleton.Rig();

    void draw(PoseStack ps, MultiBufferSource buf, KenjutsuSession session, float now, float partial) {
        CombatStateMachine m = session.machine();
        for (int i = 0; i < SAMPLES; i++) {
            float t = now - i * STEP;
            m.player().pose(t, pose);
            Skeleton.compute(pose, false, rig);
            session.playerOffset(t, now, off);
            Mat4 s = new Mat4().translate((float) off[0], 0, (float) off[1])
                    .mul(Skeleton.bodyMatrixBlocks(session.playerYawAt(t), pose)).mul(Skeleton.swordModelSpace(rig));
            s.transformPoint(Skeleton.SWORD_GUARD[0] + 0.12F, Skeleton.SWORD_GUARD[1] + 0.12F, 0.5F, guard[i]);
            s.transformPoint(Skeleton.SWORD_TIP[0], Skeleton.SWORD_TIP[1], 0.5F, tip[i]);
        }
        VertexConsumer vc = buf.getBuffer(RenderType.lightning());
        PoseStack.Pose last = ps.last();
        for (int i = 0; i < SAMPLES - 1; i++) {
            float speed = dist(tip[i], tip[i + 1]);
            if (speed < MIN_SPEED) continue;
            float k = Math.min(1.0F, (speed - MIN_SPEED) / (FULL_SPEED - MIN_SPEED));
            float a0 = k * (1.0F - i / (float) (SAMPLES - 1)) * 0.75F;
            float a1 = k * (1.0F - (i + 1) / (float) (SAMPLES - 1)) * 0.75F;
            quad(vc, last, guard[i], tip[i], tip[i + 1], guard[i + 1], a0, a1);
            quad(vc, last, guard[i + 1], tip[i + 1], tip[i], guard[i], a1, a0); // verso
        }
    }

    private static float dist(float[] a, float[] b) {
        float dx = a[0] - b[0], dy = a[1] - b[1], dz = a[2] - b[2];
        return (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose last, float[] g0, float[] t0, float[] t1, float[] g1,
                             float a0, float a1) {
        // branco-arroxeado no fio da lâmina, mais fraco perto do guarda-mão
        vc.addVertex(last, g0[0], g0[1], g0[2]).setColor(0.55F, 0.45F, 0.95F, a0 * 0.25F);
        vc.addVertex(last, t0[0], t0[1], t0[2]).setColor(0.92F, 0.88F, 1.0F, a0);
        vc.addVertex(last, t1[0], t1[1], t1[2]).setColor(0.92F, 0.88F, 1.0F, a1);
        vc.addVertex(last, g1[0], g1[1], g1[2]).setColor(0.55F, 0.45F, 0.95F, a1 * 0.25F);
    }
}
