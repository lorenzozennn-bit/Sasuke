package com.kenjutsu.mixin;

import com.kenjutsu.client.KenjutsuSession;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * A câmera em terceira pessoa acompanha o personagem quando ele corre/avança
 * na luta. Só a câmera se move: a posição real do jogador não muda.
 */
@Mixin(Camera.class)
public abstract class CameraMixin {

    @Shadow
    protected abstract void setPosition(Vec3 pos);

    @Shadow
    public abstract Vec3 getPosition();

    @Inject(method = "setup", at = @At("TAIL"))
    private void kenjutsu$followFighter(BlockGetter level, Entity entity, boolean detached,
                                        boolean thirdPersonReverse, float partialTick, CallbackInfo ci) {
        if (!detached) return;
        double[] off = KenjutsuSession.get().cameraOffset(partialTick);
        if (off != null) {
            setPosition(getPosition().add(off[0], 0.0, off[1]));
        }
    }
}
