package com.kenjutsu.mixin;

import com.kenjutsu.client.KenjutsuSession;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Câmera cinematográfica: durante a luta (em terceira pessoa) a posição e a
 * direção da câmera vêm do diretor de câmera do mod. Fora da luta, nada muda.
 */
@Mixin(Camera.class)
public abstract class CameraMixin {

    @Shadow
    protected abstract void setPosition(Vec3 pos);

    @Shadow
    protected abstract void setRotation(float yRot, float xRot);

    @Unique
    private final double[] kenjutsu$pos = new double[3];
    @Unique
    private final float[] kenjutsu$rot = new float[2];

    @Inject(method = "setup", at = @At("TAIL"))
    private void kenjutsu$cinematic(BlockGetter level, Entity entity, boolean detached,
                                    boolean thirdPersonReverse, float partialTick, CallbackInfo ci) {
        if (!detached) return;
        if (KenjutsuSession.get().cameraPose(partialTick, entity, kenjutsu$pos, kenjutsu$rot)) {
            setRotation(kenjutsu$rot[0], kenjutsu$rot[1]);
            setPosition(new Vec3(kenjutsu$pos[0], kenjutsu$pos[1], kenjutsu$pos[2]));
        }
    }
}
