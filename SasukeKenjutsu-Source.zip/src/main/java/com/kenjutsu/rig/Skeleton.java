package com.kenjutsu.rig;

import com.kenjutsu.anim.Pose;

/**
 * Esqueleto articulado (skin 64x64 Steve/Alex + armadura 64x32) com juntas
 * deformáveis: cotovelos e joelhos dobram de forma contínua, sem fresta.
 *
 * Fonte única da geometria: o renderizador do jogo e a pré-visualização usam
 * exatamente estas matrizes, malhas e a mesma rotina {@link #emit}.
 */
public final class Skeleton {

    public static final int TORSO = 0, HEAD = 1, R_UPPER_ARM = 2, R_FOREARM = 3, L_UPPER_ARM = 4,
            L_FOREARM = 5, R_THIGH = 6, R_SHIN = 7, L_THIGH = 8, L_SHIN = 9;
    public static final int BONES = 10;

    /** Juntas deformáveis. */
    public static final int J_R_ELBOW = 0, J_L_ELBOW = 1, J_R_KNEE = 2, J_L_KNEE = 3;
    public static final int JOINTS = 4;

    public static final float ELBOW_Y = 4.0F;
    public static final float KNEE_Y = 6.0F;

    /** Camadas de malha. */
    public static final int SKIN = 0, SKIN_OUTER = 1, ARMOR_OUTER = 2, ARMOR_INNER = 3;
    public static final int LAYERS = 4;

    private static final int[] JOINT_OF_BONE = {-1, -1, J_R_ELBOW, J_R_ELBOW, J_L_ELBOW, J_L_ELBOW,
            J_R_KNEE, J_R_KNEE, J_L_KNEE, J_L_KNEE};

    /** [slim][camada][osso] */
    private static final BoxMesh[][][] MESH = new BoxMesh[2][LAYERS][BONES];

    static {
        for (int s = 0; s < 2; s++) {
            boolean slim = s == 1;
            int aw = slim ? 3 : 4;
            float rx = slim ? -2.0F : -3.0F;
            BoxMesh[][] m = MESH[s];

            // ---- skin (64x64)
            m[SKIN][TORSO] = new BoxMesh(64, 64).addBox(-4, -12, -2, 8, 12, 4, 16, 16, 0);
            m[SKIN_OUTER][TORSO] = new BoxMesh(64, 64).addBox(-4, -12, -2, 8, 12, 4, 16, 32, 0.25F);
            m[SKIN][HEAD] = new BoxMesh(64, 64).addBox(-4, -8, -4, 8, 8, 8, 0, 0, 0);
            m[SKIN_OUTER][HEAD] = new BoxMesh(64, 64).addBox(-4, -8, -4, 8, 8, 8, 32, 0, 0.5F);
            limb(m, SKIN, R_UPPER_ARM, R_FOREARM, 64, rx, aw, 40, 16, 0, false);
            limb(m, SKIN_OUTER, R_UPPER_ARM, R_FOREARM, 64, rx, aw, 40, 32, 0.25F, false);
            limb(m, SKIN, L_UPPER_ARM, L_FOREARM, 64, -1, aw, 32, 48, 0, false);
            limb(m, SKIN_OUTER, L_UPPER_ARM, L_FOREARM, 64, -1, aw, 48, 48, 0.25F, false);
            leg(m, SKIN, R_THIGH, R_SHIN, 64, 0, 16, 0, false);
            leg(m, SKIN_OUTER, R_THIGH, R_SHIN, 64, 0, 32, 0.25F, false);
            leg(m, SKIN, L_THIGH, L_SHIN, 64, 16, 48, 0, false);
            leg(m, SKIN_OUTER, L_THIGH, L_SHIN, 64, 0, 48, 0.25F, false);

            // ---- armadura (texturas 64x32; lado esquerdo espelha o direito)
            // Camada externa (layer_1): capacete, peitoral, ombreiras/braços, botas.
            m[ARMOR_OUTER][HEAD] = new BoxMesh(64, 32).addBox(-4, -8, -4, 8, 8, 8, 0, 0, 1.0F);
            m[ARMOR_OUTER][TORSO] = new BoxMesh(64, 32).addBox(-4, -12, -2, 8, 12, 4, 16, 16, 1.0F);
            // Braço da armadura sempre na largura do Steve, como no modelo vanilla.
            limb(m, ARMOR_OUTER, R_UPPER_ARM, R_FOREARM, 32, -3, 4, 40, 16, 1.0F, false);
            limb(m, ARMOR_OUTER, L_UPPER_ARM, L_FOREARM, 32, -1, 4, 40, 16, 1.0F, true);
            leg(m, ARMOR_OUTER, R_THIGH, R_SHIN, 32, 0, 16, 1.0F, false);
            leg(m, ARMOR_OUTER, L_THIGH, L_SHIN, 32, 0, 16, 1.0F, true);
            // Camada interna (layer_2): calças (cintura + pernas).
            m[ARMOR_INNER][TORSO] = new BoxMesh(64, 32).addBox(-4, -12, -2, 8, 12, 4, 16, 16, 0.5F);
            leg(m, ARMOR_INNER, R_THIGH, R_SHIN, 32, 0, 16, 0.5F, false);
            leg(m, ARMOR_INNER, L_THIGH, L_SHIN, 32, 0, 16, 0.5F, true);
        }
    }

    private static void limb(BoxMesh[][] m, int layer, int upper, int fore, int texH, float x, int w,
                             int u, int v, float delta, boolean mirror) {
        m[layer][upper] = new BoxMesh(64, texH).addSegment(x, -2, -2, w, 6, 4, u, v, 0, delta, false, true, mirror);
        m[layer][fore] = new BoxMesh(64, texH).addSegment(x, 0, -2, w, 6, 4, u, v, 6, delta, true, false, mirror);
    }

    private static void leg(BoxMesh[][] m, int layer, int thigh, int shin, int texH, int u, int v,
                            float delta, boolean mirror) {
        m[layer][thigh] = new BoxMesh(64, texH).addSegment(-2, 0, -2, 4, 6, 4, u, v, 0, delta, false, true, mirror);
        m[layer][shin] = new BoxMesh(64, texH).addSegment(-2, 0, -2, 4, 6, 4, u, v, 6, delta, true, false, mirror);
    }

    private Skeleton() {
    }

    public static BoxMesh mesh(boolean slim, int layer, int bone) {
        return MESH[slim ? 1 : 0][layer][bone];
    }

    // ------------------------------------------------------------------ poses

    /** Estado calculado de um corpo: matrizes dos ossos e das juntas (px, espaço do modelo). */
    public static final class Rig {
        public final Mat4[] bones = new Mat4[BONES];
        public final Mat4[] joints = new Mat4[JOINTS];

        public Rig() {
            for (int i = 0; i < BONES; i++) bones[i] = new Mat4();
            for (int i = 0; i < JOINTS; i++) joints[i] = new Mat4();
        }
    }

    /** Calcula o esqueleto. O quadril desce para manter o pé mais baixo no chão. */
    public static void compute(Pose p, boolean slim, Rig out) {
        build(p, slim, 0.0F, out);
        float maxY = Math.max(footY(out.bones[R_SHIN]), footY(out.bones[L_SHIN]));
        float drop = 24.0F - maxY;
        if (drop > 0.001F) build(p, slim, drop, out);
    }

    private static float footY(Mat4 shin) {
        float max = -1e9F;
        float[] tmp = new float[3];
        for (int i = 0; i < 4; i++) {
            shin.transformPoint((i & 1) == 0 ? -2 : 2, 6, (i & 2) == 0 ? -2 : 2, tmp);
            max = Math.max(max, tmp[1]);
        }
        return max;
    }

    private static void build(Pose p, boolean slim, float drop, Rig r) {
        Mat4[] b = r.bones;
        Mat4 hips = new Mat4().translate(0, 12 + drop, 0);
        b[TORSO].set(hips).rotateZYX(p.get(Pose.BODY), p.get(Pose.BODY + 1), p.get(Pose.BODY + 2));
        b[HEAD].set(b[TORSO]).translate(0, -12, 0)
                .rotateZYX(p.get(Pose.HEAD), p.get(Pose.HEAD + 1), p.get(Pose.HEAD + 2));
        float sy = slim ? -9.5F : -10.0F;
        b[R_UPPER_ARM].set(b[TORSO]).translate(-5, sy, 0)
                .rotateZYX(p.get(Pose.R_ARM), p.get(Pose.R_ARM + 1), p.get(Pose.R_ARM + 2));
        b[L_UPPER_ARM].set(b[TORSO]).translate(5, sy, 0)
                .rotateZYX(p.get(Pose.L_ARM), p.get(Pose.L_ARM + 1), p.get(Pose.L_ARM + 2));
        b[R_THIGH].set(hips).translate(-1.9F, 0, 0)
                .rotateZYX(p.get(Pose.R_LEG), p.get(Pose.R_LEG + 1), p.get(Pose.R_LEG + 2));
        b[L_THIGH].set(hips).translate(1.9F, 0, 0)
                .rotateZYX(p.get(Pose.L_LEG), p.get(Pose.L_LEG + 1), p.get(Pose.L_LEG + 2));

        joint(b[R_UPPER_ARM], b[R_FOREARM], r.joints[J_R_ELBOW], ELBOW_Y, -p.get(Pose.R_ELBOW));
        joint(b[L_UPPER_ARM], b[L_FOREARM], r.joints[J_L_ELBOW], ELBOW_Y, -p.get(Pose.L_ELBOW));
        joint(b[R_THIGH], b[R_SHIN], r.joints[J_R_KNEE], KNEE_Y, p.get(Pose.R_KNEE));
        joint(b[L_THIGH], b[L_SHIN], r.joints[J_L_KNEE], KNEE_Y, p.get(Pose.L_KNEE));
    }

    /**
     * Segmento inferior gira o ângulo inteiro; o anel da junta gira a metade e
     * é alargado no sentido da dobra (1/cos(θ/2)) para manter a espessura.
     */
    private static void joint(Mat4 upper, Mat4 lower, Mat4 ring, float at, float bendDeg) {
        lower.set(upper).translate(0, at, 0).rotate(bendDeg, 0);
        float half = bendDeg * 0.5F;
        float c = (float) Math.cos(Math.toRadians(half));
        float widen = c < 0.55F ? 1.8F : 1.0F / c;
        ring.set(upper).translate(0, at, 0).rotate(half, 0).scale(1.0F, 1.0F, widen);
    }

    // ------------------------------------------------------------------ desenho

    /** Recebe vértices já transformados. */
    public interface Sink {
        void vertex(float x, float y, float z, float u, float v, float nx, float ny, float nz);
    }

    private static final ThreadLocal<float[]> TMP = ThreadLocal.withInitial(() -> new float[3]);

    /**
     * Emite um osso de uma camada. {@code base} leva do espaço do modelo (px) ao
     * espaço de destino (ex.: posição relativa à câmera, em blocos).
     */
    public static void emit(Mat4 base, Rig rig, boolean slim, int layer, int bone, Sink sink) {
        BoxMesh mesh = mesh(slim, layer, bone);
        if (mesh == null) return;
        Mat4 boneM = base.copy().mul(rig.bones[bone]);
        int j = JOINT_OF_BONE[bone];
        Mat4 ringM = j < 0 ? null : base.copy().mul(rig.joints[j]);
        float[] t = TMP.get();
        float[] n = new float[3];
        for (BoxMesh.Quad q : mesh.quads()) {
            boneM.transformDir(q.nx, q.ny, q.nz, n);
            normalize(n);
            for (int v = 0; v < 4; v++) {
                float x = q.xyz[v * 3], y = q.xyz[v * 3 + 1], z = q.xyz[v * 3 + 2];
                if (q.ring[v] && ringM != null) {
                    ringM.transformPoint(x, 0.0F, z, t); // anel da junta: y = 0 no espaço da junta
                } else {
                    boneM.transformPoint(x, y, z, t);
                }
                sink.vertex(t[0], t[1], t[2], q.uv[v * 2], q.uv[v * 2 + 1], n[0], n[1], n[2]);
            }
        }
    }

    private static void normalize(float[] n) {
        float l = (float) Math.sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]);
        if (l > 1e-6F) {
            n[0] /= l;
            n[1] /= l;
            n[2] /= l;
        }
    }

    // ------------------------------------------------------------------ corpo

    /** Transformação raiz em blocos (depois da rotação de direção, antes do scale(-1,-1,1)). */
    public static Mat4 rootMatrix(Pose p) {
        Mat4 m = new Mat4();
        m.translate(p.get(Pose.OFF_X), p.get(Pose.OFF_Y), -p.get(Pose.OFF_F));
        m.rotate(p.get(Pose.ROOT_YAW), 1);
        float pitch = p.get(Pose.ROOT_PITCH), roll = p.get(Pose.ROOT_ROLL);
        if (pitch != 0.0F || roll != 0.0F) {
            float pivot = p.get(Pose.PIVOT_Y);
            m.translate(0, pivot, 0).rotate(-pitch, 0).rotate(-roll, 2).translate(0, -pivot, 0);
        }
        return m;
    }

    /** Pés do corpo -> espaço do modelo em BLOCOS (mesma sequência do LivingEntityRenderer). */
    public static Mat4 bodyMatrixBlocks(float worldYaw, Pose p) {
        Mat4 m = new Mat4();
        m.rotate(180.0F - worldYaw, 1);
        m.mul(rootMatrix(p));
        m.scale(-1, -1, 1);
        m.scale(0.9375F, 0.9375F, 0.9375F);
        m.translate(0, -1.501F, 0);
        return m;
    }

    /** Pés do corpo -> espaço do modelo em PIXELS (para os ossos). */
    public static Mat4 bodyMatrix(float worldYaw, Pose p) {
        return bodyMatrixBlocks(worldYaw, p).scale(0.0625F, 0.0625F, 0.0625F);
    }

    // ------------------------------------------------------------------ espada

    /**
     * Quadro da mão direita em BLOCOS, já com as rotações/translações que o
     * ItemInHandLayer aplica antes de desenhar o item (Rx -90, Ry 180, translate).
     * O item deve ser desenhado aqui com THIRD_PERSON_RIGHT_HAND.
     */
    public static Mat4 rightHandItemFrame(Rig rig) {
        Mat4 hand = rig.bones[R_FOREARM].copy().translate(0, -ELBOW_Y, 0).withScaledTranslation(0.0625F);
        return hand.rotate(-90.0F, 0).rotate(180.0F, 1).translate(1.0F / 16.0F, 0.125F, -0.625F);
    }

    /**
     * Espaço do modelo do item (cubo 0..1) da espada na mão direita, aplicando a
     * transformação "thirdperson_righthand" do item/handheld.json do Minecraft.
     */
    public static Mat4 swordModelSpace(Rig rig) {
        Mat4 m = rightHandItemFrame(rig);
        m.translate(0.0F, 4.0F / 16.0F, 0.5F / 16.0F);
        m.rotate(0.0F, 0).rotate(-90.0F, 1).rotate(55.0F, 2);
        m.scale(0.85F, 0.85F, 0.85F);
        m.translate(-0.5F, -0.5F, -0.5F);
        return m;
    }

    /** Pontos da lâmina no espaço do modelo do item (sprite 16x16 na diagonal). */
    public static final float[] SWORD_TIP = {0.95F, 0.95F, 0.5F};
    public static final float[] SWORD_GUARD = {0.32F, 0.32F, 0.5F};
    public static final float[] SWORD_POMMEL = {0.06F, 0.06F, 0.5F};
}
