package com.kenjutsu.rig;

/**
 * Espada arrancada da mão do adversário: sobe girando, cai e fica cravada no
 * chão. Tudo em função do tempo desde o desarme (determinístico).
 *
 * Entrada: matriz do espaço do modelo do item (cubo 0..1) no instante do
 * desarme, em blocos, relativa aos pés do adversário; e a direção lateral
 * (unitária, no plano XZ) para onde ela voa.
 */
public final class FlyingSword {

    private FlyingSword() {
    }

    public static final float FLIGHT_TICKS = 16.0F;
    private static final float UP_SPEED = 0.34F;     // blocos/tick
    private static final float SIDE_SPEED = 0.11F;   // blocos/tick
    private static final float GRAVITY = 0.045F;     // blocos/tick²
    private static final float SPIN = 47.0F;         // graus/tick

    /**
     * @param start  item no instante do desarme (relativo aos pés do adversário)
     * @param sideX  direção lateral X
     * @param sideZ  direção lateral Z
     * @param t      ticks desde o desarme
     */
    public static Mat4 matrix(Mat4 start, float sideX, float sideZ, float t) {
        float[] c = new float[3];
        start.transformPoint(0.5F, 0.5F, 0.5F, c);
        float tt = Math.min(t, FLIGHT_TICKS);
        // Trajetória até tocar o chão (y = 0.3: lâmina meio enterrada).
        float x = c[0] + sideX * SIDE_SPEED * tt;
        float z = c[2] + sideZ * SIDE_SPEED * tt;
        float y = c[1] + UP_SPEED * tt - GRAVITY * tt * tt;
        float ground = 0.32F;
        if (y < ground || t >= FLIGHT_TICKS) y = Math.max(ground, Math.min(y, ground + 0.6F));
        boolean landed = t >= FLIGHT_TICKS;

        Mat4 m = new Mat4().translate(x, y, z);
        // Eixo de giro: perpendicular à direção do voo, horizontal.
        float yaw = (float) Math.toDegrees(Math.atan2(sideX, sideZ));
        m.rotate(yaw, 1);
        if (landed) {
            // Cravada: ponta para baixo, levemente inclinada.
            m.rotate(18.0F, 0).rotate(-135.0F, 2);
        } else {
            m.rotate(SPIN * tt, 0).rotate(-135.0F, 2);
        }
        return m.translate(-0.5F, -0.5F, -0.5F);
    }
}
