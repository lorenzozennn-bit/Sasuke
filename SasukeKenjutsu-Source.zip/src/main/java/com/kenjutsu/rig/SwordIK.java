package com.kenjutsu.rig;

import com.kenjutsu.anim.Pose;

/**
 * Cinemática inversa da espada: dado ONDE a espada deve estar (guarda-mão e
 * ponta, em blocos, F = frente, R = direita, U = altura a partir dos pés),
 * encontra os ângulos do ombro direito (x, y, z), do cotovelo direito e — com
 * peso menor — a torção e a inclinação do tronco, para o corpo inteiro
 * participar do golpe.
 *
 * Referencial "arena" (padrão): inclui o giro e o deslocamento da raiz da pose,
 * ou seja, os pontos são relativos aos pés com o corpo virado para o alvo.
 * Referencial "local": ignora a raiz (para giros de 360° em que a espada
 * acompanha o corpo).
 *
 * Determinística: mesma entrada, mesmo resultado.
 */
public final class SwordIK {

    private SwordIK() {
    }

    public static final class Result {
        public final float[] v = new float[6];
        public float error;
    }

    // ombro x, y, z, cotovelo, tronco x (inclinação), tronco y (torção)
    private static final float[] LO = {-210, -180, -200, 0, -35, -80};
    private static final float[] HI = {90, 180, 200, 150, 45, 80};
    private static final int N = 6;

    /** Comprimento da lâmina (guarda-mão até a ponta), em blocos. */
    public static final float BLADE = 0.71F;

    /** Guarda-mão em (F,R,U) e direção da lâmina (F,R,U, não precisa ser unitária). */
    public static Result solveDir(Pose p, float[] guardFRU, float[] dirFRU, boolean local) {
        float l = (float) Math.sqrt(dirFRU[0] * dirFRU[0] + dirFRU[1] * dirFRU[1] + dirFRU[2] * dirFRU[2]);
        float[] tip = {guardFRU[0] + dirFRU[0] / l * BLADE, guardFRU[1] + dirFRU[1] / l * BLADE,
                guardFRU[2] + dirFRU[2] / l * BLADE};
        return solve(p, guardFRU, tip, local);
    }

    public static Result solve(Pose p, float[] guardFRU, float[] tipFRU, boolean local) {
        Pose base = Pose.from(p);
        if (local) base.root(0, 0, 0).off(0, 0, 0);
        Skeleton.Rig rig = new Skeleton.Rig();
        float bz = base.get(Pose.BODY + 2);
        Pose noBody = Pose.from(base).body(0, 0, 0);
        Skeleton.compute(noBody, false, rig);
        Mat4 body = Skeleton.bodyMatrixBlocks(0.0F, base);
        Mat4 hips = rig.bones[Skeleton.TORSO];
        float[] g = {-guardFRU[1], guardFRU[2], guardFRU[0]};
        float[] t = {-tipFRU[1], tipFRU[2], tipFRU[0]};
        float bx0 = base.get(Pose.BODY), by0 = base.get(Pose.BODY + 1);

        float[] best = null;
        float bestErr = Float.MAX_VALUE;
        long seed = 0x5EED5EEDL;
        for (int i = 0; i < 24; i++) {
            float[] st = new float[N];
            for (int k = 0; k < N; k++) {
                seed = seed * 6364136223846793005L + 1442695040888963407L;
                float u = ((seed >>> 40) & 0xFFFFFF) / (float) 0x1000000;
                st[k] = LO[k] + u * (HI[k] - LO[k]);
            }
            st[4] = bx0;
            st[5] = by0;
            float err = refine(st, body, hips, bz, g, t, bx0, by0);
            if (err < bestErr) {
                bestErr = err;
                best = st;
            }
        }
        p.ra(best[0], best[1], best[2]);
        p.elbows(best[3], p.get(Pose.L_ELBOW));
        p.body(best[4], best[5], bz);
        Result r = new Result();
        System.arraycopy(best, 0, r.v, 0, N);
        r.error = (float) Math.sqrt(posError(best, body, hips, bz, g, t));
        return r;
    }

    private static float refine(float[] x, Mat4 body, Mat4 hips, float bz, float[] g, float[] t,
                                float bx0, float by0) {
        float err = eval(x, body, hips, bz, g, t, bx0, by0);
        float step = 32.0F;
        while (step > 0.05F) {
            boolean improved = false;
            for (int i = 0; i < N; i++) {
                for (int sgn = -1; sgn <= 1; sgn += 2) {
                    float old = x[i];
                    float nv = old + sgn * step;
                    x[i] = nv < LO[i] ? LO[i] : (nv > HI[i] ? HI[i] : nv);
                    float e = eval(x, body, hips, bz, g, t, bx0, by0);
                    if (e < err) {
                        err = e;
                        improved = true;
                    } else {
                        x[i] = old;
                    }
                }
            }
            if (!improved) step *= 0.5F;
        }
        return err;
    }

    private static final float[] Q = new float[3];

    private static float posError(float[] a, Mat4 body, Mat4 hips, float bz, float[] g, float[] t) {
        Mat4 s = swordFrame(body, hips, bz, a);
        float e = 0;
        s.transformPoint(Skeleton.SWORD_GUARD[0], Skeleton.SWORD_GUARD[1], Skeleton.SWORD_GUARD[2], Q);
        e += sq(Q[0] - g[0]) + sq(Q[1] - g[1]) + sq(Q[2] - g[2]);
        s.transformPoint(Skeleton.SWORD_TIP[0], Skeleton.SWORD_TIP[1], Skeleton.SWORD_TIP[2], Q);
        e += sq(Q[0] - t[0]) + sq(Q[1] - t[1]) + sq(Q[2] - t[2]);
        return e * 0.5F;
    }

    private static float eval(float[] a, Mat4 body, Mat4 hips, float bz, float[] g, float[] t,
                              float bx0, float by0) {
        float e = posError(a, body, hips, bz, g, t);
        // Preferências suaves: tronco perto do autorado, cotovelo e torção moderados.
        e += 0.000004F * (sq(a[4] - bx0) + sq(a[5] - by0));
        e += 0.0000003F * (sq(a[3]) + 0.3F * sq(a[1]));
        return e;
    }

    private static float sq(float v) {
        return v * v;
    }

    /** Mesma cadeia do Skeleton (cintura -> ombro -> cotovelo -> item na mão). */
    private static Mat4 swordFrame(Mat4 body, Mat4 hips, float bz, float[] a) {
        Mat4 m = hips.copy().rotateZYX(a[4], a[5], bz);
        m.translate(-5.0F, -10.0F, 0.0F).rotateZYX(a[0], a[1], a[2]);
        m.translate(0, Skeleton.ELBOW_Y, 0).rotate(-a[3], 0).translate(0, -Skeleton.ELBOW_Y, 0);
        Mat4 hand = m.withScaledTranslation(0.0625F);
        hand.rotate(-90.0F, 0).rotate(180.0F, 1).translate(1.0F / 16.0F, 0.125F, -0.625F);
        hand.translate(0.0F, 4.0F / 16.0F, 0.5F / 16.0F);
        hand.rotate(0.0F, 0).rotate(-90.0F, 1).rotate(55.0F, 2);
        hand.scale(0.85F, 0.85F, 0.85F);
        hand.translate(-0.5F, -0.5F, -0.5F);
        return body.copy().mul(hand);
    }
}
