package com.kenjutsu.rig;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Malha de caixas com o mesmo mapeamento UV do ModelBox/ModelPart do Minecraft,
 * com três extras:
 *  - recorte de um membro em segmentos (braço/antebraço, coxa/canela);
 *  - marcação dos vértices do "anel" da junta, que o esqueleto deforma para a
 *    dobra ficar contínua (sem fresta), como as bibliotecas de membros dobráveis;
 *  - espelhamento (membros esquerdos das texturas de armadura 64x32).
 *
 * Coordenadas: pixels, Y para baixo, frente em -Z, lado direito do personagem em -X.
 */
public final class BoxMesh {

    /** Um quadrilátero: 4 vértices (x, y, z, u, v), flag de anel por vértice e normal. */
    public static final class Quad {
        public final float[] xyz = new float[12];
        public final float[] uv = new float[8];
        public final boolean[] ring = new boolean[4];
        public float nx, ny, nz;

        Quad(float nx, float ny, float nz) {
            this.nx = nx;
            this.ny = ny;
            this.nz = nz;
        }
    }

    private final float texW;
    private final float texH;
    private final List<Quad> quads = new ArrayList<Quad>();

    public BoxMesh(float texW, float texH) {
        this.texW = texW;
        this.texH = texH;
    }

    public List<Quad> quads() {
        return Collections.unmodifiableList(quads);
    }

    private Quad quad(float nx, float ny, float nz) {
        Quad q = new Quad(nx, ny, nz);
        quads.add(q);
        return q;
    }

    private void put(Quad q, int i, float x, float y, float z, float u, float v, boolean ring) {
        q.xyz[i * 3] = x;
        q.xyz[i * 3 + 1] = y;
        q.xyz[i * 3 + 2] = z;
        q.uv[i * 2] = u / texW;
        q.uv[i * 2 + 1] = v / texH;
        q.ring[i] = ring;
    }

    /**
     * Adiciona um segmento de caixa.
     *
     * @param x,y,z       canto mínimo (px) no espaço do osso
     * @param w,h,d       largura, altura DO SEGMENTO, profundidade
     * @param u,v         offset da caixa original na textura
     * @param rowStart    linha da textura lateral onde o segmento começa (0..altura total)
     * @param delta       inflação (camadas externas / armadura)
     * @param ringTop     vértices do topo pertencem ao anel da junta
     * @param ringBottom  vértices da base pertencem ao anel da junta
     * @param mirror      espelha em X (membro esquerdo usando a textura do direito)
     */
    public BoxMesh addSegment(float x, float y, float z, int w, int h, int d, int u, int v,
                              int rowStart, float delta, boolean ringTop, boolean ringBottom, boolean mirror) {
        float x0 = x - delta, y0 = y - delta, z0 = z - delta;
        float x1 = x + w + delta, y1 = y + h + delta, z1 = z + d + delta;
        if (mirror) {
            // Monta a caixa equivalente do lado direito (sem espelho) e, no fim,
            // reflete todos os vértices em X: textura espelhada como no ModelBox.
            float rx0 = -x1, rx1 = -x0;
            x0 = rx0;
            x1 = rx1;
        }
        int first = quads.size();
        float sv0 = v + d + rowStart;
        float sv1 = v + d + rowStart + h;
        boolean rt = ringTop, rb = ringBottom;

        Quad q = quad(0, 0, -1); // frente
        put(q, 0, x1, y0, z0, u + d + w, sv0, rt);
        put(q, 1, x0, y0, z0, u + d, sv0, rt);
        put(q, 2, x0, y1, z0, u + d, sv1, rb);
        put(q, 3, x1, y1, z0, u + d + w, sv1, rb);

        q = quad(0, 0, 1); // costas
        put(q, 0, x0, y0, z1, u + d + w + d + w, sv0, rt);
        put(q, 1, x1, y0, z1, u + d + w + d, sv0, rt);
        put(q, 2, x1, y1, z1, u + d + w + d, sv1, rb);
        put(q, 3, x0, y1, z1, u + d + w + d + w, sv1, rb);

        q = quad(-1, 0, 0); // -X
        put(q, 0, x0, y0, z0, u + d, sv0, rt);
        put(q, 1, x0, y0, z1, u, sv0, rt);
        put(q, 2, x0, y1, z1, u, sv1, rb);
        put(q, 3, x0, y1, z0, u + d, sv1, rb);

        q = quad(1, 0, 0); // +X
        put(q, 0, x1, y0, z1, u + d + w + d, sv0, rt);
        put(q, 1, x1, y0, z0, u + d + w, sv0, rt);
        put(q, 2, x1, y1, z0, u + d + w, sv1, rb);
        put(q, 3, x1, y1, z1, u + d + w + d, sv1, rb);

        if (!rt) { // topo (tampa escondida dentro da junta não é desenhada)
            q = quad(0, -1, 0);
            put(q, 0, x1, y0, z1, u + d + w, v, false);
            put(q, 1, x0, y0, z1, u + d, v, false);
            put(q, 2, x0, y0, z0, u + d, v + d, false);
            put(q, 3, x1, y0, z0, u + d + w, v + d, false);
        }
        if (!rb) { // base
            q = quad(0, 1, 0);
            put(q, 0, x1, y1, z0, u + d + w + w, v + d, false);
            put(q, 1, x0, y1, z0, u + d + w, v + d, false);
            put(q, 2, x0, y1, z1, u + d + w, v, false);
            put(q, 3, x1, y1, z1, u + d + w + w, v, false);
        }

        if (mirror) {
            for (int i = first; i < quads.size(); i++) {
                Quad m = quads.get(i);
                for (int k = 0; k < 4; k++) m.xyz[k * 3] = -m.xyz[k * 3];
                m.nx = -m.nx;
            }
        }
        return this;
    }

    /** Caixa inteira (sem recorte nem juntas). */
    public BoxMesh addBox(float x, float y, float z, int w, int h, int d, int u, int v, float delta) {
        return addSegment(x, y, z, w, h, d, u, v, 0, delta, false, false, false);
    }
}
