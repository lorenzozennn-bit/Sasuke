package com.kenjutsu;

import com.kenjutsu.client.ClientEvents;
import com.kenjutsu.client.KenjutsuConfig;
import com.kenjutsu.client.KeyBindings;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;

/**
 * Sasuke Kenjutsu Cinematic — luta de espada cinematográfica (1v1) em terceira
 * pessoa. Mod exclusivamente client-side: nada é registrado no mundo nem no
 * servidor; armadura e espada de netherite são apenas visuais.
 */
@Mod(value = KenjutsuMod.MODID, dist = Dist.CLIENT)
public final class KenjutsuMod {

    public static final String MODID = "kenjutsu";

    public KenjutsuMod(IEventBus modBus, ModContainer container) {
        container.registerConfig(ModConfig.Type.CLIENT, KenjutsuConfig.SPEC);
        modBus.addListener(KeyBindings::register);
        NeoForge.EVENT_BUS.register(new ClientEvents());
    }
}
