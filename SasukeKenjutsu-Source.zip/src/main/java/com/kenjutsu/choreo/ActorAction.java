package com.kenjutsu.choreo;

import com.kenjutsu.anim.Clip;

/** Ação do adversário dentro de uma etapa, com atraso relativo ao início da etapa. */
public final class ActorAction {
    public final int actor;
    /** Clipe a tocar (pode ser nulo quando a ação é só efeito). */
    public final Clip clip;
    public final int delay;
    /** Para onde é arremessado na derrota (NaN = fica onde está). */
    public final float knockX, knockZ;
    public final int moveTicks;
    public final ImpactType impact;
    public final boolean defeat;

    public ActorAction(int actor, Clip clip, int delay, float knockX, float knockZ, int moveTicks,
                       ImpactType impact, boolean defeat) {
        this.actor = actor;
        this.clip = clip;
        this.delay = delay;
        this.knockX = knockX;
        this.knockZ = knockZ;
        this.moveTicks = moveTicks;
        this.impact = impact == null ? ImpactType.NONE : impact;
        this.defeat = defeat;
    }

    public boolean movesActor() {
        return !Float.isNaN(knockX);
    }
}
