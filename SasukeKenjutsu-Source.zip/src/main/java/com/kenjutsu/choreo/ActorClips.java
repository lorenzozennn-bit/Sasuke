package com.kenjutsu.choreo;

import com.kenjutsu.anim.Clip;
import com.kenjutsu.anim.Ease;
import com.kenjutsu.anim.Pose;

/**
 * Adversários: armadura e espada de netherite (mão direita). "Frente" é sempre
 * a direção do jogador. Lutam com raiva e força bruta — e perdem feio.
 *
 * Mesma mecânica da pegada: braço à frente = lâmina para cima; acima da
 * cabeça = lâmina para trás.
 */
public final class ActorClips {

    private ActorClips() {
    }

    /** Guarda média: lâmina erguida apontando para o jogador. */
    public static final Pose GUARD = new Pose()
            .root(15, 0, 0)
            .body(8, -10, 0)
            .head(-4, 8, 0)
            .ra(-58, -12, 6).elbows(18, 60)
            .la(-35, 25, -12)
            .rl(14, 0, 5).ll(-18, 0, -5)
            .knees(28, 28);

    public static final Clip GUARD_IDLE = Clip.build("a_guard_idle")
            .key(0, GUARD)
            .key(10, Pose.from(GUARD).body(10, -10, 0).ra(-55, -12, 6).knees(32, 32))
            .key(20, GUARD)
            .loop().done();

    /** Espada erguida acima da cabeça, pronto para descer. */
    private static final Pose OVERHEAD = Pose.from(GUARD).root(10, 0, 0).body(-8, 5, 0).head(-12, 0, 0)
            .ra(-172, 5, 12).elbows(10, 60).la(-60, 10, -20);

    private static Pose runStride(float side) {
        return Pose.from(OVERHEAD).body(18, 5, 0).head(-24, 0, 0)
                .rl(side > 0 ? -55 : 40, 0, 4).ll(side > 0 ? 40 : -55, 0, -4)
                .knees(side > 0 ? 70 : 35, side > 0 ? 35 : 70).off(0, 0.06F, 0);
    }

    /** Corre para cima do jogador com a espada erguida (a distância vem da coreografia). */
    public static final Clip RUN_IN = Clip.build("a_run_in")
            .key(0, GUARD)
            .key(2, runStride(1), Ease.OUT)
            .key(4.5F, Pose.from(runStride(1)).off(0, 0.12F, 0))
            .key(7, runStride(-1))
            .key(9.5F, Pose.from(runStride(-1)).off(0, 0.12F, 0))
            .key(12, OVERHEAD)
            .done();

    public static final Clip OVERHEAD_HOLD = Clip.build("a_overhead_hold")
            .key(0, OVERHEAD).key(8, Pose.from(OVERHEAD).ra(-175, 5, 12).knees(32, 30)).key(16, OVERHEAD)
            .loop().done();

    /** Golpe descendente com força bruta. A lâmina chega: tick 4. */
    public static final Clip OVERHEAD_STRIKE = Clip.build("a_overhead_strike")
            .key(0, OVERHEAD)
            .key(2, Pose.from(OVERHEAD).body(-14, 8, 0).ra(-180, 5, 12).knees(30, 25))
            .key(4, Pose.from(GUARD).root(0, 0, 0).body(28, -5, 0).head(-10, 0, 0)
                    .ra(-40, -8, 10).elbows(4, 60).la(20, 0, -30)
                    .rl(25, 0, 5).ll(-40, 0, -5).knees(20, 50).off(0, 0, 0.35F), Ease.OUT)
            .key(6, Pose.from(GUARD).root(0, 0, 0).body(32, -5, 0).head(-8, 0, 0)
                    .ra(-5, -8, 10).elbows(2, 60).la(25, 0, -30)
                    .rl(25, 0, 5).ll(-40, 0, -5).knees(20, 52).off(0, 0, 0.38F))
            .key(12, GUARD)
            .done();

    /** Golpe horizontal largo. A lâmina chega: tick 4. */
    public static final Clip HORIZ_STRIKE = Clip.build("a_horiz_strike")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(35, 0, 0).body(4, 35, 0).head(-6, -30, 0)
                    .ra(55, 0, 90).elbows(10, 40).la(-50, 25, -20).knees(30, 25))
            .key(4, Pose.from(GUARD).root(5, 0, 0).body(14, -10, 0).head(-6, 5, 0)
                    .ra(-60, 0, 90).elbows(12, 40).la(15, 0, -25)
                    .rl(25, 0, 5).ll(-35, 0, -5).knees(25, 40).off(0, 0, 0.3F), Ease.OUT)
            .key(6, Pose.from(GUARD).root(0, 0, 0).body(16, -40, 0).head(-6, 30, 0)
                    .ra(-150, 0, 90).elbows(12, 40).la(30, 0, -30)
                    .rl(25, 0, 5).ll(-35, 0, -5).knees(25, 40).off(0, 0, 0.32F))
            .key(12, GUARD)
            .done();

    /** Bloqueio alto desesperado (lâmina horizontal sobre a cabeça). */
    public static final Clip BLOCK_HIGH = Clip.build("a_block_high")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).body(-4, 5, 0).head(-20, 0, 0)
                    .ra(-134, 70, 28).elbows(17, 60).knees(35, 35), Ease.OUT)
            .key(5, Pose.from(GUARD).body(-6, 5, 0).head(-20, 0, 0)
                    .ra(-132, 70, 28).elbows(20, 60).knees(40, 40))
            .done();

    /** Arremessado para trás quando a lâmina é aparada (braço da espada jogado para cima). */
    public static final Clip RECOIL = Clip.build("a_recoil")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(25, 0, 6).body(-22, 25, 0).head(-25, 20, 5)
                    .ra(-150, 30, 60).elbows(10, 30).la(-20, 0, -40)
                    .rl(-20, 0, 8).knees(20, 40).off(0, 0, -0.3F), Ease.OUT)
            .key(6, Pose.from(GUARD).root(15, 0, 3).body(-10, 15, 0).head(-12, 10, 0)
                    .ra(-120, 20, 45).elbows(15, 40).knees(35, 45).off(0, 0, -0.35F))
            .key(12, Pose.from(GUARD).off(0, 0, -0.2F))
            .key(16, GUARD)
            .done();

    /** Desarmado: a mão vazia é jogada para cima e ele cambaleia, olhando a própria mão. */
    private static final Pose EMPTY = Pose.from(GUARD).ra(-40, -20, 10).elbows(70, 60);

    public static final Clip DISARMED = Clip.build("a_disarmed")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(20, 0, 5).body(-18, 20, 0).head(-30, 25, 0)
                    .ra(-165, 25, 55).elbows(15, 30).la(-20, 0, -35).knees(25, 40).off(0, 0, -0.25F), Ease.OUT)
            .key(7, Pose.from(GUARD).root(10, 0, 0).body(10, -5, 0).head(15, 30, 0)
                    .ra(-70, -40, 10).elbows(60, 50).la(-30, 20, -15).knees(35, 35).off(0, 0, -0.4F))
            .key(12, Pose.from(EMPTY).head(10, 25, 0).off(0, 0, -0.3F))
            .key(16, EMPTY)
            .done();

    public static final Clip EMPTY_IDLE = Clip.build("a_empty_idle")
            .key(0, EMPTY).key(10, Pose.from(EMPTY).head(8, 15, 0).knees(32, 32)).key(20, EMPTY)
            .loop().done();

    /** Corte na armadura: tranco para trás. */
    public static final Clip SLASHED = Clip.build("a_slashed")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).body(-24, 20, 0).head(-28, 15, 5)
                    .ra(-20, 0, 45).elbows(10, 30).la(-30, 0, -35).knees(30, 35).off(0, 0, -0.25F), Ease.OUT)
            .key(6, Pose.from(GUARD).body(-8, 8, 0).head(-10, 8, 0)
                    .ra(-40, -10, 25).elbows(15, 50).knees(35, 35).off(0, 0, -0.2F))
            .key(12, GUARD)
            .done();

    /** Cambaleio forte. */
    public static final Clip STAGGER = Clip.build("a_stagger")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(25, 0, 8).body(-28, 25, 0).head(-25, 15, 5)
                    .ra(-10, 0, 55).elbows(20, 40).la(-20, 0, -45)
                    .rl(-25, 0, 8).knees(20, 40).off(0, 0, -0.45F), Ease.OUT)
            .key(6, Pose.from(GUARD).root(-5, 0, -6).body(-12, -10, 0).head(-5, -5, 0)
                    .ra(-25, 0, 40).elbows(25, 40).ll(-30, 0, -8).knees(35, 50).off(0, 0, -0.5F))
            .key(10, Pose.from(GUARD).body(15, -10, 0).knees(50, 50).off(0, 0, -0.35F))
            .key(16, GUARD)
            .done();

    /** Atordoado depois do tapa: cabeça virada, a espada cai da mão (desarme). */
    private static final Pose DAZED = Pose.from(EMPTY).root(40, 0, 6).body(10, 25, 8).head(15, 55, 15)
            .ra(10, 0, 20).elbows(20, 15).la(5, 0, -20).knees(35, 20).off(0, 0, -0.2F);

    public static final Clip SLAPPED = Clip.build("a_slapped")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(30, 0, 8).body(-10, 30, 8).head(-15, 75, 20)
                    .ra(-20, 0, 50).elbows(10, 30).la(-30, 0, -40).off(0, 0, -0.15F), Ease.OUT)
            .key(7, DAZED)
            .done();

    public static final Clip DAZED_IDLE = Clip.build("a_dazed_idle")
            .key(0, DAZED).key(10, Pose.from(DAZED).root(35, 0, -4).head(18, 45, -6)).key(20, DAZED)
            .loop().done();

    /** Atacou o vazio e perdeu o equilíbrio para a frente. */
    public static final Clip OVERCOMMIT = Clip.build("a_overcommit")
            .key(0, OVERHEAD)
            .key(2, Pose.from(OVERHEAD).body(-14, 8, 0).ra(-180, 5, 12))
            .key(4, Pose.from(GUARD).root(0, 0, 0).body(40, 5, 0).head(-20, 0, 0)
                    .ra(10, -8, 10).elbows(2, 40).la(-60, 0, -40)
                    .rl(30, 0, 5).ll(-45, 0, -5).knees(25, 60).off(-0.15F, 0, 0.3F), Ease.OUT)
            .key(8, Pose.from(GUARD).root(-10, 0, 0).body(30, 15, 0).head(-10, 10, 0)
                    .ra(20, -8, 15).elbows(2, 40).la(-40, 0, -40).knees(40, 50).off(-0.15F, 0, 0.28F))
            .key(14, Pose.from(GUARD).off(0, 0, 0.1F))
            .done();

    // ------------------------------------------------------------- derrotas

    /** Parado, sem perceber que já foi cortado (depois do iai). */
    private static final Pose FROZEN = Pose.from(GUARD).root(0, 0, 0).body(26, -5, 0).head(-10, 0, 0)
            .ra(-30, -8, 10).elbows(4, 60).la(20, 0, -30)
            .rl(25, 0, 5).ll(-40, 0, -5).knees(20, 50).off(0, 0, 0.35F);

    private static final Pose KNEELING = new Pose()
            .body(18, 0, 0).head(30, 0, 0)
            .ra(10, 0, 12).elbows(5, 20).la(10, 0, -12)
            .rl(0, 0, 4).ll(-5, 0, -4).knees(95, 95)
            .off(0, 0, 0.3F);

    private static final Pose FACE_DOWN = new Pose()
            .head(-30, 20, 0)
            .ra(-160, 0, 30).la(-150, 0, -30).elbows(30, 50)
            .rl(0, 0, 6).ll(0, 0, -8).knees(10, 25)
            .root(5, 90, 0).off(0, 0.14F, 0.35F);

    /** Iai: congela, cai de joelhos e tomba de cara no chão. */
    public static final Clip KNEEL_COLLAPSE = Clip.build("a_kneel_collapse")
            .key(0, FROZEN)
            .key(4, Pose.from(FROZEN).body(28, -5, 0).head(-5, 0, 0))
            .key(9, KNEELING, Ease.IN)
            .key(16, Pose.from(KNEELING).body(28, 0, 0).head(40, 0, 0))
            .key(22, FACE_DOWN, Ease.IN)
            .key(24, Pose.from(FACE_DOWN).off(0, 0.2F, 0.35F))
            .key(26, FACE_DOWN)
            .done();

    private static final Pose LYING_BACK = new Pose()
            .head(-10, 15, 0)
            .ra(-150, 0, 40).la(-150, 0, -30).elbows(40, 20)
            .rl(-10, 0, 10).ll(-25, 0, -8).knees(20, 40)
            .root(0, -90, 0)
            .off(0, 0.14F, -0.65F);

    /** Queda de costas. */
    public static final Clip FALL_BACK = Clip.build("a_fall_back")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(0, -20, 0).body(-30, 0, 0).head(-30, 0, 0)
                    .ra(-120, 0, 45).la(-120, 0, -40).elbows(30, 30).knees(30, 30).off(0, 0.05F, -0.3F), Ease.OUT)
            .key(9, LYING_BACK, Ease.IN)
            .key(11, Pose.from(LYING_BACK).off(0, 0.22F, -0.67F))
            .key(13, LYING_BACK)
            .done();

    private static final Pose LYING_SPUN = Pose.from(LYING_BACK).root(430, -90, 0).off(0.3F, 0.14F, -0.75F)
            .head(0, 30, 0).rl(-5, 0, 20).ll(-30, 0, -3).knees(15, 60);

    /** Lançado girando (corte giratório). */
    public static final Clip FALL_SPIN = Clip.build("a_fall_spin")
            .key(0, GUARD)
            .key(4, Pose.from(GUARD).root(200, -30, 15).body(-20, 20, 0).head(-20, 0, 0)
                    .ra(-100, 0, 70).la(-100, 0, -70).elbows(20, 20)
                    .knees(50, 20).off(0.1F, 0.35F, -0.5F), Ease.OUT)
            .key(10, LYING_SPUN, Ease.IN)
            .key(12, Pose.from(LYING_SPUN).off(0.3F, 0.22F, -0.77F))
            .key(14, LYING_SPUN)
            .done();

    /** Vê o jogador disparando contra ele: recua o pé, fecha a guarda, assustado. */
    public static final Clip BRACE = Clip.build("a_brace")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(18, 0, 0).body(-6, -12, 0).head(-12, 8, 0)
                    .ra(-72, -14, 8).elbows(22, 70).la(-40, 25, -15)
                    .rl(26, 0, 6).ll(-22, 0, -5).knees(36, 30).off(0, -0.03F, -0.12F), Ease.OUT)
            .key(8, Pose.from(GUARD).root(18, 0, 0).body(2, -12, 0).head(-8, 8, 0)
                    .ra(-66, -14, 8).elbows(20, 66).la(-38, 25, -14)
                    .rl(24, 0, 6).ll(-22, 0, -5).knees(40, 36).off(0, -0.04F, -0.12F))
            .done();

    private static final Pose BRACED = Pose.from(GUARD).root(18, 0, 0).body(2, -12, 0).head(-8, 8, 0)
            .ra(-66, -14, 8).elbows(20, 66).la(-38, 25, -14)
            .rl(24, 0, 6).ll(-22, 0, -5).knees(40, 36).off(0, -0.04F, -0.12F);

    public static final Clip BRACED_IDLE = Clip.build("a_braced_idle")
            .key(0, BRACED).key(6, Pose.from(BRACED).body(4, -12, 0).knees(43, 39)).key(12, BRACED)
            .loop().done();

    /** Ergue a espada acima da cabeça, desesperado, esperando o jogador chegar. */
    public static final Clip RAISE_OVERHEAD = Clip.build("a_raise_overhead")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).body(-2, 0, 0).ra(-120, 5, 12).elbows(20, 60).off(0, 0, -0.05F))
            .key(6, OVERHEAD)
            .done();

    /** Usado pelo construtor de coreografias para aproximações curtas. */
    public static final Clip ADVANCE = RUN_IN;

    /** Clipe tocado quando o atual termina (sem ter sido derrotado). */
    public static Clip followUp(Clip finished) {
        if (finished == RUN_IN || finished == OVERHEAD_HOLD || finished == RAISE_OVERHEAD) return OVERHEAD_HOLD;
        if (finished == BRACE || finished == BRACED_IDLE) return BRACED_IDLE;
        if (finished == DISARMED || finished == EMPTY_IDLE) return EMPTY_IDLE;
        if (finished == SLAPPED || finished == DAZED_IDLE) return DAZED_IDLE;
        if (finished == BLOCK_HIGH) return GUARD_IDLE;
        return GUARD_IDLE;
    }
}
