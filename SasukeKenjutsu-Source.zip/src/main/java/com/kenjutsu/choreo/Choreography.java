package com.kenjutsu.choreo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Uma luta 1v1 completa: etapas disparadas por clique (ou encadeadas). */
public final class Choreography {

    /** Nome do combo (mostrado ao ativar). */
    public final String name;
    public final float startRadius;
    private final List<Step> steps;

    public Choreography(String name, float startRadius, List<Step> steps) {
        this.name = name;
        this.startRadius = startRadius;
        this.steps = Collections.unmodifiableList(new ArrayList<Step>(steps));
        validate();
    }

    public int actorCount() {
        return 1;
    }

    public float angle(int actor) {
        return 0.0F;
    }

    public List<Step> steps() {
        return steps;
    }

    public int totalTicks() {
        int t = 0;
        for (Step s : steps) t += s.duration;
        return t;
    }

    /** Garante que o roteiro termina com o adversário derrotado e sem ações impossíveis. */
    private void validate() {
        if (steps.isEmpty()) throw new IllegalStateException("coreografia vazia: " + name);
        boolean defeated = false;
        for (int si = 0; si < steps.size(); si++) {
            Step s = steps.get(si);
            if (s.face > 0) throw new IllegalStateException(name + " etapa " + (si + 1) + ": alvo inexistente");
            for (ActorAction a : s.actions()) {
                if (a.actor != 0) throw new IllegalStateException(name + " etapa " + (si + 1) + ": ator inexistente");
                if (defeated && a.clip != null) {
                    throw new IllegalStateException(name + " etapa " + (si + 1) + ": ator já derrotado");
                }
                if (a.delay >= s.duration) {
                    throw new IllegalStateException(name + " etapa " + (si + 1) + ": atraso maior que a etapa");
                }
                if (a.defeat) defeated = true;
            }
        }
        if (!defeated) throw new IllegalStateException(name + ": adversário nunca é derrotado");
    }
}
