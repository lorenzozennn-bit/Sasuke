package com.kenjutsu.choreo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Uma luta 1v1 completa: etapas disparadas por clique (ou encadeadas). */
public final class Choreography {

    public final String name;
    /** Posição inicial do adversário na arena (o jogador começa em 0,0). */
    public final float actorX, actorZ;
    private final List<Step> steps;

    public Choreography(String name, float actorX, float actorZ, List<Step> steps) {
        this.name = name;
        this.actorX = actorX;
        this.actorZ = actorZ;
        this.steps = Collections.unmodifiableList(new ArrayList<Step>(steps));
        if (this.steps.isEmpty()) throw new IllegalArgumentException("luta sem etapas: " + name);
        for (Step s : this.steps) {
            for (ActorAction a : s.actions()) {
                if (a.delay < 0 || a.delay > s.duration + 40) {
                    throw new IllegalArgumentException("atraso inválido em " + name);
                }
            }
        }
        if (!this.steps.get(this.steps.size() - 1).actions().stream().anyMatch(a -> a.defeat)) {
            throw new IllegalArgumentException("a última etapa precisa derrotar o adversário: " + name);
        }
    }

    public int actorCount() {
        return 1;
    }

    public List<Step> steps() {
        return steps;
    }
}
