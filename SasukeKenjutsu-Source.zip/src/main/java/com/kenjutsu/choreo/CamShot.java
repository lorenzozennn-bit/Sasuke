package com.kenjutsu.choreo;

/**
 * Planos de câmera da luta. Cada plano é calculado ao vivo a partir das
 * posições dos dois lutadores, com o eixo da cena fixado no instante do corte
 * (a câmera nunca "pula" para o outro lado quando eles se cruzam).
 */
public enum CamShot {
    /** Plano aberto e alto, de lado: o campo inteiro (as investidas do vídeo). */
    WIDE,
    /** Lateral na altura do peito, acompanhando os dois. */
    SIDE,
    /** Câmera baixa, quase no chão, olhando para cima no choque. */
    LOW,
    /** Atrás do seu ombro, olhando o adversário. */
    SHOULDER,
    /** Close no seu personagem, de frente. */
    FRONT,
    /** Perseguição: atrás e ao lado durante a arrancada. */
    CHASE,
    /** Do alto, quase de cima, enquanto se rodeiam. */
    TOP,
    /** Órbita lenta em volta do vencedor. */
    ORBIT
}
