package com.kenjutsu.choreo;

/** Como a luta se adapta ao espaço disponível. */
public final class FightOptions {

    /** Nome mostrado ao jogador. */
    public final String name;
    /** Escala dos deslocamentos (investidas, deslizes, arremessos). As distâncias de golpe não mudam. */
    public final float space;
    /** Saltos e lançamento ao alto (precisam de céu aberto). */
    public final boolean aerial;
    /** Rodeio largo e câmera do alto. */
    public final boolean wide;

    public FightOptions(String name, float space, boolean aerial, boolean wide) {
        this.name = name;
        this.space = space;
        this.aerial = aerial;
        this.wide = wide;
    }

    public static final FightOptions OPEN = new FightOptions("campo aberto", 1.0F, true, true);
    public static final FightOptions MEDIUM = new FightOptions("espaço médio", 0.62F, true, false);
    public static final FightOptions TIGHT_HIGH = new FightOptions("espaço apertado", 0.38F, true, false);
    public static final FightOptions TIGHT_LOW = new FightOptions("apertado, sem saltos", 0.38F, false, false);
    public static final FightOptions MEDIUM_LOW = new FightOptions("espaço médio, sem saltos", 0.62F, false, false);

    public static final FightOptions[] TIERS = {OPEN, MEDIUM, MEDIUM_LOW, TIGHT_HIGH, TIGHT_LOW};
}
