package com.kenjutsu.choreo;

import com.kenjutsu.anim.Clip;
import com.kenjutsu.anim.Ease;
import com.kenjutsu.anim.Pose;

/**
 * Kenjutsu do jogador, estilo Sasuke (era Boruto): espada SÓ na mão direita,
 * braço esquerdo vivo (equilíbrio, impulso, contrapeso), postura ereta e
 * arrogante, golpes de uma passada só.
 *
 * Mecânica da pegada do Minecraft: a lâmina é perpendicular ao antebraço e o
 * seu ângulo de elevação acompanha o do braço (braço pendurado = lâmina para
 * frente; braço à frente = lâmina para cima; acima da cabeça = para trás).
 * Por isso os cortes são ARCOS do braço inteiro; o rolamento do ombro (z)
 * inclina o plano do corte: z≈0 vertical, z≈35 diagonal, z=±90 horizontal.
 *
 * Os ticks de impacto anotados são verificados por ferramenta: a lâmina cruza
 * o tronco do adversário (a ~1,35 bloco) exatamente nesse tick.
 */
public final class PlayerClips {

    private PlayerClips() {
    }

    // ================================================================ postura

    /** Ereto e de perfil, queixo erguido, lâmina baixa apontando para o chão à frente. */
    public static final Pose GUARD = new Pose()
            .root(-22, 0, 0)
            .body(6, 10, 0)
            .head(-4, -8, 0)
            .ra(18, -12, 8).elbows(10, 22)
            .la(-6, 6, -14)
            .ll(-18, 0, -5).rl(14, 0, 8)
            .knees(26, 28);

    private static final Pose GUARD_BREATH = Pose.from(GUARD)
            .body(8, 10, 0).ra(16, -12, 8).la(-8, 6, -15).knees(30, 31);

    public static final Clip GUARD_IDLE = Clip.build("p_guard_idle")
            .key(0, GUARD).key(14, GUARD_BREATH).key(28, GUARD)
            .loop().done();

    // ================================================================ cortes

    /**
     * Corte descendente diagonal (kesagiri): do alto, à direita, para baixo à
     * esquerda, com avanço. Impacto: tick 4.
     */
    public static final Clip SLASH_DOWN = Clip.build("p_slash_down")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(-30, 0, 0).body(-10, 25, 0).head(-14, -20, 0)
                    .ra(-172, 10, 32).elbows(12, 35).la(-45, 10, -15)
                    .ll(-18, 0, -4).rl(12, 0, 6).knees(20, 18).off(0, 0, 0.05F), Ease.OUT)
            .key(4, Pose.from(GUARD).root(-10, 0, 0).body(18, -18, 0).head(-12, 15, 0)
                    .ra(-62, -12, 28).elbows(5, 20).la(25, 0, -28)
                    .ll(-40, 0, -4).rl(28, 0, 6).knees(48, 28).off(0, 0, 0.42F), Ease.OUT)
            .key(6, Pose.from(GUARD).root(-8, 0, 0).body(24, -28, 0).head(-12, 22, 0)
                    .ra(-12, -25, 26).elbows(2, 20).la(30, 0, -30)
                    .ll(-40, 0, -4).rl(28, 0, 6).knees(50, 30).off(0, 0, 0.45F))
            .key(12, GUARD)
            .done();

    /** Corte ascendente (kiriage): de baixo para cima, na diagonal. Impacto: tick 3. */
    public static final Clip SLASH_UP = Clip.build("p_slash_up")
            .key(0, GUARD)
            .key(1, Pose.from(GUARD).root(-12, 0, 0).body(20, -15, 0).head(-14, 10, 0)
                    .ra(40, -35, -15).elbows(4, 18).la(15, 0, -25).knees(40, 30).off(0, 0, 0.15F))
            .key(3, Pose.from(GUARD).root(-25, 0, 0).body(9, 9, 0).head(-20, -10, 0)
                    .ra(-51, -53, -18).elbows(9, 30).la(-25, 0, -30)
                    .ll(-35, 0, -4).rl(20, 0, 6).knees(30, 18).off(0, 0.04F, 0.4F), Ease.OUT)
            .key(5, Pose.from(GUARD).root(-32, 0, 0).body(-12, 30, 0).head(-25, -22, 0)
                    .ra(-140, -30, 10).elbows(10, 30).la(-25, 0, -35)
                    .ll(-35, 0, -4).rl(20, 0, 6).knees(22, 12).off(0, 0.05F, 0.42F))
            .key(11, GUARD)
            .done();

    /** Corte horizontal (yokogiri) da direita para a esquerda, na altura do peito. Impacto: tick 3. */
    public static final Clip SLASH_HORIZ = Clip.build("p_slash_horiz")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(-45, 0, 0).body(4, 35, 0).head(-12, -40, 0)
                    .ra(55, 0, 90).elbows(10, 30).la(-45, 25, -20).knees(28, 22).off(0, 0, 0.08F), Ease.OUT)
            .key(3, Pose.from(GUARD).root(-22, 0, 0).body(14, 0, 0).head(-10, -5, 0)
                    .ra(-40, 0, 90).elbows(12, 25).la(10, 0, -25)
                    .ll(-35, 0, -4).rl(22, 0, 6).knees(38, 26).off(0, 0, 0.42F), Ease.OUT)
            .key(5, Pose.from(GUARD).root(-5, 0, 0).body(16, -40, 0).head(-10, 35, 0)
                    .ra(-155, 0, 90).elbows(12, 25).la(35, 0, -35)
                    .ll(-35, 0, -4).rl(22, 0, 6).knees(40, 28).off(0, 0, 0.45F))
            .key(11, GUARD)
            .done();

    /** Corte giratório 360° na horizontal (finalização). Impacto: tick 6. */
    public static final Clip SPIN_SLASH = Clip.build("p_spin_slash")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(-40, 0, 0).body(12, 30, 0).head(-14, -30, 0)
                    .ra(40, 0, 90).elbows(10, 25).la(-40, 0, -30).knees(55, 45))
            .key(4, Pose.from(GUARD).yaw(-210).body(10, 0, 0).head(-12, 0, 0)
                    .ra(-20, 0, 90).elbows(8, 25).la(-20, 0, -75).knees(35, 30).off(0, 0.1F, 0.15F))
            .key(6, Pose.from(GUARD).yaw(-365).body(15, -10, 0).head(-10, 10, 0)
                    .ra(-60, 0, 90).elbows(10, 25).la(10, 0, -60)
                    .ll(-30, 0, -4).rl(20, 0, 6).knees(40, 30).off(0, 0.04F, 0.4F), Ease.OUT)
            .key(8, Pose.from(GUARD).yaw(-385).body(18, -45, 0).head(-10, 40, 0)
                    .ra(-150, 0, 90).elbows(10, 25).la(35, 0, -40).knees(45, 32).off(0, 0, 0.42F))
            .key(14, Pose.from(GUARD).yaw(-380))
            .done();

    /** Estocada baixa (gedan-tsuki) no abdômen, com o corpo inteiro avançando. Impacto: tick 4. */
    public static final Clip THRUST = Clip.build("p_thrust")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(-40, 0, 0).body(0, 30, 0).head(-14, -30, 0)
                    .ra(45, 0, 8).elbows(30, 20).la(-30, 0, -20).knees(45, 30).off(0, 0, -0.08F))
            .key(4, Pose.from(GUARD).root(-12, 0, 0).body(10, -15, 0).head(-14, 10, 0)
                    .ra(-28, -4, 2).elbows(4, 20).la(40, 0, -30)
                    .ll(-55, 0, -4).rl(32, 0, 6).knees(60, 20).off(0, 0, 0.62F), Ease.OUT)
            .key(7, Pose.from(GUARD).root(-12, 0, 0).body(9, -15, 0).head(-14, 10, 0)
                    .ra(-28, -4, 2).elbows(4, 20).la(40, 0, -30)
                    .ll(-55, 0, -4).rl(32, 0, 6).knees(60, 20).off(0, 0, 0.6F))
            .key(13, GUARD)
            .done();

    // ============================================================ defensiva

    /** Apara de lado: lâmina vertical diante do corpo. Contato: tick 2. */
    public static final Clip PARRY_SIDE = Clip.build("p_parry_side")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(-15, 0, 0).body(4, -12, 0).head(-12, 10, 0)
                    .ra(-82, 22, 4).elbows(10, 20).la(15, 0, -20).knees(18, 18), Ease.OUT)
            .key(3, Pose.from(GUARD).root(-15, 0, 0).body(1, -8, 0).head(-12, 10, 0)
                    .ra(-80, 26, 4).elbows(12, 20).la(18, 0, -22).knees(22, 22).off(0, 0, -0.08F))
            .key(7, Pose.from(GUARD).root(-15, 0, 0).body(2, -10, 0).head(-12, 10, 0)
                    .ra(-80, 24, 4).elbows(12, 20).la(16, 0, -20).knees(20, 20).off(0, 0, -0.06F))
            .key(12, GUARD)
            .done();

    /** Apara alta: lâmina horizontal acima da cabeça. Contato: tick 2. */
    public static final Clip PARRY_HIGH = Clip.build("p_parry_high")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(-20, 0, 0).body(-2, 8, 0).head(-22, -5, 0)
                    .ra(-134, 70, 28).elbows(17, 20).la(10, 0, -15).knees(25, 25), Ease.OUT)
            .key(3, Pose.from(GUARD).root(-20, 0, 0).body(-4, 8, 0).head(-22, -5, 0)
                    .ra(-132, 70, 28).elbows(20, 20).la(12, 0, -18).knees(34, 34))
            .key(7, Pose.from(GUARD).root(-20, 0, 0).body(-3, 8, 0).head(-22, -5, 0)
                    .ra(-133, 70, 28).elbows(19, 20).la(10, 0, -16).knees(28, 28))
            .key(11, GUARD)
            .done();

    /** Desarme: arco ascendente curto e seco contra a lâmina dele. Contato: tick 2. */
    public static final Clip FLICK_DISARM = Clip.build("p_flick_disarm")
            .key(0, GUARD)
            .key(1, Pose.from(GUARD).root(-15, 0, 0).body(17, -14, 0).ra(-2, -6, -10).elbows(4, 14)
                    .knees(28, 22).off(0, 0, 0.1F))
            .key(2, Pose.from(GUARD).root(-25, 0, 0).body(6, 10, 0).head(-16, -15, 0)
                    .ra(-70, -38, 2).elbows(4, 20).la(-15, 0, -25).knees(15, 12).off(0, 0, 0.18F), Ease.OUT)
            .key(5, Pose.from(GUARD).root(-25, 0, 0).body(4, 9, 0).head(-16, -15, 0)
                    .ra(-104, -32, -10).elbows(4, 20).la(-15, 0, -25).knees(12, 10).off(0, 0, 0.16F))
            .key(10, GUARD)
            .done();

    /** Desvio mínimo, só tronco e cabeça; a espada continua baixa. */
    public static final Clip SLIP = Clip.build("p_slip")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(-20, 0, -10).body(-2, 8, -14).head(-12, -15, -18)
                    .off(-0.25F, 0, -0.04F), Ease.OUT)
            .key(7, Pose.from(GUARD).root(-20, 0, -9).body(-2, 8, -13).head(-12, -15, -16)
                    .off(-0.23F, 0, -0.04F))
            .key(10, GUARD)
            .done();

    /** Desvio inclinando o tronco para trás; a espada continua baixa. */
    public static final Clip LEAN_BACK = Clip.build("p_lean_back")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).body(-35, 8, 0).head(20, -10, 0)
                    .la(-30, 0, -45).elbows(4, 30).ll(-30, 0, -4).rl(10, 0, 6).knees(50, 60)
                    .off(0, 0, -0.12F), Ease.OUT)
            .key(7, Pose.from(GUARD).body(-33, 8, 0).head(18, -10, 0)
                    .la(-30, 0, -45).elbows(4, 30).ll(-30, 0, -4).rl(10, 0, 6).knees(50, 60)
                    .off(0, 0, -0.12F))
            .key(11, GUARD)
            .done();

    /** Passo lateral para fora da linha do ataque. */
    public static final Clip SIDESTEP = Clip.build("p_sidestep")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(-35, 0, 8).body(6, 20, 6).head(-12, -25, 0)
                    .la(-20, 0, -30).knees(35, 25).off(0.6F, 0, 0), Ease.OUT)
            .key(7, Pose.from(GUARD).root(-35, 0, 6).body(5, 20, 5).head(-12, -25, 0)
                    .la(-18, 0, -28).knees(32, 22).off(0.58F, 0, 0))
            .key(11, GUARD)
            .done();

    /** Tapa com o lado chato da lâmina (horizontal) na cabeça dele. Impacto: tick 3. */
    public static final Clip FLAT_SLAP = Clip.build("p_flat_slap")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(-35, 0, 0).body(-2, 30, 0).head(-12, -30, 0)
                    .ra(-5, 0, 105).elbows(10, 14).la(-15, 0, -20).off(0, 0, 0.05F))
            .key(3, Pose.from(GUARD).root(-18, 0, 0).body(6, -5, 0).head(-12, 5, 0)
                    .ra(-72, 0, 98).elbows(10, 14).la(15, 0, -25).off(0, 0, 0.32F), Ease.OUT)
            .key(6, Pose.from(GUARD).root(-15, 0, 0).body(6, -20, 0).head(-12, 15, 0)
                    .ra(-100, 0, 95).elbows(10, 14).la(18, 0, -25).off(0, 0, 0.3F))
            .key(11, GUARD)
            .done();

    /** Chute frontal com a espada baixa. Impacto: tick 3. */
    public static final Clip FRONT_KICK = Clip.build("p_front_kick")
            .key(0, GUARD)
            .key(1, Pose.from(GUARD).root(-15, 0, 0).body(0, 8, 0).rl(-85, 0, 0).ll(-5, 0, -4).knees(110, 18)
                    .la(-20, 0, -30))
            .key(3, Pose.from(GUARD).root(-15, 0, 0).body(-14, 8, 0).head(5, -10, 0)
                    .rl(-92, 0, 0).ll(0, 0, -4).knees(0, 15).la(-30, 0, -35).off(0, 0, 0.22F), Ease.OUT)
            .key(5, Pose.from(GUARD).root(-15, 0, 0).body(-12, 8, 0).head(5, -10, 0)
                    .rl(-90, 0, 0).ll(0, 0, -4).knees(5, 15).la(-30, 0, -35).off(0, 0, 0.21F))
            .key(7, Pose.from(GUARD).root(-15, 0, 0).body(0, 8, 0).rl(-80, 0, 0).ll(-5, 0, -4).knees(105, 18)
                    .off(0, 0, 0.1F))
            .key(11, GUARD)
            .done();

    // ============================================================ corrida

    /** Passada da corrida anime: tronco muito inclinado, olhar fixo no alvo, espada arrastada baixa atrás. */
    private static Pose stride(boolean rightLegFront, float lift) {
        return new Pose()
                .root(0, 0, rightLegFront ? -3 : 3)
                .body(42, rightLegFront ? -6 : 6, 0)
                .head(-46, 0, 0)
                .ra(38, 172, 20).elbows(14, 30)
                .la(58, -6, -14)
                .rl(rightLegFront ? -72 : 48, 0, 4).ll(rightLegFront ? 48 : -72, 0, -4)
                .knees(rightLegFront ? 62 : 95, rightLegFront ? 95 : 62)
                .off(0, lift, 0);
    }

    /** Agachamento de arrancada (antecipação curtíssima). */
    private static final Pose LAUNCH = new Pose()
            .root(-8, 0, 0).body(34, 4, 0).head(-38, -4, 0)
            .ra(30, 150, 22).elbows(14, 40).la(30, 0, -18)
            .rl(-38, 0, 4).ll(30, 0, -4).knees(95, 70)
            .off(0, -0.12F, 0);

    /** Freada com o pé da frente cravado: o corpo ainda carrega o embalo, pronto para cortar. */
    public static final Pose PLANT = new Pose()
            .root(-14, 0, 0).body(26, 10, 0).head(-26, -10, 0)
            .ra(50, -2, 18).elbows(10, 30).la(-10, 0, -26)
            .ll(-58, 0, -4).rl(34, 0, 6).knees(70, 42)
            .off(0, -0.06F, 0);

    /**
     * Corrida estilo Sasuke contra o inimigo (10 ticks): arranca, três passadas
     * longas quase voando e crava o pé para o golpe. O avanço vem da coreografia
     * (Ease.RUN, mesma duração).
     */
    public static final Clip SPRINT = Clip.build("p_sprint")
            .key(0, GUARD)
            .key(1.5F, LAUNCH, Ease.OUT)
            .key(3, stride(true, 0.02F))
            .key(4.25F, stride(true, 0.14F))
            .key(5.5F, stride(false, 0.02F))
            .key(6.75F, stride(false, 0.14F))
            .key(8, stride(true, 0.03F))
            .key(10, PLANT)
            .done();

    /** Passada da caminhada arrogante: ereto, queixo erguido, espada baixa. */
    private static Pose walkStep(boolean rightFront, float up) {
        return Pose.from(GUARD).root(-14, 0, rightFront ? -2 : 2).body(-2, rightFront ? 4 : 10, 0).head(-12, -6, 0)
                .ra(rightFront ? 30 : 44, -12, 6).la(rightFront ? -14 : 18, 0, -8).elbows(6, 16)
                .rl(rightFront ? -26 : 20, 0, 4).ll(rightFront ? 20 : -26, 0, -4)
                .knees(rightFront ? 8 : 26, rightFront ? 26 : 8).off(0, up, 0);
    }

    /** Caminhada lenta e confiante em direção ao inimigo (16 ticks, duas passadas). */
    public static final Clip WALK = Clip.build("p_walk")
            .key(0, GUARD)
            .key(4, walkStep(true, 0.0F))
            .key(6, walkStep(true, 0.03F))
            .key(8, walkStep(false, 0.0F))
            .key(10, walkStep(false, 0.03F))
            .key(12, walkStep(true, 0.0F))
            .key(16, GUARD)
            .done();

    // ====================================================== estilo do vídeo

    /**
     * Empurrado pelo choque de lâminas: desliza para trás agachado, mão esquerda
     * raspando o chão, espada aberta para o lado. O deslize vem da coreografia.
     */
    private static final Pose SKID = new Pose()
            .root(-25, 0, 0).body(36, 14, 0).head(-42, -12, 0)
            .ra(-25, 165, 68).elbows(6, 8)
            .la(-28, 0, -24)
            .ll(-62, 0, -6).rl(48, 0, 10).knees(112, 58)
            .off(0, -0.36F, 0);

    public static final Clip SKID_BACK = Clip.build("p_skid_back")
            .key(0, GUARD)
            .key(2, SKID, Ease.OUT)
            .key(9, Pose.from(SKID).body(32, 14, 0).ra(-23, 165, 66).knees(108, 56))
            .key(14, GUARD)
            .done();

    /**
     * Chidori na lâmina: base baixa, espada para trás (como na corrida), mão
     * esquerda aberta à frente. Os raios são desenhados pelo cliente.
     */
    private static final Pose CHARGED = new Pose()
            .root(-28, 0, 0).body(24, 16, 0).head(-30, -16, 0)
            .ra(24, 160, 28).elbows(12, 30)
            .la(-62, 22, -8).elbows(12, 18)
            .ll(-44, 0, -6).rl(34, 0, 8).knees(74, 52)
            .off(0, -0.14F, 0);

    public static final Clip CHARGE = Clip.build("p_charge")
            .key(0, GUARD)
            .key(3, CHARGED, Ease.OUT)
            .key(8, Pose.from(CHARGED).body(26, 16, 0).la(-66, 22, -6).knees(78, 55))
            .key(12, CHARGED)
            .done();

    /**
     * Salto com corte descendente (corre, salta e desce a espada no ar).
     * Choque no ar: tick 9. O avanço vem da coreografia.
     */
    public static final Clip LEAP_SLASH = Clip.build("p_leap_slash")
            .key(0, GUARD)
            .key(2, stride(true, 0.03F))
            .key(4, stride(false, 0.03F))
            .key(5.5F, Pose.from(LAUNCH).ra(-60, 0, 14), Ease.OUT)
            .key(8, new Pose().root(-12, 0, 0).body(-14, 6, 0).head(-24, -6, 0)
                    .ra(-176, 2, 14).elbows(16, 30).la(-40, 0, -40)
                    .rl(-60, 0, 6).ll(10, 0, -6).knees(110, 70).off(0, 1.05F, 0))
            .key(9.5F, new Pose().root(-8, 0, 0).body(30, -10, 0).head(-30, 8, 0)
                    .ra(-58, -12, 24).elbows(6, 24).la(20, 0, -36)
                    .rl(-50, 0, 6).ll(20, 0, -6).knees(90, 60).off(0, 0.9F, 0.2F), Ease.OUT)
            .key(12, new Pose().root(-14, 0, 0).body(34, -14, 0).head(-34, 10, 0)
                    .ra(-14, -20, 24).elbows(4, 24).la(22, 0, -40)
                    .ll(-58, 0, -4).rl(40, 0, 6).knees(100, 60).off(0, -0.2F, 0.25F), Ease.IN)
            .key(16, GUARD)
            .done();

    /**
     * Levando um corte: tenta levantar a lâmina tarde demais, o golpe pega no
     * ombro, o corpo torce e recua; a mão esquerda vai ao ferimento e ele
     * volta à guarda. Golpe recebido: tick 4.
     */
    public static final Clip HIT_TAKEN = Clip.build("p_hit_taken")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(-18, 0, 0).body(2, 4, 0).head(-14, -4, 0)
                    .ra(-55, 18, 6).elbows(14, 24).knees(30, 30))
            .key(4.5F, Pose.from(GUARD).root(-42, 0, 7).body(-22, 32, 0).head(-22, 30, 8)
                    .ra(24, 12, 42).elbows(12, 40).la(-30, 0, -42)
                    .rl(-22, 0, 8).knees(30, 52).off(0, 0, -0.1F), Ease.OUT)
            .key(9, Pose.from(GUARD).root(-30, 0, 2).body(18, 12, 0).head(-12, 6, 0)
                    .ra(30, -8, 14).la(-62, 42, -6).elbows(12, 95).knees(52, 44))
            .key(15, GUARD)
            .done();

    /** Agarra pela gola e acerta uma joelhada no rosto, que o lança para o alto. Impacto: tick 3. */
    public static final Clip KNEE_STRIKE = Clip.build("p_knee_strike")
            .key(0, GUARD)
            .key(1.5F, Pose.from(GUARD).root(-10, 0, 0).body(14, 6, 0).head(-14, -4, 0)
                    .la(-92, 4, -6).elbows(10, 12).knees(30, 34).off(0, 0, 0.1F))
            .key(3, Pose.from(GUARD).root(-10, 0, 0).body(-4, 6, 0).head(-6, -4, 0)
                    .la(-62, 4, -6).elbows(12, 70)
                    .rl(-118, 0, 0).ll(4, 0, -4).knees(135, 18).off(0, 0.2F, 0.25F), Ease.OUT)
            .key(5, Pose.from(GUARD).root(-10, 0, 0).body(-6, 6, 0).head(-8, -4, 0)
                    .la(-40, 4, -14).elbows(12, 60)
                    .rl(-112, 0, 0).ll(4, 0, -4).knees(128, 18).off(0, 0.16F, 0.22F))
            .key(8, Pose.from(GUARD).body(10, 8, 0).knees(50, 40).off(0, 0, 0.1F), Ease.IN)
            .key(13, GUARD)
            .done();

    /** Passadas laterais rodeando o oponente, guarda firme (12 ticks, três passos). */
    public static final Clip STRAFE = Clip.build("p_strafe")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).rl(16, 0, 24).ll(-18, 0, -3).knees(36, 30).off(0, -0.03F, 0))
            .key(4, Pose.from(GUARD).rl(12, 0, 3).ll(-16, 0, -6).knees(30, 36).off(0, 0.01F, 0))
            .key(6, Pose.from(GUARD).rl(16, 0, 22).ll(-18, 0, -3).knees(36, 30).off(0, -0.03F, 0))
            .key(8, Pose.from(GUARD).rl(12, 0, 3).ll(-16, 0, -6).knees(30, 36).off(0, 0.01F, 0))
            .key(10, Pose.from(GUARD).rl(16, 0, 22).ll(-18, 0, -3).knees(36, 30).off(0, -0.03F, 0))
            .key(12, GUARD)
            .done();

    /**
     * Passe relâmpago: dispara com o Chidori, recolhe a lâmina, corta na
     * horizontal ao passar ao lado dele e derrapa baixo do outro lado.
     * Corte: tick 4. O deslocamento vem da coreografia.
     */
    public static final Clip FLASH_CUT = Clip.build("p_flash_cut")
            .key(0, stride(true, 0.03F))
            .key(2, new Pose().root(-15, 0, 0).body(30, 2, 0).head(-30, -10, 0)
                    .ra(-165, 3, 199).elbows(4, 25).la(-35, 0, -20)
                    .ll(-45, 0, -4).rl(35, 0, 6).knees(85, 70).off(0, 0.04F, 0), Ease.OUT)
            .key(4, new Pose().root(0, 0, 0).body(24, -10, 0).head(-24, 20, 0)
                    .ra(52, 40, 96).elbows(4, 30).la(30, 0, -35)
                    .ll(-55, 0, -4).rl(45, 0, 6).knees(60, 40).off(-0.55F, 0, 0), Ease.OUT)
            .key(6, new Pose().root(0, 0, 0).body(16, 11, 0).head(-20, 30, 0)
                    .ra(-125, 5, -91).elbows(4, 30).la(35, 0, -40)
                    .ll(-50, 0, -4).rl(40, 0, 6).knees(70, 48).off(-0.45F, -0.1F, 0))
            .key(10, Pose.from(SKID).off(-0.2F, -0.3F, 0))
            .done();

    /** Arrancada curta: corpo baixo, espada arrastada atrás. O avanço vem da coreografia. */
    public static final Clip DASH = Clip.build("p_dash")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(-10, 0, 0).body(30, 0, 0).head(-32, 0, 0)
                    .ra(55, 0, 14).elbows(4, 5).la(50, 0, -12)
                    .rl(-55, 0, 4).ll(40, 0, -4).knees(70, 35).off(0, 0.06F, 0))
            .key(5, Pose.from(GUARD).root(-10, 0, 0).body(32, 0, 0).head(-34, 0, 0)
                    .ra(60, 0, 14).elbows(4, 5).la(55, 0, -12)
                    .rl(40, 0, 4).ll(-55, 0, -4).knees(35, 70).off(0, 0.1F, 0))
            .key(8, Pose.from(GUARD).root(-10, 0, 0).body(30, 0, 0).head(-32, 0, 0)
                    .ra(55, 0, 14).elbows(4, 5).la(50, 0, -12)
                    .rl(-55, 0, 4).ll(40, 0, -4).knees(70, 35).off(0, 0.06F, 0))
            .key(10, Pose.from(GUARD).body(12, 8, 0).knees(30, 30))
            .done();

    /**
     * Iai atravessando o adversário: agacha com a lâmina recolhida, dispara e,
     * ao passar ao lado dele, corta na horizontal da esquerda para a direita;
     * termina de costas, imóvel, lâmina baixa. O avanço vem da coreografia.
     * Corte: tick 5.
     */
    public static final Clip IAI_DASH = Clip.build("p_iai_dash")
            .key(0, PLANT)
            .key(3, Pose.from(GUARD).root(-15, 0, 0).body(28, 2, 0).head(-28, -10, 0)
                    .ra(-165, 3, 199).elbows(4, 25).la(-35, 0, -20)
                    .ll(-45, 0, -4).rl(35, 0, 6).knees(85, 70), Ease.OUT)
            .key(5, Pose.from(GUARD).root(0, 0, 0).body(24, -10, 0).head(-24, 20, 0)
                    .ra(52, 40, 96).elbows(4, 30).la(30, 0, -35)
                    .ll(-55, 0, -4).rl(45, 0, 6).knees(60, 40).off(-0.55F, 0, 0), Ease.OUT)
            .key(7, Pose.from(GUARD).root(0, 0, 0).body(14, 11, 0).head(-20, 35, 0)
                    .ra(-125, 5, -91).elbows(4, 30).la(35, 0, -40)
                    .ll(-50, 0, -4).rl(40, 0, 6).knees(65, 45).off(-0.5F, 0, 0))
            .key(12, Pose.from(GUARD).root(0, 0, 0).body(4, 10, 0).head(-14, 10, 0)
                    .ra(-152, 11, -142).elbows(4, 15).la(5, 0, -10).knees(35, 30).off(-0.25F, 0, 0))
            .key(20, Pose.from(GUARD).root(0, 0, 0).body(-2, 0, 0).head(-14, 0, 0)
                    .ra(40, -12, 4).elbows(4, 14).la(4, 0, -9).knees(8, 10))
            .done();

    /** De costas após o iai: imóvel, lâmina baixa, sem olhar para trás. */
    public static final Pose IAI_END = Pose.from(GUARD).root(0, 0, 0).body(-2, 0, 0).head(-14, 0, 0)
            .ra(40, -12, 4).elbows(4, 14).la(4, 0, -9).knees(8, 10);

    public static final Clip IAI_HOLD = Clip.build("p_iai_hold")
            .key(0, IAI_END).key(14, Pose.from(IAI_END).body(-3, 0, 0).knees(10, 12)).key(28, IAI_END)
            .loop().done();

    // ============================================================= vitória

    /** Chiburi (sacode a lâmina para baixo) e fica imóvel, queixo erguido. */
    public static final Pose VICTORY_POSE = Pose.from(GUARD).root(-10, 0, 0).body(-4, 5, 0).head(-14, -5, 0)
            .ra(42, -10, 10).elbows(4, 14).la(4, 0, -8).knees(4, 6);

    public static final Clip VICTORY = Clip.build("p_victory")
            .key(0, GUARD)
            .key(4, Pose.from(GUARD).ra(-70, 0, 10).elbows(10, 14))
            .key(6, Pose.from(GUARD).ra(45, -10, 12).elbows(4, 14), Ease.OUT)
            .key(14, VICTORY_POSE)
            .key(40, Pose.from(VICTORY_POSE).body(-5, 5, 0))
            .done();

    /** Clipe tocado quando o atual termina. */
    public static Clip followUp(Clip finished) {
        if (finished == IAI_DASH || finished == IAI_HOLD) return IAI_HOLD;
        return GUARD_IDLE;
    }
}
