package com.kenjutsu.choreo;

import com.kenjutsu.anim.Clip;
import com.kenjutsu.anim.Ease;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Uma etapa da luta, disparada por um clique (ou encadeada à anterior).
 * Posições em coordenadas da arena: f (frente do jogador ao ativar) e r
 * (direita), em blocos. Os dois lutadores se viram um para o outro sozinhos.
 */
public final class Step {

    public final int duration;
    public final Clip playerClip;
    private boolean chain;
    private boolean lockFacing;
    private int lightFrom = -1, lightTo = -1;
    private final List<ActorAction> actions = new ArrayList<ActorAction>();
    private final List<Move> moves = new ArrayList<Move>();

    public Step(int duration, Clip playerClip) {
        if (duration <= 0) throw new IllegalArgumentException("duração inválida");
        this.duration = duration;
        this.playerClip = playerClip;
    }

    // ------------------------------------------------------------ deslocamento

    /** O jogador vai até (x, z) da arena. */
    public Step p(float x, float z, int delay, int ticks, Ease ease) {
        moves.add(new Move(Move.Who.PLAYER, x, z, 0, delay, ticks, ease));
        return this;
    }

    /** O adversário vai até (x, z) da arena. */
    public Step a(float x, float z, int delay, int ticks, Ease ease) {
        moves.add(new Move(Move.Who.ACTOR, x, z, 0, delay, ticks, ease));
        return this;
    }

    /** Os dois giram em volta do ponto médio entre eles (rodeando-se). */
    public Step orbit(float deg, int delay, int ticks) {
        moves.add(new Move(Move.Who.ORBIT, 0, 0, deg, delay, ticks, Ease.SMOOTH));
        return this;
    }

    public List<Move> moves() {
        return Collections.unmodifiableList(moves);
    }

    // ------------------------------------------------------------ modificadores

    public Step chain() {
        chain = true;
        return this;
    }

    public boolean chainsToNext() {
        return chain;
    }

    /** Congela a direção dos dois nesta etapa (ex.: quando um passa pelo outro). */
    public Step lockFacing() {
        lockFacing = true;
        return this;
    }

    public boolean locksFacing() {
        return lockFacing;
    }

    /** Chidori na lâmina entre os ticks indicados. */
    public Step lightning(int from, int to) {
        lightFrom = from;
        lightTo = to;
        return this;
    }

    public boolean hasLightning() {
        return lightFrom >= 0;
    }

    public int lightningFrom() {
        return lightFrom;
    }

    public int lightningTo() {
        return lightTo;
    }

    // ------------------------------------------------------------ adversário

    public List<ActorAction> actions() {
        return Collections.unmodifiableList(actions);
    }

    public Step act(Clip clip, int delay) {
        actions.add(new ActorAction(0, clip, delay, Float.NaN, Float.NaN, 0, ImpactType.NONE, false));
        return this;
    }

    public Step act(Clip clip, int delay, ImpactType impact) {
        actions.add(new ActorAction(0, clip, delay, Float.NaN, Float.NaN, 0, impact, false));
        return this;
    }

    public Step fx(ImpactType impact, int delay) {
        actions.add(new ActorAction(0, null, delay, Float.NaN, Float.NaN, 0, impact, false));
        return this;
    }

    /** Golpe final: toca a queda, é arremessado até (x, z) e permanece caído. */
    public Step defeat(Clip fall, int delay, ImpactType impact, float x, float z, int flightTicks) {
        actions.add(new ActorAction(0, fall, delay, x, z, flightTicks, impact, true));
        return this;
    }
}
