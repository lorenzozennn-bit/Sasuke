package com.kenjutsu.choreo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import static com.kenjutsu.choreo.ImpactType.CLASH;
import static com.kenjutsu.choreo.ImpactType.DISARM;
import static com.kenjutsu.choreo.ImpactType.HEAVY;
import static com.kenjutsu.choreo.ImpactType.KICK;
import static com.kenjutsu.choreo.ImpactType.MISS;
import static com.kenjutsu.choreo.ImpactType.SLASH;

/**
 * Os quatro combos de kenjutsu (1v1), sorteados a cada ativação.
 *
 * Distâncias: o raio do adversário é medido da posição real do jogador; o
 * jogador avança (corrida/estocada) e a distância entre os dois é
 * raio − avanço. Contato de espada ≈ 1,35 bloco.
 *
 * Os ticks de impacto de cada clipe do jogador foram verificados por
 * ferramenta (a lâmina atravessa o tronco do adversário nesse instante):
 * SLASH_DOWN 3, SLASH_UP 2, SLASH_HORIZ 3, SPIN_SLASH 6, THRUST 4,
 * FLAT_SLAP 3, FLICK_DISARM 2, PARRY_* contato 2.
 * Golpes do adversário chegam no tick 4 (OVERHEAD_STRIKE, HORIZ_STRIKE).
 */
public final class ChoreographyLibrary {

    private static List<Choreography> list;

    private ChoreographyLibrary() {
    }

    public static synchronized List<Choreography> variants() {
        if (list == null) {
            List<Choreography> l = new ArrayList<Choreography>();
            l.add(iai());
            l.add(disarm());
            l.add(storm());
            l.add(humiliation());
            list = Collections.unmodifiableList(l);
        }
        return list;
    }

    /** Sorteia um combo diferente do anterior. */
    public static int pickIndex(Random random, int previous) {
        int n = variants().size();
        if (n <= 1) return 0;
        boolean valid = previous >= 0 && previous < n;
        int i = random.nextInt(n - (valid ? 1 : 0));
        if (valid && i >= previous) i++;
        return i;
    }

    private static Step s(int duration, com.kenjutsu.anim.Clip player) {
        return new Step(duration, player, 0, 3);
    }

    /**
     * Iai — Corte Relâmpago. Ele vem correndo com a espada erguida; você nem se
     * mexe. No último instante dispara, passa ao lado dele cortando e para de
     * costas. Um segundo depois ele cai de joelhos e tomba. Um corte só.
     */
    private static Choreography iai() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(12, null).act(0, ActorClips.RUN_IN, 0).move(0, 2.45F, 0, 11));
        st.add(s(32, PlayerClips.IAI_DASH)
                .advance(4.7F, 3, 5)
                .act(0, ActorClips.OVERHEAD_STRIKE, 1).fx(0, MISS, 5)
                .defeat(0, ActorClips.KNEEL_COLLAPSE, 14, HEAVY, 2.45F, 1));
        return new Choreography("Iai", 6.0F, st);
    }

    /**
     * Desarme. Apara o golpe dele sem esforço, arranca a espada da mão dele com
     * um corte seco e o atravessa com uma estocada.
     */
    private static Choreography disarm() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(12, null).act(0, ActorClips.RUN_IN, 0).move(0, 1.6F, 0, 11));
        st.add(s(12, PlayerClips.PARRY_SIDE)
                .act(0, ActorClips.HORIZ_STRIKE, 0).fx(0, CLASH, 3)
                .act(0, ActorClips.RECOIL, 4).move(0, 1.9F, 4, 5));
        st.add(s(11, PlayerClips.FLICK_DISARM).advance(0.5F, 0, 3)
                .act(0, ActorClips.DISARMED, 2, DISARM).move(0, 2.2F, 2, 6));
        st.add(s(20, PlayerClips.THRUST).advance(0.8F, 0, 4)
                .defeat(0, ActorClips.FALL_BACK, 4, HEAVY, 5.0F, 9));
        return new Choreography("Desarme", 6.0F, st);
    }

    /**
     * Tempestade de lâminas. Arrancada até ele, descendente contra a lâmina dele
     * (que voa para o lado), ascendente e horizontal na armadura, e o corte
     * giratório que o arremessa.
     */
    private static Choreography storm() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(10, PlayerClips.DASH).advance(1.75F, 0, 9));
        st.add(s(6, PlayerClips.SLASH_DOWN).act(0, ActorClips.BLOCK_HIGH, 0).fx(0, CLASH, 3)
                .act(0, ActorClips.RECOIL, 4).chain());
        st.add(s(5, PlayerClips.SLASH_UP).advance(1.95F, 0, 3)
                .act(0, ActorClips.SLASHED, 2, SLASH).chain());
        st.add(s(10, PlayerClips.SLASH_HORIZ).advance(2.1F, 0, 3)
                .act(0, ActorClips.STAGGER, 3, SLASH).move(0, 3.85F, 3, 6));
        st.add(s(20, PlayerClips.SPIN_SLASH).advance(2.45F, 0, 4)
                .defeat(0, ActorClips.FALL_SPIN, 6, HEAVY, 8.5F, 10));
        return new Choreography("Tempestade", 3.2F, st);
    }

    /**
     * Humilhação. Ele ataca três vezes e você desvia sem nem levantar a espada.
     * Um tapa com o lado chato da lâmina faz a espada dele cair; um chute encerra.
     */
    private static Choreography humiliation() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(12, null).act(0, ActorClips.RUN_IN, 0).move(0, 1.6F, 0, 11));
        st.add(s(12, PlayerClips.SLIP).act(0, ActorClips.OVERHEAD_STRIKE, 0).fx(0, MISS, 4));
        st.add(s(13, PlayerClips.LEAN_BACK).act(0, ActorClips.HORIZ_STRIKE, 0).fx(0, MISS, 4));
        st.add(s(14, PlayerClips.SIDESTEP).act(0, ActorClips.OVERCOMMIT, 0).fx(0, MISS, 4));
        st.add(s(12, PlayerClips.FLAT_SLAP).advance(0.1F, 0, 3)
                .act(0, ActorClips.SLAPPED, 3, DISARM).move(0, 1.6F, 3, 6));
        st.add(s(18, PlayerClips.FRONT_KICK).advance(0.3F, 0, 3)
                .defeat(0, ActorClips.FALL_BACK, 3, KICK, 5.0F, 9));
        return new Choreography("Humilhação", 6.0F, st);
    }
}
