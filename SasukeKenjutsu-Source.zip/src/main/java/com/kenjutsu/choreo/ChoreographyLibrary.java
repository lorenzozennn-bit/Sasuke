package com.kenjutsu.choreo;

import com.kenjutsu.anim.Ease;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import static com.kenjutsu.choreo.ImpactType.CLASH;
import static com.kenjutsu.choreo.ImpactType.DISARM;
import static com.kenjutsu.choreo.ImpactType.HEAVY;
import static com.kenjutsu.choreo.ImpactType.KICK;
import static com.kenjutsu.choreo.ImpactType.MISS;
import static com.kenjutsu.choreo.ImpactType.SLASH;

/**
 * Os quatro combos de kenjutsu (1v1), sorteados a cada ativação.
 *
 * Distâncias: o raio do adversário é medido da posição real do jogador; o
 * jogador avança (corrida/estocada) e a distância entre os dois é
 * raio − avanço. Contato de espada ≈ 1,35 bloco.
 *
 * Os ticks de impacto de cada clipe do jogador foram verificados por
 * ferramenta (a lâmina atravessa o tronco do adversário nesse instante):
 * SLASH_DOWN 3, SLASH_UP 2, SLASH_HORIZ 3, SPIN_SLASH 6, THRUST 4,
 * FLAT_SLAP 3, FLICK_DISARM 2, PARRY_* contato 2.
 * Golpes do adversário chegam no tick 4 (OVERHEAD_STRIKE, HORIZ_STRIKE).
 */
public final class ChoreographyLibrary {

    private static List<Choreography> list;

    private ChoreographyLibrary() {
    }

    public static synchronized List<Choreography> variants() {
        if (list == null) {
            List<Choreography> l = new ArrayList<Choreography>();
            l.add(iai());
            l.add(disarm());
            l.add(storm());
            l.add(humiliation());
            list = Collections.unmodifiableList(l);
        }
        return list;
    }

    /** Sorteia um combo diferente do anterior. */
    public static int pickIndex(Random random, int previous) {
        int n = variants().size();
        if (n <= 1) return 0;
        boolean valid = previous >= 0 && previous < n;
        int i = random.nextInt(n - (valid ? 1 : 0));
        if (valid && i >= previous) i++;
        return i;
    }

    private static Step s(int duration, com.kenjutsu.anim.Clip player) {
        return new Step(duration, player, 0, 3);
    }

    // Todos os combos começam com VOCÊ partindo para cima: corrida de anime
    // (ou caminhada arrogante) até a distância de contato, sem parar o embalo.
    // As distâncias de contato de cada golpe são as mesmas verificadas por
    // ferramenta; só o ponto de partida ficou mais longe.

    /**
     * Iai — Corte Relâmpago. Ele te vê disparando e ergue a espada em pânico.
     * Você crava o pé, some num traço, passa ao lado dele cortando e para de
     * costas. Ele cai de joelhos e tomba. Um clique, um corte.
     */
    private static Choreography iai() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(10, PlayerClips.SPRINT).advance(5.05F, 0, 10, Ease.RUN)
                .act(0, ActorClips.RAISE_OVERHEAD, 2).chain());
        st.add(s(32, PlayerClips.IAI_DASH)
                .advance(9.75F, 3, 5)
                .act(0, ActorClips.OVERHEAD_STRIKE, 1).fx(0, MISS, 5)
                .defeat(0, ActorClips.KNEEL_COLLAPSE, 14, HEAVY, 7.5F, 1));
        return new Choreography("Iai", 7.5F, st);
    }

    /**
     * Desarme. Você avança correndo; ele tenta te parar com um golpe largo,
     * você apara sem frear, arranca a espada da mão dele e o atravessa.
     */
    private static Choreography disarm() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(10, PlayerClips.SPRINT).advance(5.4F, 0, 10, Ease.RUN)
                .act(0, ActorClips.BRACE, 1).chain());
        st.add(s(12, PlayerClips.PARRY_SIDE)
                .act(0, ActorClips.HORIZ_STRIKE, 0).fx(0, CLASH, 3)
                .act(0, ActorClips.RECOIL, 4).move(0, 7.3F, 4, 5));
        st.add(s(11, PlayerClips.FLICK_DISARM).advance(5.9F, 0, 3)
                .act(0, ActorClips.DISARMED, 2, DISARM).move(0, 7.6F, 2, 6));
        st.add(s(20, PlayerClips.THRUST).advance(6.2F, 0, 4)
                .defeat(0, ActorClips.FALL_BACK, 4, HEAVY, 10.4F, 9));
        return new Choreography("Desarme", 7.0F, st);
    }

    /**
     * Tempestade de lâminas. Corrida e, sem frear, descendente contra a guarda
     * dele, ascendente e horizontal na armadura sempre avançando, e o corte
     * giratório que o arremessa longe.
     */
    private static Choreography storm() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(10, PlayerClips.SPRINT).advance(6.05F, 0, 10, Ease.RUN)
                .act(0, ActorClips.BRACE, 1).chain());
        st.add(s(6, PlayerClips.SLASH_DOWN).act(0, ActorClips.BLOCK_HIGH, 0).fx(0, CLASH, 3)
                .act(0, ActorClips.RECOIL, 4).chain());
        st.add(s(5, PlayerClips.SLASH_UP).advance(6.25F, 0, 3)
                .act(0, ActorClips.SLASHED, 2, SLASH).chain());
        st.add(s(10, PlayerClips.SLASH_HORIZ).advance(6.4F, 0, 3)
                .act(0, ActorClips.STAGGER, 3, SLASH).move(0, 8.15F, 3, 6));
        st.add(s(20, PlayerClips.SPIN_SLASH).advance(6.75F, 0, 4)
                .defeat(0, ActorClips.FALL_SPIN, 6, HEAVY, 12.8F, 10));
        return new Choreography("Tempestade", 7.5F, st);
    }

    /**
     * Humilhação. Você caminha devagar até ele, sem levantar a espada. Ele ataca
     * três vezes; você desvia de cada um e continua andando para cima dele,
     * que vai recuando. Um tapa com o lado da lâmina arranca a espada dele e um
     * chute encerra.
     */
    private static Choreography humiliation() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(16, PlayerClips.WALK).advance(4.4F, 0, 16, Ease.LINEAR)
                .act(0, ActorClips.BRACE, 2).act(0, ActorClips.RAISE_OVERHEAD, 9).chain());
        st.add(s(12, PlayerClips.SLIP).act(0, ActorClips.OVERHEAD_STRIKE, 0).fx(0, MISS, 4)
                .advance(4.65F, 7, 5).move(0, 6.25F, 7, 5));
        st.add(s(13, PlayerClips.LEAN_BACK).act(0, ActorClips.HORIZ_STRIKE, 0).fx(0, MISS, 4)
                .advance(4.9F, 7, 5).move(0, 6.5F, 7, 5));
        st.add(s(14, PlayerClips.SIDESTEP).act(0, ActorClips.OVERCOMMIT, 0).fx(0, MISS, 4)
                .advance(5.15F, 8, 5).move(0, 6.75F, 8, 5));
        st.add(s(12, PlayerClips.FLAT_SLAP).advance(5.25F, 0, 3)
                .act(0, ActorClips.SLAPPED, 3, DISARM));
        st.add(s(18, PlayerClips.FRONT_KICK).advance(5.45F, 0, 3)
                .defeat(0, ActorClips.FALL_BACK, 3, KICK, 10.15F, 9));
        return new Choreography("Humilhação", 6.0F, st);
    }
}
