package com.kenjutsu.choreo;

import com.kenjutsu.anim.Ease;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import static com.kenjutsu.choreo.ImpactType.CLASH;
import static com.kenjutsu.choreo.ImpactType.HEAVY;
import static com.kenjutsu.choreo.ImpactType.KICK;
import static com.kenjutsu.choreo.ImpactType.MISS;
import static com.kenjutsu.choreo.ImpactType.SLASH;
import static com.kenjutsu.choreo.ImpactType.SHOCK;
import static com.kenjutsu.choreo.ImpactType.CHARGE;

/**
 * Os quatro combos de kenjutsu (1v1), sorteados a cada ativação.
 *
 * Distâncias: o raio do adversário é medido da posição real do jogador; o
 * jogador avança (corrida/estocada) e a distância entre os dois é
 * raio − avanço. Contato de espada ≈ 1,35 bloco.
 *
 * Os ticks de impacto de cada clipe do jogador foram verificados por
 * ferramenta (a lâmina atravessa o tronco do adversário nesse instante):
 * SLASH_DOWN 3, SLASH_UP 2, SLASH_HORIZ 3, SPIN_SLASH 6, THRUST 4,
 * FLAT_SLAP 3, FLICK_DISARM 2, PARRY_* contato 2.
 * Golpes do adversário chegam no tick 4 (OVERHEAD_STRIKE, HORIZ_STRIKE).
 */
public final class ChoreographyLibrary {

    private static List<Choreography> list;

    private ChoreographyLibrary() {
    }

    public static synchronized List<Choreography> variants() {
        if (list == null) {
            List<Choreography> l = new ArrayList<Choreography>();
            l.add(clash());
            l.add(chidori());
            l.add(leap());
            l.add(storm());
            list = Collections.unmodifiableList(l);
        }
        return list;
    }

    /** Sorteia um combo diferente do anterior. */
    public static int pickIndex(Random random, int previous) {
        int n = variants().size();
        if (n <= 1) return 0;
        boolean valid = previous >= 0 && previous < n;
        int i = random.nextInt(n - (valid ? 1 : 0));
        if (valid && i >= previous) i++;
        return i;
    }

    private static Step s(int duration, com.kenjutsu.anim.Clip player) {
        return new Step(duration, player, 0, 3);
    }

    // Estilo "Adult Sasuke vs Madara": os dois disparam um contra o outro e se
    // chocam no meio (faíscas, micropausa), deslizam para trás e se chocam de
    // novo; pulos com golpe de cima, chute que lança ao alto e o Chidori na
    // lâmina (raios azuis e rastro elétrico). As distâncias de contato de cada
    // golpe são as verificadas por ferramenta.

    /**
     * Choque Relâmpago. Vocês correm um contra o outro: choque horizontal no
     * meio e os dois deslizam para trás. Segunda investida: ele desce a espada
     * de cima, você bloqueia e desliza de novo. Na terceira, o Chidori acende e
     * você o atravessa com um iai elétrico.
     */
    private static Choreography clash() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(10, PlayerClips.SPRINT).advance(4.6F, 0, 10, Ease.RUN)
                .act(0, ActorClips.RUN_IN, 0).move(0, 6.6F, 0, 10)
                .act(0, ActorClips.HORIZ_STRIKE, 9).chain());
        st.add(s(6, PlayerClips.SLASH_HORIZ).fx(0, CLASH, 3).chain());
        st.add(s(14, PlayerClips.SKID_BACK).advance(3.0F, 0, 8, Ease.OUT)
                .act(0, ActorClips.RECOIL, 0).move(0, 8.0F, 0, 8));
        st.add(s(8, PlayerClips.SPRINT).advance(5.2F, 0, 8, Ease.RUN)
                .act(0, ActorClips.RUN_IN, 0).move(0, 6.9F, 0, 8)
                .act(0, ActorClips.OVERHEAD_STRIKE, 6).chain());
        st.add(s(6, PlayerClips.PARRY_HIGH).fx(0, CLASH, 2).chain());
        st.add(s(14, PlayerClips.SKID_BACK).advance(3.6F, 0, 8, Ease.OUT)
                .act(0, ActorClips.RECOIL, 0).move(0, 6.05F, 0, 8));
        st.add(s(32, PlayerClips.IAI_DASH).lightning(0, 9).fx(0, CHARGE, 0)
                .advance(8.3F, 3, 5)
                .act(0, ActorClips.OVERHEAD_STRIKE, 1).fx(0, MISS, 5)
                .defeat(0, ActorClips.KNEEL_COLLAPSE, 14, SHOCK, 6.05F, 1));
        return new Choreography("Choque Relâmpago", 12.0F, st);
    }

    /**
     * Chidori Nagashi. O Chidori acende na lâmina; você dispara com um rastro de
     * raios e o atravessa com uma estocada elétrica que o lança girando no ar.
     */
    private static Choreography chidori() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(12, PlayerClips.CHARGE).lightning(2, 60).fx(0, CHARGE, 2)
                .act(0, ActorClips.BRACE, 4));
        st.add(s(10, PlayerClips.SPRINT).lightning(0, 30).advance(7.3F, 0, 10, Ease.RUN).chain());
        st.add(s(22, PlayerClips.THRUST).lightning(0, 8).advance(7.6F, 0, 4)
                .defeat(0, ActorClips.AIR_LAUNCH, 4, SHOCK, 14.0F, 16));
        return new Choreography("Chidori", 9.0F, st);
    }

    /**
     * Salto. Os dois saltam e as lâminas se chocam no ar. No chão, descendente
     * contra a guarda dele, ascendente na armadura e um chute que o lança para
     * o alto.
     */
    private static Choreography leap() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(16, PlayerClips.LEAP_SLASH).advance(3.4F, 0, 9)
                .act(0, ActorClips.LEAP_STRIKE, 0).move(0, 5.0F, 3, 6)
                .fx(0, CLASH, 9).move(0, 5.6F, 10, 5));
        st.add(s(6, PlayerClips.SLASH_DOWN).advance(4.15F, 0, 3)
                .act(0, ActorClips.BLOCK_HIGH, 0).fx(0, CLASH, 3)
                .act(0, ActorClips.RECOIL, 4).chain());
        st.add(s(5, PlayerClips.SLASH_UP).advance(4.35F, 0, 3)
                .act(0, ActorClips.SLASHED, 2, SLASH).chain());
        st.add(s(20, PlayerClips.FRONT_KICK).advance(4.55F, 0, 3)
                .defeat(0, ActorClips.AIR_LAUNCH, 3, KICK, 10.6F, 16));
        return new Choreography("Salto", 6.5F, st);
    }

    /**
     * Tempestade de lâminas. Corrida e, sem frear, descendente contra a guarda
     * dele, ascendente e horizontal sempre avançando, e o corte giratório com
     * Chidori que o arremessa longe.
     */
    private static Choreography storm() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(10, PlayerClips.SPRINT).advance(6.05F, 0, 10, Ease.RUN)
                .act(0, ActorClips.BRACE, 1).chain());
        st.add(s(6, PlayerClips.SLASH_DOWN).act(0, ActorClips.BLOCK_HIGH, 0).fx(0, CLASH, 3)
                .act(0, ActorClips.RECOIL, 4).chain());
        st.add(s(5, PlayerClips.SLASH_UP).advance(6.25F, 0, 3)
                .act(0, ActorClips.SLASHED, 2, SLASH).chain());
        st.add(s(10, PlayerClips.SLASH_HORIZ).advance(6.4F, 0, 3)
                .act(0, ActorClips.STAGGER, 3, SLASH).move(0, 8.15F, 3, 6));
        st.add(s(20, PlayerClips.SPIN_SLASH).lightning(0, 9).fx(0, CHARGE, 0).advance(6.75F, 0, 4)
                .defeat(0, ActorClips.FALL_SPIN, 6, SHOCK, 12.8F, 10));
        return new Choreography("Tempestade", 7.5F, st);
    }
}
