package com.kenjutsu.choreo;

import com.kenjutsu.anim.Clip;
import com.kenjutsu.anim.Ease;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import static com.kenjutsu.choreo.ImpactType.CHARGE;
import static com.kenjutsu.choreo.ImpactType.CLASH;
import static com.kenjutsu.choreo.ImpactType.KICK;
import static com.kenjutsu.choreo.ImpactType.MISS;
import static com.kenjutsu.choreo.ImpactType.PLAYER_HIT;
import static com.kenjutsu.choreo.ImpactType.SHOCK;
import static com.kenjutsu.choreo.CamShot.*;

/**
 * A luta: Sasuke contra um espadachim, no estilo da animação "Adult Sasuke vs
 * Madara". Combate real, usando o espaço: investidas de longe com choques no
 * meio do campo, os dois se rodeando, salto em que um passa pelo outro, troca
 * de perto em que o adversário também acerta, joelhada que o lança e o Chidori
 * no iai final. O jogador termina onde a luta terminou.
 *
 * Coordenadas da arena: f = frente do jogador ao ativar, r = direita (blocos).
 * Distâncias de contato verificadas por ferramenta (ver KCheck): corte ≈ 1,25–1,45,
 * choque horizontal ≈ 2,0 (os dois avançam), iai começa a 2,45.
 */
public final class ChoreographyLibrary {

    private static List<Choreography> list;

    private ChoreographyLibrary() {
    }

    public static synchronized List<Choreography> variants() {
        if (list == null) {
            List<Choreography> l = new ArrayList<Choreography>();
            l.add(realFight(FightOptions.OPEN));
            list = Collections.unmodifiableList(l);
        }
        return list;
    }

    private static final java.util.Map<FightOptions, Choreography> BY_OPTIONS =
            new java.util.IdentityHashMap<FightOptions, Choreography>();

    /** A luta montada para um tipo de espaço (campo aberto, apertado, teto baixo...). */
    public static synchronized Choreography fight(FightOptions o) {
        Choreography c = BY_OPTIONS.get(o);
        if (c == null) {
            c = realFight(o);
            BY_OPTIONS.put(o, c);
        }
        return c;
    }

    public static int pickIndex(Random random, int previous) {
        int n = variants().size();
        if (n <= 1) return 0;
        boolean valid = previous >= 0 && previous < n;
        int i = random.nextInt(n - (valid ? 1 : 0));
        if (valid && i >= previous) i++;
        return i;
    }

    // ------------------------------------------------------------------ autoria

    /** Acompanha, durante a escrita do roteiro, onde cada um vai terminar. */
    private static final class Arena {
        float px, pz, ax, az;

        Arena(float ax, float az) {
            this.ax = ax;
            this.az = az;
        }

        float[] u() {
            float dx = ax - px, dz = az - pz;
            float l = (float) Math.sqrt(dx * dx + dz * dz);
            return new float[]{dx / l, dz / l};
        }

        float midX() { return (px + ax) * 0.5F; }

        float midZ() { return (pz + az) * 0.5F; }

        Step player(Step s, float x, float z, int d, int t, Ease e) {
            px = x;
            pz = z;
            return s.p(x, z, d, t, e);
        }

        Step actor(Step s, float x, float z, int d, int t, Ease e) {
            ax = x;
            az = z;
            return s.a(x, z, d, t, e);
        }

        /** Os dois convergem para (cx, cz), ficando a {@code dist} na linha atual entre eles. */
        Step meet(Step s, float cx, float cz, float dist, int pt, int at) {
            float[] u = u();
            float h = dist * 0.5F;
            player(s, cx - u[0] * h, cz - u[1] * h, 0, pt, Ease.RUN);
            return actor(s, cx + u[0] * h, cz + u[1] * h, 0, at, Ease.RUN);
        }

        /** Empurrados para longe um do outro (deslize depois do choque). */
        Step apart(Step s, float back, int t) {
            float[] u = u();
            player(s, px - u[0] * back, pz - u[1] * back, 0, t, Ease.OUT);
            return actor(s, ax + u[0] * back, az + u[1] * back, 0, t, Ease.OUT);
        }

        /** Jogador avança (ou recua, se negativo) na linha, com desvio lateral opcional. */
        Step pStep(Step s, float fwd, float side, int d, int t, Ease e) {
            float[] u = u();
            return player(s, px + u[0] * fwd - u[1] * side, pz + u[1] * fwd + u[0] * side, d, t, e);
        }

        /** Adversário vai até a distância indicada do jogador, na linha atual. */
        Step aTo(Step s, float dist, int d, int t, Ease e) {
            float[] u = u();
            return actor(s, px + u[0] * dist, pz + u[1] * dist, d, t, e);
        }

        /**
         * Investida em zigue-zague com raios: o jogador corta para um lado, para
         * o outro e chega ao ponto de encontro; o adversário vem em linha reta.
         */
        Step zigMeet(Step s, float cx, float cz, float dist, float zig) {
            float[] u = u();
            float h = dist * 0.5F;
            float fx = cx - u[0] * h, fz = cz - u[1] * h;
            float sx = px, sz = pz;
            float nx = -u[1], nz = u[0];
            s.p(sx + (fx - sx) * 0.38F + nx * zig, sz + (fz - sz) * 0.38F + nz * zig, 0, 4, Ease.LINEAR);
            s.p(sx + (fx - sx) * 0.72F - nx * zig * 0.75F, sz + (fz - sz) * 0.72F - nz * zig * 0.75F, 4, 3, Ease.LINEAR);
            player(s, fx, fz, 7, 3, Ease.OUT);
            return actor(s, cx + u[0] * h, cz + u[1] * h, 0, 10, Ease.RUN);
        }

        /** Passe relâmpago: atravessa até {@code beyond} além dele, desviando {@code deg} da linha. */
        Step pass(Step s, float beyond, float deg, int delay, int ticks) {
            float[] u = u();
            double r = Math.toRadians(deg);
            float c = (float) Math.cos(r), sn = (float) Math.sin(r);
            float dx = u[0] * c - u[1] * sn, dz = u[0] * sn + u[1] * c;
            float ox = ax, oz = az;
            player(s, ox + dx * beyond, oz + dz * beyond, delay, ticks, Ease.SMOOTH);
            // o golpe o empurra um pouco na direção do passe
            return actor(s, ox + dx * 0.45F, oz + dz * 0.45F, delay + 3, 4, Ease.OUT);
        }

        Step orbit(Step s, float deg, int d, int t) {
            float cx = midX(), cz = midZ();
            float[] o = new float[2];
            com.kenjutsu.anim.Track2D.rotate(px, pz, cx, cz, deg, o);
            px = o[0];
            pz = o[1];
            com.kenjutsu.anim.Track2D.rotate(ax, az, cx, cz, deg, o);
            ax = o[0];
            az = o[1];
            return s.orbit(deg, d, t);
        }
    }

    private static Step s(int duration, Clip player) {
        return new Step(duration, player);
    }

    // ------------------------------------------------------------------ a luta

    private static Choreography realFight(FightOptions o) {
        final float k = o.space;
        Arena w = new Arena(Math.max(5.0F, 13.0F * k), 3.5F * k);
        List<Step> st = new ArrayList<Step>();

        // 1) Um clique e os dois disparam: você em zigue-zague com raios, ele em linha reta.
        st.add(w.zigMeet(s(10, PlayerClips.SPRINT), w.midX(), w.midZ() - 0.15F * k, 2.0F, 1.8F * k).lightning(0, 10)
                .act(ActorClips.RUN_IN, 0).act(ActorClips.HORIZ_STRIKE, 9).cam(CHASE, 1, 0));
        st.add(s(6, PlayerClips.SLASH_HORIZ).fx(CLASH, 3).cam(LOW, 1, 0));
        st.add(w.apart(s(12, PlayerClips.SKID_BACK), Math.max(0.8F, 1.7F * k), 8).act(ActorClips.RECOIL, 0).cam(SIDE, 1, 4));

        // 2) Rodeiam-se (câmera do alto) e investem de novo; ele desce a espada, bloqueio alto.
        st.add(w.orbit(s(12, PlayerClips.STRAFE), o.wide ? 80.0F : 55.0F, 0, 12).act(ActorClips.STRAFE, 0)
                .cam(o.wide ? TOP : SIDE, 1, 8));
        st.add(w.zigMeet(s(10, PlayerClips.SPRINT), w.midX(), w.midZ(), 1.7F, -1.5F * k).lightning(0, 10)
                .act(ActorClips.RUN_IN, 0).act(ActorClips.OVERHEAD_STRIKE, 8).cam(CHASE, -1, 0));
        st.add(s(6, PlayerClips.PARRY_HIGH).fx(CLASH, 2).cam(LOW, -1, 0));
        st.add(w.apart(s(12, PlayerClips.SKID_BACK), Math.max(0.7F, 1.5F * k), 8).act(ActorClips.RECOIL, 0).cam(WIDE, -1, 0));

        if (o.aerial) {
        // 3) Os dois saltam, choque no ar, cada um aterrissa do outro lado e se viram.
            {
                float[] u = w.u();
                float mx = w.midX(), mz = w.midZ();
                float nx = -u[1], nz = u[0];
                Step leap = s(16, PlayerClips.LEAP_SLASH).lockFacing().cam(SIDE, 1, 0)
                        .act(ActorClips.LEAP_STRIKE, 0).fx(CLASH, 9);
                leap.p(mx - u[0] * 0.8F + nx * 0.3F, mz - u[1] * 0.8F + nz * 0.3F, 0, 9, Ease.SMOOTH);
                leap.a(mx + u[0] * 0.8F - nx * 0.3F, mz + u[1] * 0.8F - nz * 0.3F, 3, 6, Ease.SMOOTH);
                w.player(leap, mx + u[0] * 1.5F + nx * 0.7F, mz + u[1] * 1.5F + nz * 0.7F, 9, 6, Ease.OUT);
                w.actor(leap, mx - u[0] * 1.5F - nx * 0.7F, mz - u[1] * 1.5F - nz * 0.7F, 9, 6, Ease.OUT);
                st.add(leap);
            }
            st.add(s(7, PlayerClips.GUARD_IDLE).cam(SHOULDER, 1, 0));
        } else {
            // teto baixo: em vez do salto, giram um em volta do outro trocando de lado
            st.add(w.orbit(s(12, PlayerClips.STRAFE), 150.0F, 0, 12).act(ActorClips.STRAFE, 0).cam(SHOULDER, 1, 6));
        }

        // 4) De perto: ele avança atacando, você apara e sai para o lado.
        st.add(w.aTo(s(5, null), 1.6F, 0, 5, Ease.RUN).act(ActorClips.RUN_IN, 0).cam(SIDE, -1, 3));
        st.add(w.pStep(s(9, PlayerClips.PARRY_SIDE), -0.1F, 0.5F, 4, 5, Ease.SMOOTH)
                .act(ActorClips.HORIZ_STRIKE, 0).fx(CLASH, 3).act(ActorClips.RECOIL, 4));
        // 5) Seu corte bate na guarda dele; ele contra-ataca de cima e te acerta.
        st.add(w.aTo(s(5, PlayerClips.SLASH_UP), 1.25F, 0, 3, Ease.SMOOTH)
                .act(ActorClips.BLOCK_SIDE, 0).fx(CLASH, 2).cam(SHOULDER, -1, 0));
        st.add(w.pStep(s(12, PlayerClips.HIT_TAKEN), -0.8F, -0.35F, 4, 6, Ease.OUT)
                .act(ActorClips.OVERHEAD_STRIKE, 0).fx(PLAYER_HIT, 4).cam(FRONT, 1, 0));

        // 6) Ele salta (ou avança, com teto baixo) sobre você; bloqueio alto e joelhada.
        if (o.aerial) {
            st.add(w.aTo(s(7, null), 1.45F, 3, 6, Ease.SMOOTH).act(ActorClips.LEAP_STRIKE, 0).cam(LOW, 1, 0));
        } else {
            st.add(w.aTo(s(7, null), 1.45F, 0, 6, Ease.RUN).act(ActorClips.RUN_IN, 0)
                    .act(ActorClips.OVERHEAD_STRIKE, 5).cam(LOW, 1, 0));
        }
        st.add(s(6, PlayerClips.PARRY_HIGH).fx(CLASH, 2));
        {
            Step knee = w.pStep(s(20, PlayerClips.KNEE_STRIKE), 0.4F, 0.0F, 0, 3, Ease.OUT)
                    .act(o.aerial ? ActorClips.AIR_LAUNCH : ActorClips.FALL_BACK, 3, KICK).cam(WIDE, 1, 0);
            float[] u = w.u();
            float fly = o.aerial ? 4.5F * Math.max(0.6F, k) : Math.max(1.4F, 3.0F * k);
            w.actor(knee, w.ax + u[0] * fly + u[1] * 1.2F * k, w.az + u[1] * fly - u[0] * 1.2F * k, 3,
                    o.aerial ? 16 : 9, Ease.OUT);
            st.add(knee);
        }

        // 7) Ele se levanta; close em você com o Chidori acendendo.
        st.add(s(14, PlayerClips.CHARGE).lightning(2, 14).fx(CHARGE, 2).act(ActorClips.GET_UP, 0)
                .cam(FRONT, -1, 0));

        // 8) Passes relâmpago: você o atravessa três vezes, de direções diferentes.
        st.add(w.pass(s(10, PlayerClips.FLASH_CUT), 2.45F, 24.0F, 1, 5).lockFacing().lightning(0, 10)
                .act(ActorClips.SLASHED, 4, SHOCK).cam(CHASE, 1, 0));
        st.add(w.pass(s(10, PlayerClips.FLASH_CUT), 2.45F, -32.0F, 1, 5).lockFacing().lightning(0, 10)
                .act(ActorClips.STAGGER, 4, SHOCK).cam(WIDE, -1, 0));
        st.add(w.pass(s(10, PlayerClips.FLASH_CUT), 2.45F, 20.0F, 1, 5).lockFacing().lightning(0, 10)
                .act(ActorClips.SLASHED, 4, SHOCK).cam(LOW, 1, 0));

        // 9) Ele mal fica de pé e ergue a espada; o iai elétrico final. Você para de costas, ele cai.
        st.add(w.pStep(s(32, PlayerClips.IAI_DASH), 4.7F, 0.0F, 3, 5, Ease.SMOOTH)
                .lockFacing().lightning(0, 9).fx(CHARGE, 0).cam(SIDE, -1, 0)
                .act(ActorClips.OVERHEAD_STRIKE, 1).fx(MISS, 5)
                .defeat(ActorClips.KNEEL_COLLAPSE, 14, SHOCK, w.ax, w.az, 1));

        // Um clique só: depois dele a luta inteira segue sozinha.
        for (int i = 0; i < st.size() - 1; i++) st.get(i).chain();
        return new Choreography("Sasuke vs espadachim (" + o.name + ")", Math.max(5.0F, 13.0F * k), 3.5F * k, st);
    }
}
