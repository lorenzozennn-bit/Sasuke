package com.kenjutsu.choreo;

import com.kenjutsu.anim.Ease;

/** Deslocamento no chão da arena agendado dentro de uma etapa. */
public final class Move {
    public enum Who { PLAYER, ACTOR, ORBIT }

    public final Who who;
    public final float x, z, deg;
    public final int delay, ticks;
    public final Ease ease;

    Move(Who who, float x, float z, float deg, int delay, int ticks, Ease ease) {
        this.who = who;
        this.x = x;
        this.z = z;
        this.deg = deg;
        this.delay = delay;
        this.ticks = ticks;
        this.ease = ease == null ? Ease.SMOOTH : ease;
    }
}
