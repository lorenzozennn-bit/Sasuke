package com.kenjutsu.choreo;

/**
 * Leitura do cenário em volta do ponto onde a luta começa, em coordenadas do
 * MUNDO relativas a esse ponto (dx, dz em blocos).
 */
public interface Terrain {

    /** Altura do chão (blocos) relativa aos pés do jogador; NaN se não há chão perto (buraco/vazio). */
    float height(float dx, float dz);

    /** Espaço livre acima do chão (blocos, até 8). */
    float clearance(float dx, float dz);

    /** Terreno plano e aberto (testes e fallback). */
    Terrain OPEN = new Terrain() {
        public float height(float dx, float dz) { return 0.0F; }
        public float clearance(float dx, float dz) { return 8.0F; }
    };
}
