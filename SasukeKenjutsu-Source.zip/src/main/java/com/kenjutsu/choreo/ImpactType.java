package com.kenjutsu.choreo;

/** Efeito audiovisual disparado no instante de uma ação. */
public enum ImpactType {
    /** Nenhum efeito. */
    NONE,
    /** Corte que acerta a armadura do adversário (faíscas + som de corte). */
    SLASH,
    /** Corte forte / golpe final (faíscas, som crítico e micropausa). */
    HEAVY,
    /** Lâmina contra lâmina (faíscas grandes + "clang" metálico + micropausa). */
    CLASH,
    /** Arranca a espada da mão do adversário. */
    DISARM,
    /** Golpe do adversário passa no vazio. */
    MISS,
    /** Chute/empurrão sem lâmina. */
    KICK
}
