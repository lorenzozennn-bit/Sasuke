package com.kenjutsu.combat;

import com.kenjutsu.choreo.Choreography;
import com.kenjutsu.choreo.ChoreographyLibrary;
import com.kenjutsu.choreo.FightOptions;
import com.kenjutsu.choreo.Terrain;

/**
 * Lê o cenário e escolhe como a luta vai acontecer: o tipo de luta (campo
 * aberto, espaço médio, apertado, teto baixo), a direção e se é espelhada.
 *
 * Para cada candidato, a luta inteira é SIMULADA tick a tick e cada posição
 * dos dois lutadores é conferida no terreno: paredes e degraus altos no
 * caminho, buracos, teto baixo (saltos precisam de céu aberto). Vence o
 * candidato sem problemas mais próximo da direção para onde o jogador olha.
 */
public final class FightPlanner {

    /** Resultado: luta escolhida + giro (graus) da arena em relação ao olhar do jogador + espelho. */
    public static final class Plan {
        public final Choreography fight;
        public final FightOptions options;
        public final float yawOffset;
        public final boolean mirror;
        public final float penalty;

        Plan(Choreography fight, FightOptions options, float yawOffset, boolean mirror, float penalty) {
            this.fight = fight;
            this.options = options;
            this.yawOffset = yawOffset;
            this.mirror = mirror;
            this.penalty = penalty;
        }
    }

    private static final int DIRECTIONS = 16;
    /** Abaixo disso o candidato é considerado limpo. */
    private static final float GOOD_ENOUGH = 2.0F;

    private FightPlanner() {
    }

    public static Plan plan(Terrain terrain) {
        Plan best = null;
        for (FightOptions o : FightOptions.TIERS) {
            Choreography c = ChoreographyLibrary.fight(o);
            Plan tierBest = null;
            for (int d = 0; d < DIRECTIONS; d++) {
                float off = d * (360.0F / DIRECTIONS);
                if (off > 180.0F) off -= 360.0F;
                for (int mi = 0; mi < 2; mi++) {
                    boolean mirror = mi == 1;
                    float pen = evaluate(c, o, terrain, off, mirror);
                    pen += Math.abs(off) / 180.0F * 0.9F + (mirror ? 0.05F : 0.0F); // prefere para onde você olha
                    if (tierBest == null || pen < tierBest.penalty) tierBest = new Plan(c, o, off, mirror, pen);
                }
            }
            if (best == null || tierBest.penalty < best.penalty) best = tierBest;
            if (tierBest.penalty <= GOOD_ENOUGH + 0.9F) return tierBest; // o maior espaço que cabe
        }
        return best;
    }

    /** Penalidade de uma luta neste terreno, girada {@code yawOffset} graus e opcionalmente espelhada. */
    static float evaluate(Choreography c, FightOptions o, Terrain t, float yawOffset, boolean mirror) {
        CombatStateMachine m = new CombatStateMachine();
        m.start(c, 0.0F);
        m.onClick(0.0F);
        double w = Math.toRadians(yawOffset);
        float sinW = (float) Math.sin(w), cosW = (float) Math.cos(w);
        float ms = mirror ? -1.0F : 1.0F;
        float[] p = new float[2], a = new float[2];
        float pen = 0.0F;
        float lastPH = 0.0F, lastAH = Float.NaN;
        float needClear = o.aerial ? 4.2F : 2.2F;
        for (int tick = 1; tick < 600; tick++) {
            m.tick(tick);
            m.playerPosition(tick, p);
            float pdx = p[0] * -sinW + p[1] * ms * -cosW, pdz = p[0] * cosW + p[1] * ms * -sinW;
            float ph = t.height(pdx, pdz);
            pen += pointPenalty(ph, t.clearance(pdx, pdz), needClear, lastPH, true);
            if (!Float.isNaN(ph)) lastPH = ph;
            if (!m.actors().isEmpty()) {
                m.actors().get(0).position(tick, a);
                float adx = a[0] * -sinW + a[1] * ms * -cosW, adz = a[0] * cosW + a[1] * ms * -sinW;
                float ah = t.height(adx, adz);
                pen += 0.6F * pointPenalty(ah, t.clearance(adx, adz), needClear,
                        Float.isNaN(lastAH) ? 0.0F : lastAH, false);
                if (!Float.isNaN(ah)) lastAH = ah;
            }
            if (m.state() == CombatState.VICTORY) break;
        }
        return pen;
    }

    private static float pointPenalty(float h, float clear, float needClear, float lastH, boolean player) {
        if (Float.isNaN(h)) return 3.0F;                    // buraco / sem chão perto
        float pen = 0.0F;
        float dh = h - lastH;
        if (dh > 0.55F) pen += player ? 2.5F : 0.8F;         // degrau que o jogador não sobe sozinho / parede
        if (dh < -1.2F) pen += 1.5F;                         // queda
        if (Math.abs(h) > 2.5F) pen += 0.4F;                 // longe demais da altura inicial
        if (clear < 2.0F) pen += 3.0F;                       // dentro de parede/árvore
        else if (clear < needClear) pen += 0.25F;            // teto baixo para saltos e câmera alta
        return pen;
    }
}
