package com.kenjutsu.combat;

import com.kenjutsu.choreo.ActorAction;
import com.kenjutsu.choreo.Choreography;
import com.kenjutsu.choreo.Step;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Máquina de estados de combate. Independente do Minecraft: recebe o tempo
 * (ticks) e cliques, e expõe poses/posições para os renderizadores.
 *
 * Regras:
 *  - cada clique válido avança uma etapa;
 *  - cliques durante uma etapa ficam em fila (no máximo 1) e só disparam
 *    quando a etapa atual já percorreu {@link #ADVANCE_FRACTION} da duração;
 *  - após a última etapa, entra em VICTORY automaticamente; cliques são ignorados;
 *  - somente {@link #start} (tecla R / troca de modo) reinicia.
 */
public final class CombatStateMachine {

    public static final float ADVANCE_FRACTION = 0.55F;
    public static final int MIN_ADVANCE_TICKS = 4;

    private CombatState state = CombatState.INACTIVE;
    private Choreography choreo;
    private final List<VirtualActor> actors = new ArrayList<VirtualActor>();
    private final PlayerAnimationController player = new PlayerAnimationController();
    /** Deslocamento visual do jogador para frente (blocos). As distâncias dos atores são medidas da posição real. */
    private final com.kenjutsu.anim.ScalarTrack advance = new com.kenjutsu.anim.ScalarTrack(false, 0.0F);
    private final List<Pending> pending = new ArrayList<Pending>();
    private SceneFx fx = SceneFx.SILENT;

    private int stepIndex = -1;
    private float stepStart;
    private boolean clickQueued;

    private static final class Pending {
        final float at;
        final ActorAction action;

        Pending(float at, ActorAction action) {
            this.at = at;
            this.action = action;
        }
    }

    public void setFx(SceneFx fx) {
        this.fx = fx == null ? SceneFx.SILENT : fx;
    }

    /** Monta (ou remonta) a cena do zero. */
    public void start(Choreography c, float now) {
        this.choreo = c;
        actors.clear();
        for (int i = 0; i < c.actorCount(); i++) {
            actors.add(new VirtualActor(i, c.angle(i), c.startRadius));
        }
        ActorAnimationController.reset(actors, now, c.startRadius);
        player.reset(now, c.angle(0));
        advance.reset(0.0F);
        pending.clear();
        stepIndex = -1;
        stepStart = now;
        clickQueued = false;
        state = CombatState.READY;
    }

    /** Remove todos os atores e volta ao estado desligado. */
    public void stop() {
        actors.clear();
        pending.clear();
        choreo = null;
        stepIndex = -1;
        clickQueued = false;
        state = CombatState.INACTIVE;
    }

    /** Clique esquerdo do jogador. Retorna true se o clique foi aceito (avançou ou entrou na fila). */
    public boolean onClick(float now) {
        switch (state) {
            case READY:
                advance(now);
                return true;
            case PLAYING:
                if (stepIndex >= choreo.steps().size() - 1) {
                    return false; // última etapa em andamento: nada a enfileirar
                }
                if (canAdvance(now)) {
                    advance(now);
                } else {
                    clickQueued = true;
                }
                return true;
            case VICTORY:
            case INACTIVE:
            default:
                return false;
        }
    }

    /** Chamado uma vez por tick do cliente. */
    public void tick(float now) {
        if (state == CombatState.INACTIVE) return;

        firePending(now);

        if (state == CombatState.PLAYING) {
            Step cur = choreo.steps().get(stepIndex);
            boolean hasNext = stepIndex < choreo.steps().size() - 1;
            if (hasNext && cur.chainsToNext() && now - stepStart >= cur.duration) {
                // Combo: a próxima etapa começa no instante exato em que esta termina.
                advance(stepStart + cur.duration);
                firePending(now);
            } else if (clickQueued && canAdvance(now) && hasNext) {
                advance(now);
                firePending(now);
            } else if (VictoryManager.isFightOver(stepIndex, choreo.steps().size(), now - stepStart, cur.duration)) {
                firePending(Float.MAX_VALUE);
                state = CombatState.VICTORY;
                clickQueued = false;
                VictoryManager.enterVictory(actors, player, now, fx);
            }
        }

        player.returnToNeutralIfDone(now, state == CombatState.VICTORY);
        ActorAnimationController.returnToNeutral(actors, now);
    }

    private boolean canAdvance(float now) {
        Step cur = choreo.steps().get(stepIndex);
        float min = Math.max(MIN_ADVANCE_TICKS, cur.duration * ADVANCE_FRACTION);
        return now - stepStart >= min;
    }

    private void advance(float now) {
        // Ações ainda pendentes da etapa anterior são aplicadas antes, mantendo o roteiro consistente.
        firePending(Float.MAX_VALUE);
        stepIndex++;
        stepStart = now;
        clickQueued = false;
        state = CombatState.PLAYING;

        Step s = choreo.steps().get(stepIndex);
        if (s.face >= 0) {
            player.faceTowards(choreo.angle(s.face), now, s.turnTicks);
        }
        if (s.playerClip != null) {
            player.play(s.playerClip, now, 2.0F);
        }
        if (s.hasAdvance()) {
            advance.moveTo(s.advanceTo(), now + s.advanceDelay(), s.advanceTicks());
        }
        for (ActorAction a : s.actions()) {
            pending.add(new Pending(now + a.delay, a));
        }
        firePending(now);
    }

    private void firePending(float now) {
        if (pending.isEmpty()) return;
        // Ordem estável por instante agendado.
        List<Pending> due = new ArrayList<Pending>();
        Iterator<Pending> it = pending.iterator();
        while (it.hasNext()) {
            Pending p = it.next();
            if (p.at <= now) {
                due.add(p);
                it.remove();
            }
        }
        Collections.sort(due, (x, y) -> Float.compare(x.at, y.at));
        for (Pending p : due) {
            ActorAnimationController.apply(actors.get(p.action.actor), p.action, p.at, fx);
        }
    }

    // ---------------------------------------------------------------- leitura

    public CombatState state() {
        return state;
    }

    public boolean isActive() {
        return state != CombatState.INACTIVE;
    }

    public List<VirtualActor> actors() {
        return Collections.unmodifiableList(actors);
    }

    public PlayerAnimationController player() {
        return player;
    }

    /** Quanto o jogador avançou (blocos) na direção do adversário 0. */
    public float playerAdvance(float now) {
        return advance.value(now);
    }

    public Choreography choreography() {
        return choreo;
    }

    /** Etapa atual (1-based para exibição); 0 antes do primeiro clique. */
    public int stepNumber() {
        return stepIndex + 1;
    }

    public int stepCount() {
        return choreo == null ? 0 : choreo.steps().size();
    }

    public boolean hasQueuedClick() {
        return clickQueued;
    }
}
