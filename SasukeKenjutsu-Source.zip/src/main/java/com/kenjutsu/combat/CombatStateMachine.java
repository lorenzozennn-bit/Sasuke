package com.kenjutsu.combat;

import com.kenjutsu.anim.Ease;
import com.kenjutsu.anim.Track2D;
import com.kenjutsu.choreo.ActorAction;
import com.kenjutsu.choreo.Choreography;
import com.kenjutsu.choreo.ImpactType;
import com.kenjutsu.choreo.Move;
import com.kenjutsu.choreo.Step;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Máquina de estados de combate. Independente do Minecraft: recebe o tempo
 * (ticks de cena) e cliques, e expõe poses, posições na arena e direções.
 *
 * Arena: plano do chão com eixo f (frente do jogador ao ativar) e r (direita).
 * O jogador começa em (0, 0). Os dois se viram um para o outro sozinhos; uma
 * etapa pode congelar as direções (quando um passa pelo outro).
 *
 *  - cada clique válido avança uma etapa (cliques adiantados ficam em fila);
 *  - etapas "encadeadas" começam sozinhas quando a anterior termina;
 *  - depois da última etapa, VICTORY; só {@link #start} reinicia.
 */
public final class CombatStateMachine {

    public static final float ADVANCE_FRACTION = 0.55F;
    public static final int MIN_ADVANCE_TICKS = 4;
    private static final float TURN_TICKS = 4.0F;

    private CombatState state = CombatState.INACTIVE;
    private Choreography choreo;
    private final List<VirtualActor> actors = new ArrayList<VirtualActor>();
    private final PlayerAnimationController player = new PlayerAnimationController();
    private final Track2D playerPos = new Track2D(0, 0);
    private final List<Pending> pending = new ArrayList<Pending>();
    private SceneFx fx = SceneFx.SILENT;

    private int stepIndex = -1;
    private float stepStart;
    private boolean clickQueued;

    private float chargeFrom = -1.0F, chargeTo = -1.0F;
    private float playerHurtUntil = -1.0F;

    // direção (graus na arena: 0 = +f, 90 = +r)
    private boolean lock;
    private float lockP, lockA;
    private float turnStart, turnFromP, turnFromA;

    private final float[] pa = new float[2], pb = new float[2];

    private static final class Pending {
        final float at;
        final ActorAction action;
        final Move move;

        Pending(float at, ActorAction action, Move move) {
            this.at = at;
            this.action = action;
            this.move = move;
        }
    }

    public void setFx(SceneFx fx) {
        this.fx = fx == null ? SceneFx.SILENT : fx;
    }

    public void start(Choreography c, float now) {
        this.choreo = c;
        actors.clear();
        actors.add(new VirtualActor(0, c.actorX, c.actorZ));
        ActorAnimationController.reset(actors, now, c.actorX, c.actorZ);
        player.reset(now);
        playerPos.reset(0, 0);
        pending.clear();
        stepIndex = -1;
        stepStart = now;
        clickQueued = false;
        chargeFrom = chargeTo = -1.0F;
        playerHurtUntil = -1.0F;
        lock = false;
        float auto = autoAngle(now, true, 0.0F);
        turnStart = now;
        turnFromP = auto;
        turnFromA = auto + 180.0F;
        state = CombatState.READY;
    }

    public void stop() {
        actors.clear();
        pending.clear();
        choreo = null;
        stepIndex = -1;
        clickQueued = false;
        state = CombatState.INACTIVE;
    }

    public boolean onClick(float now) {
        switch (state) {
            case READY:
                advance(now);
                return true;
            case PLAYING:
                if (stepIndex >= choreo.steps().size() - 1) return false;
                if (canAdvance(now)) advance(now);
                else clickQueued = true;
                return true;
            default:
                return false;
        }
    }

    public void tick(float now) {
        if (state == CombatState.INACTIVE) return;
        firePending(now);
        if (state == CombatState.PLAYING) {
            Step cur = choreo.steps().get(stepIndex);
            boolean hasNext = stepIndex < choreo.steps().size() - 1;
            if (hasNext && cur.chainsToNext() && now - stepStart >= cur.duration) {
                advance(stepStart + cur.duration);
                firePending(now);
            } else if (clickQueued && hasNext && canAdvance(now) && !cur.chainsToNext()) {
                advance(now);
                firePending(now);
            } else if (VictoryManager.isFightOver(stepIndex, choreo.steps().size(), now - stepStart, cur.duration)) {
                firePending(Float.MAX_VALUE);
                state = CombatState.VICTORY;
                clickQueued = false;
                VictoryManager.enterVictory(actors, player, now, fx);
            }
        }
        player.returnToNeutralIfDone(now, state == CombatState.VICTORY);
        ActorAnimationController.returnToNeutral(actors, now);
    }

    private boolean canAdvance(float now) {
        Step cur = choreo.steps().get(stepIndex);
        if (cur.chainsToNext()) return false; // a etapa encadeada segue sozinha
        float min = Math.max(MIN_ADVANCE_TICKS, cur.duration * ADVANCE_FRACTION);
        return now - stepStart >= min;
    }

    private void advance(float now) {
        firePending(Float.MAX_VALUE);
        // direção de partida para a virada suave desta etapa
        turnFromP = playerFacing(now);
        turnFromA = actorFacing(now);
        turnStart = now;

        stepIndex++;
        stepStart = now;
        clickQueued = false;
        state = CombatState.PLAYING;
        Step s = choreo.steps().get(stepIndex);

        lock = s.locksFacing();
        if (lock) {
            lockP = turnFromP;
            lockA = turnFromA;
        }
        if (s.hasLightning()) {
            chargeFrom = now + s.lightningFrom();
            chargeTo = now + s.lightningTo();
        }
        if (s.playerClip != null) player.play(s.playerClip, now, 2.0F);
        for (ActorAction a : s.actions()) pending.add(new Pending(now + a.delay, a, null));
        for (Move m : s.moves()) pending.add(new Pending(now + m.delay, null, m));
        firePending(now);
    }

    private void firePending(float now) {
        if (pending.isEmpty()) return;
        List<Pending> due = new ArrayList<Pending>();
        Iterator<Pending> it = pending.iterator();
        while (it.hasNext()) {
            Pending p = it.next();
            if (p.at <= now) {
                due.add(p);
                it.remove();
            }
        }
        Collections.sort(due, (x, y) -> Float.compare(x.at, y.at));
        for (Pending p : due) {
            if (p.move != null) {
                applyMove(p.move, p.at);
                continue;
            }
            if (p.action.impact == ImpactType.PLAYER_HIT) playerHurtUntil = p.at + 5.0F;
            ActorAnimationController.apply(actors.get(p.action.actor), p.action, p.at, fx);
        }
    }

    private void applyMove(Move m, float at) {
        VirtualActor a = actors.get(0);
        switch (m.who) {
            case PLAYER:
                playerPos.moveTo(m.x, m.z, at, m.ticks, m.ease);
                break;
            case ACTOR:
                if (!a.defeated) a.pos.moveTo(m.x, m.z, at, m.ticks, m.ease);
                break;
            case ORBIT: {
                playerPos.value(at, pa);
                a.pos.value(at, pb);
                float cx = (pa[0] + pb[0]) * 0.5F, cz = (pa[1] + pb[1]) * 0.5F;
                playerPos.orbit(cx, cz, m.deg, at, m.ticks, m.ease);
                if (!a.defeated) a.pos.orbit(cx, cz, m.deg, at, m.ticks, m.ease);
                break;
            }
            default:
                break;
        }
    }

    // ---------------------------------------------------------------- direção

    /** Ângulo (graus) de quem olha para o outro; {@code fromPlayer}: do jogador para o adversário. */
    private float autoAngle(float now, boolean fromPlayer, float fallback) {
        if (actors.isEmpty()) return fallback;
        float[] p = playerPos.value(now, new float[2]);
        float[] a = actors.get(0).pos.value(now, new float[2]);
        float dx = a[0] - p[0], dz = a[1] - p[1];
        if (dx * dx + dz * dz < 0.04F) return fallback;
        float ang = (float) Math.toDegrees(Math.atan2(dz, dx));
        return fromPlayer ? ang : ang + 180.0F;
    }

    private static float blendAngle(float from, float to, float k) {
        float d = to - from;
        d = ((d % 360.0F) + 540.0F) % 360.0F - 180.0F;
        return from + d * k;
    }

    /** Direção do corpo do jogador (graus na arena). Sem efeitos colaterais. */
    public float playerFacing(float now) {
        float target = lock ? lockP : autoAngle(now, true, turnFromP);
        float k = Ease.SMOOTH.apply(Math.min(1.0F, Math.max(0.0F, (now - turnStart) / TURN_TICKS)));
        return blendAngle(turnFromP, target, k);
    }

    /** Direção do corpo do adversário (graus na arena). */
    public float actorFacing(float now) {
        float target = lock ? lockA : autoAngle(now, false, turnFromA);
        float k = Ease.SMOOTH.apply(Math.min(1.0F, Math.max(0.0F, (now - turnStart) / TURN_TICKS)));
        return blendAngle(turnFromA, target, k);
    }

    // ---------------------------------------------------------------- leitura

    public CombatState state() {
        return state;
    }

    public boolean isActive() {
        return state != CombatState.INACTIVE;
    }

    public List<VirtualActor> actors() {
        return Collections.unmodifiableList(actors);
    }

    public PlayerAnimationController player() {
        return player;
    }

    /** Posição (f, r) do jogador na arena. */
    public float[] playerPosition(float now, float[] out) {
        return playerPos.value(now, out);
    }

    /** Velocidade do jogador (blocos por tick de cena), para vultos e rastro. */
    public float playerSpeed(float now) {
        float[] a = playerPos.value(now, new float[2]);
        float[] b = playerPos.value(now - 1.0F, new float[2]);
        float dx = a[0] - b[0], dz = a[1] - b[1];
        return (float) Math.sqrt(dx * dx + dz * dz);
    }

    public float playerHurtAmount(float now) {
        if (playerHurtUntil < 0.0F || now >= playerHurtUntil) return 0.0F;
        return Math.min(1.0F, (playerHurtUntil - now) / 5.0F);
    }

    public float playerCharge(float now) {
        if (chargeFrom < 0.0F || now < chargeFrom) return 0.0F;
        if (now <= chargeTo) return Math.min(1.0F, (now - chargeFrom) / 2.0F + 0.35F);
        float f = 1.0F - (now - chargeTo) / 4.0F;
        return f > 0.0F ? f : 0.0F;
    }

    public Choreography choreography() {
        return choreo;
    }

    public int stepNumber() {
        return stepIndex + 1;
    }

    public int stepCount() {
        return choreo == null ? 0 : choreo.steps().size();
    }

    public boolean hasQueuedClick() {
        return clickQueued;
    }
}
