package com.kenjutsu.combat;

import com.kenjutsu.anim.Ease;
import com.kenjutsu.choreo.ActorAction;
import com.kenjutsu.choreo.ActorClips;
import com.kenjutsu.choreo.ImpactType;

import java.util.List;

/** Aplica as ações do roteiro ao adversário e o devolve à guarda quando um golpe termina. */
final class ActorAnimationController {

    private ActorAnimationController() {
    }

    static void reset(List<VirtualActor> actors, float now, float x, float z) {
        for (VirtualActor a : actors) {
            a.defeated = false;
            a.hurtUntil = -1.0F;
            a.disarmedAt = -1.0F;
            a.pos.reset(x, z);
            a.track.snap(ActorClips.GUARD_IDLE, now);
        }
    }

    static void apply(VirtualActor actor, ActorAction action, float at, SceneFx fx) {
        if (actor.defeated && !action.defeat) return;
        if (action.clip != null) actor.track.play(action.clip, at, 2.0F);
        if (action.movesActor()) {
            actor.pos.moveTo(action.knockX, action.knockZ, at, action.moveTicks, Ease.OUT);
        }
        ImpactType t = action.impact;
        if (t == ImpactType.SLASH || t == ImpactType.HEAVY || t == ImpactType.KICK || t == ImpactType.SHOCK) {
            actor.hurtUntil = at + 5.0F;
        }
        if (t == ImpactType.DISARM && actor.disarmedAt < 0.0F) actor.disarmedAt = at;
        if (t != ImpactType.NONE) fx.onImpact(actor, t);
        if (action.defeat && !actor.defeated) {
            actor.defeated = true;
            fx.onActorDefeated(actor);
        }
    }

    static void returnToNeutral(List<VirtualActor> actors, float now) {
        for (VirtualActor a : actors) {
            if (!a.defeated && a.track.isFinished(now)) {
                a.track.play(ActorClips.followUp(a.track.clip()), now, 4.0F);
            }
        }
    }
}
