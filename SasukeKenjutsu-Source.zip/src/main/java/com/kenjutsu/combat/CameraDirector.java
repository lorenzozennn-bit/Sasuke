package com.kenjutsu.combat;

import com.kenjutsu.choreo.CamShot;

/**
 * Diretor de câmera (Java puro): calcula onde fica a câmera e para onde ela
 * olha, em coordenadas da arena (f, r) e altura acima do chão do jogador.
 * Saída: {camF, camR, camH, lookF, lookR, lookH}.
 *
 * O eixo de cada plano (linha jogador → adversário) é fixado no instante do
 * corte, então a câmera não troca de lado quando os dois se cruzam; as
 * posições dos lutadores continuam ao vivo.
 */
public final class CameraDirector {

    private CameraDirector() {
    }

    /**
     * Ajuste de um plano ao cenário: troca de enquadramento, inverte o lado e/ou
     * aproxima a câmera do alvo. {@code cost} = preferência (0 = plano original).
     */
    public static final class Fit {
        public static final Fit NONE = new Fit(null, 1.0F, 1.0F, 0.0F);
        public final CamShot shot;
        public final float sideMul, scale, cost;

        public Fit(CamShot shot, float sideMul, float scale, float cost) {
            this.shot = shot;
            this.sideMul = sideMul;
            this.scale = scale;
            this.cost = cost;
        }
    }

    /** Alternativas em ordem de preferência para um plano. */
    public static Fit[] alternatives(CamShot base) {
        return new Fit[]{
                Fit.NONE,
                new Fit(null, -1.0F, 1.0F, 0.1F),
                new Fit(null, 1.0F, 0.6F, 0.2F),
                new Fit(null, -1.0F, 0.6F, 0.3F),
                new Fit(CamShot.SHOULDER, 1.0F, 1.0F, 0.4F),
                new Fit(CamShot.SHOULDER, -1.0F, 0.75F, 0.5F),
                new Fit(CamShot.FRONT, 1.0F, 1.0F, 0.6F),
                new Fit(CamShot.SHOULDER, 1.0F, 0.45F, 0.8F),
        };
    }

    public static void compute(CombatStateMachine m, float now, float[] out) {
        compute(m, now, out, Fit.NONE, Fit.NONE);
    }

    public static void compute(CombatStateMachine m, float now, float[] out, Fit cur, Fit prevFit) {
        float[] curO = new float[6];
        shot(m, cur.shot != null ? cur.shot : m.shot(), m.shotSide() * cur.sideMul, m.shotStart(), now, curO);
        scale(curO, cur.scale);
        float blend = m.shotBlend();
        float[] curArr = curO;
        if (m.prevShot() != null && blend > 0.0F && now - m.shotStart() < blend) {
            float[] prev = new float[6];
            shot(m, prevFit.shot != null ? prevFit.shot : m.prevShot(), m.prevSide() * prevFit.sideMul,
                    m.prevStart(), now, prev);
            scale(prev, prevFit.scale);
            float[] cur2 = curArr;
            float k = (now - m.shotStart()) / blend;
            k = k * k * (3 - 2 * k);
            for (int i = 0; i < 6; i++) out[i] = prev[i] + (cur2[i] - prev[i]) * k;
            return;
        }
        System.arraycopy(curArr, 0, out, 0, 6);
    }

    /** Aproxima a câmera do ponto para onde ela olha. */
    private static void scale(float[] o, float k) {
        if (k == 1.0F) return;
        o[0] = o[3] + (o[0] - o[3]) * k;
        o[1] = o[4] + (o[1] - o[4]) * k;
        o[2] = o[5] + (o[2] - o[5]) * k;
    }

    private static void shot(CombatStateMachine m, CamShot s, float side, float since, float now, float[] o) {
        float[] p = m.playerPosition(now, new float[2]);
        float[] a = m.actors().isEmpty() ? new float[]{p[0] + 3, p[1]} : m.actors().get(0).position(now, new float[2]);
        // eixo fixado no corte
        float[] p0 = m.playerPosition(since, new float[2]);
        float[] a0 = m.actors().isEmpty() ? new float[]{p0[0] + 3, p0[1]} : m.actors().get(0).position(since, new float[2]);
        float ux = a0[0] - p0[0], uz = a0[1] - p0[1];
        float l = (float) Math.sqrt(ux * ux + uz * uz);
        if (l < 1e-3F) { ux = 1; uz = 0; } else { ux /= l; uz /= l; }
        float nx = -uz * side, nz = ux * side; // lateral
        float mx = (p[0] + a[0]) * 0.5F, mz = (p[1] + a[1]) * 0.5F;
        float dist = (float) Math.hypot(a[0] - p[0], a[1] - p[1]);
        switch (s) {
            case WIDE: {
                float back = Math.max(8.0F, dist * 0.9F + 5.0F);
                set(o, mx + nx * back - ux * 2.0F, mz + nz * back - uz * 2.0F, 4.6F, mx, mz, 0.9F);
                break;
            }
            case SIDE: {
                float back = Math.max(4.5F, dist * 0.7F + 3.0F);
                set(o, mx + nx * back, mz + nz * back, 1.7F, mx, mz, 1.1F);
                break;
            }
            case LOW:
                set(o, mx + nx * 3.4F - ux * 0.6F, mz + nz * 3.4F - uz * 0.6F, 0.35F, mx, mz, 1.45F);
                break;
            case SHOULDER:
                set(o, p[0] - ux * 3.2F + nx * 1.1F, p[1] - uz * 3.2F + nz * 1.1F, 2.1F,
                        a[0], a[1], 1.2F);
                break;
            case FRONT:
                set(o, p[0] + ux * 2.4F + nx * 0.9F, p[1] + uz * 2.4F + nz * 0.9F, 1.65F,
                        p[0], p[1], 1.45F);
                break;
            case CHASE:
                set(o, p[0] - ux * 4.2F + nx * 2.0F, p[1] - uz * 4.2F + nz * 2.0F, 2.0F,
                        p[0] + ux * 2.5F, p[1] + uz * 2.5F, 1.0F);
                break;
            case TOP:
                set(o, mx + nx * 2.0F - ux * 0.5F, mz + nz * 2.0F - uz * 0.5F, 10.0F, mx, mz, 0.5F);
                break;
            case ORBIT:
            default: {
                double ang = Math.toRadians((now - since) * 1.6F);
                float c = (float) Math.cos(ang), sn = (float) Math.sin(ang);
                float rx = nx * c - ux * sn, rz = nz * c - uz * sn;
                set(o, p[0] + rx * 4.6F, p[1] + rz * 4.6F, 2.0F, p[0], p[1], 1.2F);
                break;
            }
        }
    }

    private static void set(float[] o, float cf, float cr, float ch, float lf, float lr, float lh) {
        o[0] = cf; o[1] = cr; o[2] = ch; o[3] = lf; o[4] = lr; o[5] = lh;
    }
}
