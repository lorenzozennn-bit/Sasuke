package com.kenjutsu.combat;

import com.kenjutsu.choreo.CamShot;

/**
 * Diretor de câmera (Java puro): calcula onde fica a câmera e para onde ela
 * olha, em coordenadas da arena (f, r) e altura acima do chão do jogador.
 * Saída: {camF, camR, camH, lookF, lookR, lookH}.
 *
 * O eixo de cada plano (linha jogador → adversário) é fixado no instante do
 * corte, então a câmera não troca de lado quando os dois se cruzam; as
 * posições dos lutadores continuam ao vivo.
 */
public final class CameraDirector {

    private CameraDirector() {
    }

    public static void compute(CombatStateMachine m, float now, float[] out) {
        float[] cur = new float[6];
        shot(m, m.shot(), m.shotSide(), m.shotStart(), now, cur);
        float blend = m.shotBlend();
        if (m.prevShot() != null && blend > 0.0F && now - m.shotStart() < blend) {
            float[] prev = new float[6];
            shot(m, m.prevShot(), m.prevSide(), m.prevStart(), now, prev);
            float k = (now - m.shotStart()) / blend;
            k = k * k * (3 - 2 * k);
            for (int i = 0; i < 6; i++) out[i] = prev[i] + (cur[i] - prev[i]) * k;
            return;
        }
        System.arraycopy(cur, 0, out, 0, 6);
    }

    private static void shot(CombatStateMachine m, CamShot s, float side, float since, float now, float[] o) {
        float[] p = m.playerPosition(now, new float[2]);
        float[] a = m.actors().isEmpty() ? new float[]{p[0] + 3, p[1]} : m.actors().get(0).position(now, new float[2]);
        // eixo fixado no corte
        float[] p0 = m.playerPosition(since, new float[2]);
        float[] a0 = m.actors().isEmpty() ? new float[]{p0[0] + 3, p0[1]} : m.actors().get(0).position(since, new float[2]);
        float ux = a0[0] - p0[0], uz = a0[1] - p0[1];
        float l = (float) Math.sqrt(ux * ux + uz * uz);
        if (l < 1e-3F) { ux = 1; uz = 0; } else { ux /= l; uz /= l; }
        float nx = -uz * side, nz = ux * side; // lateral
        float mx = (p[0] + a[0]) * 0.5F, mz = (p[1] + a[1]) * 0.5F;
        float dist = (float) Math.hypot(a[0] - p[0], a[1] - p[1]);
        switch (s) {
            case WIDE: {
                float back = Math.max(8.0F, dist * 0.9F + 5.0F);
                set(o, mx + nx * back - ux * 2.0F, mz + nz * back - uz * 2.0F, 4.6F, mx, mz, 0.9F);
                break;
            }
            case SIDE: {
                float back = Math.max(4.5F, dist * 0.7F + 3.0F);
                set(o, mx + nx * back, mz + nz * back, 1.7F, mx, mz, 1.1F);
                break;
            }
            case LOW:
                set(o, mx + nx * 3.4F - ux * 0.6F, mz + nz * 3.4F - uz * 0.6F, 0.35F, mx, mz, 1.45F);
                break;
            case SHOULDER:
                set(o, p[0] - ux * 3.2F + nx * 1.1F, p[1] - uz * 3.2F + nz * 1.1F, 2.1F,
                        a[0], a[1], 1.2F);
                break;
            case FRONT:
                set(o, p[0] + ux * 2.4F + nx * 0.9F, p[1] + uz * 2.4F + nz * 0.9F, 1.65F,
                        p[0], p[1], 1.45F);
                break;
            case CHASE:
                set(o, p[0] - ux * 4.2F + nx * 2.0F, p[1] - uz * 4.2F + nz * 2.0F, 2.0F,
                        p[0] + ux * 2.5F, p[1] + uz * 2.5F, 1.0F);
                break;
            case TOP:
                set(o, mx + nx * 2.0F - ux * 0.5F, mz + nz * 2.0F - uz * 0.5F, 10.0F, mx, mz, 0.5F);
                break;
            case ORBIT:
            default: {
                double ang = Math.toRadians((now - since) * 1.6F);
                float c = (float) Math.cos(ang), sn = (float) Math.sin(ang);
                float rx = nx * c - ux * sn, rz = nz * c - uz * sn;
                set(o, p[0] + rx * 4.6F, p[1] + rz * 4.6F, 2.0F, p[0], p[1], 1.2F);
                break;
            }
        }
    }

    private static void set(float[] o, float cf, float cr, float ch, float lf, float lr, float lh) {
        o[0] = cf; o[1] = cr; o[2] = ch; o[3] = lf; o[4] = lr; o[5] = lh;
    }
}
