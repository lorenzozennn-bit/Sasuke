package com.kenjutsu.combat;

import com.kenjutsu.anim.AnimTrack;
import com.kenjutsu.anim.Pose;
import com.kenjutsu.anim.ScalarTrack;

/**
 * Adversário virtual: existe apenas na memória do cliente. Não é uma Entity,
 * não tem hitbox, não colide, não é salvo e não interage com o mundo.
 */
public final class VirtualActor {

    public final int index;
    /** Posição angular em volta do jogador (graus, relativa à arena). */
    public final float angle;
    /** true = modelo de braços finos (skin Alex), false = Steve. */
    public final boolean slim;

    final AnimTrack track = new AnimTrack();
    final ScalarTrack radius;
    boolean defeated;
    float hurtUntil = -1.0F;
    /** Instante em que a espada foi arrancada da mão (-1 = ainda armado). */
    float disarmedAt = -1.0F;

    VirtualActor(int index, float angle, float startRadius) {
        this.index = index;
        this.angle = angle;
        this.slim = false;
        this.radius = new ScalarTrack(false, startRadius);
    }

    public boolean isDefeated() {
        return defeated;
    }

    public float radius(float now) {
        return radius.value(now);
    }

    public Pose pose(float now, Pose out) {
        return track.sample(now, out);
    }

    /** 0..1 – intensidade do "flash" vermelho após levar um golpe. */
    public float hurtAmount(float now) {
        if (hurtUntil < 0.0F || now >= hurtUntil) return 0.0F;
        return Math.min(1.0F, (hurtUntil - now) / 5.0F);
    }

    public boolean isDisarmed(float now) {
        return disarmedAt >= 0.0F && now >= disarmedAt;
    }

    /** Tempo (ticks) desde que foi desarmado, ou -1. */
    public float disarmedFor(float now) {
        return disarmedAt < 0.0F ? -1.0F : now - disarmedAt;
    }

    public String currentClipName() {
        return track.clip() == null ? "none" : track.clip().name;
    }
}
