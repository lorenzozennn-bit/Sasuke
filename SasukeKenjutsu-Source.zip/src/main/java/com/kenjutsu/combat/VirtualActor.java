package com.kenjutsu.combat;

import com.kenjutsu.anim.AnimTrack;
import com.kenjutsu.anim.Pose;
import com.kenjutsu.anim.Track2D;

/**
 * Adversário virtual: existe apenas na memória do cliente. Não é uma Entity,
 * não tem hitbox, não colide, não é salvo e não interage com o mundo.
 */
public final class VirtualActor {

    public final int index;
    public final boolean slim = false;

    final AnimTrack track = new AnimTrack();
    final Track2D pos;
    boolean defeated;
    float hurtUntil = -1.0F;
    float disarmedAt = -1.0F;

    VirtualActor(int index, float x, float z) {
        this.index = index;
        this.pos = new Track2D(x, z);
    }

    public boolean isDefeated() {
        return defeated;
    }

    /** Posição (f, r) na arena. */
    public float[] position(float now, float[] out) {
        return pos.value(now, out);
    }

    public Pose pose(float now, Pose out) {
        return track.sample(now, out);
    }

    public float hurtAmount(float now) {
        if (hurtUntil < 0.0F || now >= hurtUntil) return 0.0F;
        return Math.min(1.0F, (hurtUntil - now) / 5.0F);
    }

    public boolean isDisarmed(float now) {
        return disarmedAt >= 0.0F && now >= disarmedAt;
    }

    public float disarmedFor(float now) {
        return disarmedAt < 0.0F ? -1.0F : now - disarmedAt;
    }

    public String currentClipName() {
        return track.clip() == null ? "none" : track.clip().name;
    }
}
