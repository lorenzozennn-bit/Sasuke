package com.kenjutsu.combat;

public enum CombatState {
    /** Taijutsu desligado: nenhum ator, renderização vanilla. */
    INACTIVE,
    /** Cena montada, aguardando o primeiro clique. */
    READY,
    /** Coreografia em andamento. */
    PLAYING,
    /** Todos derrotados; só a tecla R reinicia. */
    VICTORY
}
