package com.kenjutsu.combat;

import com.kenjutsu.anim.AnimTrack;
import com.kenjutsu.anim.Clip;
import com.kenjutsu.anim.Pose;
import com.kenjutsu.choreo.PlayerClips;

/** Clipe atual do jogador. A direção e a posição ficam na máquina de estados. */
public final class PlayerAnimationController {

    private final AnimTrack track = new AnimTrack();

    void reset(float now) {
        track.snap(PlayerClips.GUARD_IDLE, now);
    }

    void play(Clip clip, float now, float blend) {
        track.play(clip, now, blend);
    }

    void returnToNeutralIfDone(float now, boolean victory) {
        if (!victory && track.isFinished(now)) {
            track.play(PlayerClips.followUp(track.clip()), now, 4.0F);
        }
    }

    public Pose pose(float now, Pose out) {
        return track.sample(now, out);
    }

    public String currentClipName() {
        return track.clip() == null ? "none" : track.clip().name;
    }
}
