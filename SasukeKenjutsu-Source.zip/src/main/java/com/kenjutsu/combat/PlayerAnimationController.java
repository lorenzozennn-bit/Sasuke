package com.kenjutsu.combat;

import com.kenjutsu.anim.AnimTrack;
import com.kenjutsu.anim.Clip;
import com.kenjutsu.anim.Pose;
import com.kenjutsu.anim.ScalarTrack;
import com.kenjutsu.choreo.PlayerClips;

/** Controlador de animações do jogador: clipe atual + direção para a qual ele encara. */
public final class PlayerAnimationController {

    private final AnimTrack track = new AnimTrack();
    private final ScalarTrack facing = new ScalarTrack(true, 0.0F);

    void reset(float now, float initialFacing) {
        track.snap(PlayerClips.GUARD_IDLE, now);
        facing.reset(initialFacing);
    }

    void play(Clip clip, float now, float blend) {
        track.play(clip, now, blend);
    }

    void faceTowards(float angle, float now, float ticks) {
        facing.moveTo(angle, now, ticks);
    }

    /** Volta à guarda quando um golpe termina e nenhum clique novo chegou. */
    void returnToNeutralIfDone(float now, boolean victory) {
        if (!victory && track.isFinished(now)) {
            track.play(PlayerClips.followUp(track.clip()), now, 4.0F);
        }
    }

    public Pose pose(float now, Pose out) {
        return track.sample(now, out);
    }

    /** Direção (graus, relativa à arena) para onde o corpo do jogador está virado. */
    public float facing(float now) {
        return facing.value(now);
    }

    public String currentClipName() {
        return track.clip() == null ? "none" : track.clip().name;
    }
}
