package com.exercito;

/**
 * Ordens de um soldado: onde ficar até a batalha começar, por onde manobrar
 * (pontos em sequência) e quando passa a atacar livremente.
 */
public final class Orders {

    public final int battleId;
    public final boolean general;
    final double homeX, homeZ;
    /** Pontos de manobra em pares x, z (pode ser vazio = segurar posição). */
    final double[] points;
    /** Tick a partir do qual começa a se mover. */
    final int moveAt;
    /** Tick a partir do qual ataca qualquer inimigo (antes disso só se defende). */
    final int engageAt;
    /** Raio em que se defende antes de estar engajado. */
    final double defense;
    /** Ataca assim que chega ao último ponto da manobra. */
    final boolean engageOnArrival;
    final double faceX, faceZ;

    private int index;
    private boolean arrived;

    public Orders(int battleId, boolean general, double homeX, double homeZ, double[] points, int moveAt,
                  int engageAt, double defense, boolean engageOnArrival, double faceX, double faceZ) {
        this.battleId = battleId;
        this.general = general;
        this.homeX = homeX;
        this.homeZ = homeZ;
        this.points = points;
        this.moveAt = moveAt;
        this.engageAt = engageAt;
        this.defense = defense;
        this.engageOnArrival = engageOnArrival;
        this.faceX = faceX;
        this.faceZ = faceZ;
    }

    double targetX(int now) {
        return now < moveAt || points.length == 0 ? homeX : points[index * 2];
    }

    double targetZ(int now) {
        return now < moveAt || points.length == 0 ? homeZ : points[index * 2 + 1];
    }

    /** Chegou ao ponto atual: passa para o próximo ou marca a chegada. */
    void reached(int now) {
        if (now < moveAt) return;
        if (index * 2 + 2 < points.length) index++;
        else arrived = true;
    }

    boolean engaged(int now) {
        return now >= engageAt || (arrived && engageOnArrival);
    }
}
