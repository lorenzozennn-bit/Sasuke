package com.exercito;

import com.exercito.network.Network;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/**
 * Exército: tecla V abre a tela, você escolhe quantos soldados e de que tipo,
 * e o exército vem marchando na sua direção. Todos morrem com um golpe.
 * Usa mobs do próprio jogo (zumbis, vindicadores, esqueletos), que o Epic
 * Fight anima com os combates dele.
 */
@Mod(ExercitoMod.MODID)
public final class ExercitoMod {

    public static final String MODID = "exercito";
    /** Marca dos soldados invocados (para 1 HP, sem drops e para remover). */
    public static final String TAG = "exercito_soldado";

    public ExercitoMod() {
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::setup);
    }

    private void setup(FMLCommonSetupEvent event) {
        event.enqueueWork(Network::register);
    }
}
