package com.exercito;

import com.exercito.network.Network;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/**
 * Exército: batalhas estratégicas.
 * Tecla V abre o Conselho de Guerra: você vê o reconhecimento do exército
 * inimigo, o conselheiro sugere a melhor estratégia e os dois exércitos
 * (todos de armadura completa de netherite) se enfrentam.
 */
@Mod(ExercitoMod.MODID)
public final class ExercitoMod {

    public static final String MODID = "exercito";

    public ExercitoMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        bus.addListener(this::setup);
        bus.addListener(this::attributes);
    }

    private void setup(FMLCommonSetupEvent event) {
        event.enqueueWork(Network::register);
    }

    private void attributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.ALLY_SOLDIER.get(), Soldier.createSoldierAttributes().build());
        event.put(ModEntities.ENEMY_SOLDIER.get(), Soldier.createSoldierAttributes().build());
        event.put(ModEntities.ALLY_ARCHER.get(), Archer.createArcherAttributes().build());
        event.put(ModEntities.ENEMY_ARCHER.get(), Archer.createArcherAttributes().build());
    }
}
