package com.exercito;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/**
 * Escolhe o inimigo mais próximo do outro exército. Antes de estar engajado,
 * o soldado só reage a quem chega perto (raio de defesa das ordens).
 * Funciona inteiro no canUse: só define o alvo, nunca fica "rodando".
 */
public final class SeekEnemyGoal extends Goal {

    private final PathfinderMob mob;
    private int cooldown;

    public SeekEnemyGoal(PathfinderMob mob) {
        this.mob = mob;
        this.cooldown = mob.getRandom().nextInt(10);
        this.setFlags(EnumSet.of(Goal.Flag.TARGET));
    }

    @Override
    public boolean canUse() {
        if (--cooldown > 0) return false;
        cooldown = 6 + mob.getRandom().nextInt(5);
        LivingEntity current = mob.getTarget();
        if (current != null && War.isFoe(mob, current) && current.distanceToSqr(mob) < 24.0D * 24.0D) return false;
        LivingEntity found = War.findFoe(mob);
        if (found != null || (current != null && !War.isFoe(mob, current))) mob.setTarget(found);
        return false;
    }
}
