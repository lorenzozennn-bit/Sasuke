package com.exercito;

/** Qualquer combatente do mod: sabe de que lado está e quais ordens recebeu. */
public interface Warrior {

    /** true = exército do jogador, false = exército inimigo. */
    boolean isAllySide();

    Orders getOrders();

    void setOrders(Orders orders);
}
