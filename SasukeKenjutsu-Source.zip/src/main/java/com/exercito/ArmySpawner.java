package com.exercito;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/**
 * Invoca o exército em formação à frente do jogador e o manda atacar.
 * Os soldados nascem aos poucos (alguns por tick) para não travar o jogo.
 */
public final class ArmySpawner {

    public static final int MAX = 3000;
    private static final int PER_TICK = 12;
    private static final double START_DIST = 22.0;
    private static final double SPACING = 1.7;

    /** Um pedido de exército ainda sendo invocado. */
    private static final class Order {
        final UUID player;
        final ArmyType type;
        final int total;
        final int perRow;
        final double ox, oz, fx, fz, rx, rz;
        final float yaw;
        int done;

        Order(ServerPlayer p, int total, ArmyType type) {
            this.player = p.getUUID();
            this.type = type;
            this.total = total;
            this.perRow = Math.max(8, Math.min(40, (int) Math.ceil(Math.sqrt(total) * 1.6)));
            double yawRad = Math.toRadians(p.getYRot());
            this.fx = -Math.sin(yawRad);
            this.fz = Math.cos(yawRad);
            this.rx = -fz;   // lateral (perpendicular à frente)
            this.rz = fx;
            this.ox = p.getX();
            this.oz = p.getZ();
            this.yaw = p.getYRot() + 180.0F; // olhando para o jogador
        }
    }

    private static final Deque<Order> ORDERS = new ArrayDeque<Order>();

    private ArmySpawner() {
    }

    /** Pedido vindo da tela (tecla V) ou do comando. */
    public static void request(ServerPlayer player, int count, ArmyType type) {
        if (!allowed(player)) {
            player.sendSystemMessage(Component.literal("§cSó o dono do mundo (ou um operador) pode invocar exércitos."));
            return;
        }
        int n = Math.max(1, Math.min(MAX, count));
        ORDERS.add(new Order(player, n, type));
        player.sendSystemMessage(Component.literal("§6⚔ Um exército de §e" + n + "§6 " + type.label.toLowerCase()
                + " está vindo na sua direção!"));
    }

    static boolean allowed(ServerPlayer p) {
        return p.hasPermissions(2) || p.server.isSingleplayerOwner(p.getGameProfile());
    }

    /** Chamado no fim de cada tick do servidor. */
    public static void tick(MinecraftServer server) {
        if (ORDERS.isEmpty()) return;
        int budget = PER_TICK;
        Iterator<Order> it = ORDERS.iterator();
        while (it.hasNext() && budget > 0) {
            Order o = it.next();
            ServerPlayer p = server.getPlayerList().getPlayer(o.player);
            if (p == null) {
                it.remove();
                continue;
            }
            while (o.done < o.total && budget > 0) {
                spawnOne(p, o, o.done);
                o.done++;
                budget--;
            }
            if (o.done >= o.total) it.remove();
        }
    }

    private static void spawnOne(ServerPlayer target, Order o, int i) {
        ServerLevel level = target.serverLevel();
        int row = i / o.perRow, col = i % o.perRow;
        double side = (col - (o.perRow - 1) / 2.0) * SPACING + (row % 2 == 0 ? 0.0 : SPACING * 0.5);
        double dist = START_DIST + row * SPACING * 1.1;
        double x = o.ox + o.fx * dist + o.rx * side;
        double z = o.oz + o.fz * dist + o.rz * side;
        BlockPos column = BlockPos.containing(x, target.getY(), z);
        if (!level.hasChunkAt(column)) return;
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, column.getX(), column.getZ());

        ArmyType type = o.type == ArmyType.MIXED ? ArmyType.byId(level.random.nextInt(4)) : o.type;
        Mob mob = create(type, level);
        if (mob == null) return;
        mob.moveTo(x, y, z, o.yaw, 0.0F);
        mob.setYHeadRot(o.yaw);
        equip(mob, type);

        // morre com um golpe
        AttributeInstance hp = mob.getAttribute(Attributes.MAX_HEALTH);
        if (hp != null) hp.setBaseValue(1.0);
        mob.setHealth(1.0F);
        // enxerga e persegue de longe, avança um pouco mais rápido
        AttributeInstance follow = mob.getAttribute(Attributes.FOLLOW_RANGE);
        if (follow != null) follow.setBaseValue(128.0);
        AttributeInstance speed = mob.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) speed.setBaseValue(speed.getBaseValue() * 1.15);

        mob.setPersistenceRequired();
        mob.setCanPickUpLoot(false);
        mob.addTag(ExercitoMod.TAG);
        level.addFreshEntity(mob);
        mob.setTarget(target);
        level.sendParticles(ParticleTypes.CLOUD, x, y + 0.8, z, 6, 0.3, 0.5, 0.3, 0.02);
    }

    private static Mob create(ArmyType type, ServerLevel level) {
        switch (type) {
            case VINDICATORS:
                return EntityType.VINDICATOR.create(level);
            case SKELETONS:
                return EntityType.SKELETON.create(level);
            case WITHER:
                return EntityType.WITHER_SKELETON.create(level);
            case SOLDIERS:
            default: {
                net.minecraft.world.entity.monster.Zombie z = EntityType.ZOMBIE.create(level);
                if (z != null) z.setBaby(false);
                return z;
            }
        }
    }

    /** Armas e armadura (capacete impede que zumbis e esqueletos queimem no sol). Nada cai ao morrer. */
    private static void equip(Mob mob, ArmyType type) {
        switch (type) {
            case VINDICATORS:
                set(mob, EquipmentSlot.MAINHAND, Items.IRON_AXE);
                break;
            case SKELETONS:
                set(mob, EquipmentSlot.MAINHAND, Items.IRON_SWORD);
                set(mob, EquipmentSlot.HEAD, Items.CHAINMAIL_HELMET);
                set(mob, EquipmentSlot.CHEST, Items.CHAINMAIL_CHESTPLATE);
                break;
            case WITHER:
                set(mob, EquipmentSlot.MAINHAND, Items.STONE_SWORD);
                break;
            case SOLDIERS:
            default:
                set(mob, EquipmentSlot.MAINHAND, Items.IRON_SWORD);
                set(mob, EquipmentSlot.HEAD, Items.IRON_HELMET);
                set(mob, EquipmentSlot.CHEST, Items.IRON_CHESTPLATE);
                set(mob, EquipmentSlot.LEGS, Items.IRON_LEGGINGS);
                set(mob, EquipmentSlot.FEET, Items.IRON_BOOTS);
                break;
        }
    }

    private static void set(Mob mob, EquipmentSlot slot, net.minecraft.world.item.Item item) {
        mob.setItemSlot(slot, new ItemStack(item));
        mob.setDropChance(slot, 0.0F);
    }

    /** Remove os soldados invocados num raio de 256 blocos do jogador. */
    public static void clear(ServerPlayer player) {
        if (!allowed(player)) return;
        ORDERS.removeIf(o -> o.player.equals(player.getUUID()));
        ServerLevel level = player.serverLevel();
        List<Mob> list = new ArrayList<Mob>(level.getEntitiesOfClass(Mob.class,
                new AABB(player.blockPosition()).inflate(256.0), m -> m.getTags().contains(ExercitoMod.TAG)));
        for (Mob m : list) {
            level.sendParticles(ParticleTypes.POOF, m.getX(), m.getY() + 0.8, m.getZ(), 4, 0.2, 0.4, 0.2, 0.01);
            m.discard();
        }
        player.sendSystemMessage(Component.literal("§7Exército removido (" + list.size() + " soldados)."));
    }
}
