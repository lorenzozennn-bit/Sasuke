package com.exercito.network;

import com.exercito.ArmySpawner;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** "Remova todos os soldados invocados perto de mim." */
public final class ClearArmyMessage {

    public static void encode(ClearArmyMessage m, FriendlyByteBuf buf) {
    }

    public static ClearArmyMessage decode(FriendlyByteBuf buf) {
        return new ClearArmyMessage();
    }

    public static void handle(ClearArmyMessage m, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player != null) ArmySpawner.clear(player);
    }
}
