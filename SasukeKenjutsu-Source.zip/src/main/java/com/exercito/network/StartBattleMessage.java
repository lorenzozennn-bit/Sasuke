package com.exercito.network;

import com.exercito.Strategy;
import com.exercito.War;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** "Comece a batalha contra este exército, com esta estratégia." */
public final class StartBattleMessage {

    private final int[] enemy;
    private final int strategy;

    public StartBattleMessage(int[] enemy, int strategy) {
        this.enemy = enemy;
        this.strategy = strategy;
    }

    public static void encode(StartBattleMessage m, FriendlyByteBuf buf) {
        for (int i = 0; i < 4; i++) buf.writeVarInt(m.enemy[i]);
        buf.writeVarInt(m.strategy);
    }

    public static StartBattleMessage decode(FriendlyByteBuf buf) {
        int[] e = new int[4];
        for (int i = 0; i < 4; i++) e[i] = buf.readVarInt();
        return new StartBattleMessage(e, buf.readVarInt());
    }

    public static void handle(StartBattleMessage m, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player != null) War.start(player, m.enemy, Strategy.byId(m.strategy));
    }
}
