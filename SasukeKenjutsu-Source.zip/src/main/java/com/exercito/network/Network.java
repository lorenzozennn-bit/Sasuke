package com.exercito.network;

import com.exercito.ExercitoMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

/** Canal cliente → servidor: a tela pede, o servidor invoca. */
public final class Network {

    private static final String VERSION = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ExercitoMod.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);

    private Network() {
    }

    public static void register() {
        int id = 0;
        CHANNEL.messageBuilder(SummonArmyMessage.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(SummonArmyMessage::encode)
                .decoder(SummonArmyMessage::decode)
                .consumerMainThread(SummonArmyMessage::handle)
                .add();
        CHANNEL.messageBuilder(ClearArmyMessage.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(ClearArmyMessage::encode)
                .decoder(ClearArmyMessage::decode)
                .consumerMainThread(ClearArmyMessage::handle)
                .add();
    }
}
