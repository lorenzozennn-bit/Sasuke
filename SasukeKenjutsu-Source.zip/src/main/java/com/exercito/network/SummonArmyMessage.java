package com.exercito.network;

import com.exercito.ArmySpawner;
import com.exercito.ArmyType;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** "Invoque N soldados do tipo T vindo na minha direção." */
public final class SummonArmyMessage {

    private final int count;
    private final int type;

    public SummonArmyMessage(int count, int type) {
        this.count = count;
        this.type = type;
    }

    public static void encode(SummonArmyMessage m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.count);
        buf.writeVarInt(m.type);
    }

    public static SummonArmyMessage decode(FriendlyByteBuf buf) {
        return new SummonArmyMessage(buf.readVarInt(), buf.readVarInt());
    }

    public static void handle(SummonArmyMessage m, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player != null) ArmySpawner.request(player, m.count, ArmyType.byId(m.type));
    }
}
