package com.exercito;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.monster.AbstractSkeleton;
import net.minecraft.world.entity.monster.Skeleton;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** Arqueiro com visual de jogador (base do esqueleto, que já sabe usar arco). */
public class Archer extends Skeleton implements Warrior {

    private final boolean ally;
    private Orders orders;

    public Archer(EntityType<? extends Skeleton> type, Level level, boolean ally) {
        super(type, level);
        this.ally = ally;
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createArcherAttributes() {
        return AbstractSkeleton.createAttributes().add(Attributes.FOLLOW_RANGE, 128.0D);
    }

    /** O ataque com arco é adicionado pelo próprio esqueleto ao receber o arco. */
    @Override
    public void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(5, new MarchGoal(this));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new SeekEnemyGoal(this));
    }

    @Override
    public boolean isAllySide() {
        return ally;
    }

    @Override
    public Orders getOrders() {
        return orders;
    }

    @Override
    public void setOrders(Orders orders) {
        this.orders = orders;
    }

    @Override
    public boolean isSunBurnTick() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean shouldDespawnInPeaceful() {
        return false;
    }

    @Override
    public SoundEvent getAmbientSound() {
        return null;
    }

    @Override
    public SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PLAYER_HURT;
    }

    @Override
    public SoundEvent getDeathSound() {
        return SoundEvents.PLAYER_DEATH;
    }

    @Override
    public void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.NETHERITE_BLOCK_STEP, 0.25F, 1.0F);
    }
}
