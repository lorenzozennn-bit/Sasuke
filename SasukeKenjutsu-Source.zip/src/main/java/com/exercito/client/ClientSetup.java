package com.exercito.client;

import com.exercito.Archer;
import com.exercito.ExercitoMod;
import com.exercito.ModEntities;
import com.exercito.Soldier;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/** Tecla V (alterável em Opções > Controles > Exército) e o visual dos soldados. */
@Mod.EventBusSubscriber(modid = ExercitoMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {

    public static final KeyMapping OPEN = new KeyMapping("key.exercito.open", KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, "key.categories.exercito");

    /** Aliados com a skin do Steve, inimigos com a do Kai. */
    private static final ResourceLocation ALLY_SKIN = new ResourceLocation("minecraft", "textures/entity/player/wide/steve.png");
    private static final ResourceLocation ENEMY_SKIN = new ResourceLocation("minecraft", "textures/entity/player/wide/kai.png");

    private ClientSetup() {
    }

    @SubscribeEvent
    public static void onKeys(RegisterKeyMappingsEvent event) {
        event.register(OPEN);
    }

    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.<Soldier>registerEntityRenderer(ModEntities.ALLY_SOLDIER.get(), ctx -> new WarriorRenderer<Soldier>(ctx, ALLY_SKIN));
        event.<Soldier>registerEntityRenderer(ModEntities.ENEMY_SOLDIER.get(), ctx -> new WarriorRenderer<Soldier>(ctx, ENEMY_SKIN));
        event.<Archer>registerEntityRenderer(ModEntities.ALLY_ARCHER.get(), ctx -> new WarriorRenderer<Archer>(ctx, ALLY_SKIN));
        event.<Archer>registerEntityRenderer(ModEntities.ENEMY_ARCHER.get(), ctx -> new WarriorRenderer<Archer>(ctx, ENEMY_SKIN));
    }
}
