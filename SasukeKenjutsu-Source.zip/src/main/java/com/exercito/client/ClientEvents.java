package com.exercito.client;

import com.exercito.ExercitoMod;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Abre a tela do exército quando a tecla é pressionada em jogo. */
@Mod.EventBusSubscriber(modid = ExercitoMod.MODID, value = Dist.CLIENT)
public final class ClientEvents {

    private ClientEvents() {
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        while (ClientSetup.OPEN.consumeClick()) {
            if (mc.player != null && mc.screen == null) mc.setScreen(new ArmyScreen());
        }
    }
}
