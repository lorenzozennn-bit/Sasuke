package com.exercito.client;

import com.exercito.Strategy;
import com.exercito.War;
import com.exercito.network.ClearArmyMessage;
import com.exercito.network.Network;
import com.exercito.network.StartBattleMessage;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;
import java.util.Random;

/**
 * Conselho de Guerra: tamanho do exército inimigo, reconhecimento (composição
 * sorteada), a estratégia recomendada pelo conselheiro e o botão de batalha.
 */
public final class ArmyScreen extends Screen {

    private static final int[] SIZES = {40, 100, 200, War.MAX_ENEMIES};
    private static final String[] SIZE_NAMES = {"Pequeno", "Médio", "Grande", "Épico"};

    private static int sizeIdx = 1;
    private static int[] enemy;
    private static Strategy chosen;

    private final Button[] sizeButtons = new Button[SIZES.length];
    private int top;

    public ArmyScreen() {
        super(Component.literal("Conselho de Guerra"));
        if (enemy == null) scout();
    }

    /** Novo reconhecimento: sorteia a composição do inimigo e pede o conselho. */
    private static void scout() {
        Random r = new Random();
        int total = SIZES[sizeIdx];
        double[] w = new double[4];
        double sum = 0;
        for (int i = 0; i < 4; i++) w[i] = 1 + r.nextInt(5);
        w[r.nextInt(4)] += 6;
        for (double v : w) sum += v;
        enemy = new int[4];
        int left = total;
        for (int i = 0; i < 3; i++) {
            enemy[i] = (int) Math.round(total * w[i] / sum);
            left -= enemy[i];
        }
        if (left < 0) {
            enemy[0] = Math.max(0, enemy[0] + left);
            left = 0;
        }
        enemy[3] = left;
        chosen = Strategy.recommend(enemy);
    }

    @Override
    protected void init() {
        int cx = width / 2;
        top = Math.max(6, height / 2 - 118);
        for (int i = 0; i < SIZES.length; i++) {
            final int idx = i;
            sizeButtons[i] = addRenderableWidget(Button.builder(sizeLabel(i), b -> {
                sizeIdx = idx;
                scout();
                refresh();
            }).bounds(cx - 124 + i * 62, top + 26, 60, 20).build());
        }
        addRenderableWidget(Button.builder(Component.literal("Novo reconhecimento"), b -> scout())
                .bounds(cx - 100, top + 50, 200, 20).build());
        addRenderableWidget(Button.builder(Component.literal("◀ Outra estratégia ▶"), b ->
                chosen = Strategy.byId(chosen.ordinal() + 1)).bounds(cx - 100, top + 166, 200, 20).build());
        addRenderableWidget(Button.builder(Component.literal("§c§l⚔ À BATALHA! ⚔"), b -> battle())
                .bounds(cx - 100, top + 190, 200, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Remover todos os soldados"), b -> {
            Network.CHANNEL.sendToServer(new ClearArmyMessage());
            onClose();
        }).bounds(cx - 100, top + 214, 200, 20).build());
    }

    private static Component sizeLabel(int i) {
        return Component.literal((i == sizeIdx ? "§e§l" : "") + SIZE_NAMES[i]);
    }

    private void refresh() {
        for (int i = 0; i < sizeButtons.length; i++) {
            if (sizeButtons[i] != null) sizeButtons[i].setMessage(sizeLabel(i));
        }
    }

    private void battle() {
        Network.CHANNEL.sendToServer(new StartBattleMessage(enemy.clone(), chosen.ordinal()));
        onClose();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderBackground(g);
        int cx = width / 2;
        int y = top;
        g.drawCenteredString(font, "§6§l⚔ CONSELHO DE GUERRA ⚔", cx, y, 0xFFD24A);
        g.drawCenteredString(font, "Tamanho do exército inimigo", cx, y + 14, 0xAAAAAA);

        int total = enemy[0] + enemy[1] + enemy[2] + enemy[3] + 1;
        y = top + 76;
        g.drawCenteredString(font, "§c§lRECONHECIMENTO §r§7— " + total + " inimigos", cx, y, 0xFFFFFF);
        g.drawCenteredString(font, "§f" + enemy[0] + " §7infantaria · §f" + enemy[1] + " §7machadeiros · §f"
                + enemy[2] + " §7batedores · §f" + enemy[3] + " §7arqueiros · §f1 §7general", cx, y + 11, 0xFFFFFF);

        Strategy rec = Strategy.recommend(enemy);
        y = top + 102;
        g.drawCenteredString(font, "§e§lCONSELHEIRO: §r§f" + chosen.title
                + (chosen == rec ? " §a★ recomendada" : " §8(recomendada: " + rec.title + ")"), cx, y, 0xFFFFFF);
        g.drawCenteredString(font, "§7§o" + Strategy.reason(enemy), cx, y + 11, 0xFFFFFF);
        List<FormattedCharSequence> lines = font.split(Component.literal(chosen.description), Math.min(320, width - 20));
        int ly = y + 25;
        for (int i = 0; i < lines.size() && i < 3; i++) {
            g.drawCenteredString(font, lines.get(i), cx, ly, 0xDDDDDD);
            ly += 10;
        }
        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
