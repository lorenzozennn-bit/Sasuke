package com.exercito.client;

import com.exercito.ArmySpawner;
import com.exercito.ArmyType;
import com.exercito.network.ClearArmyMessage;
import com.exercito.network.Network;
import com.exercito.network.SummonArmyMessage;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/** Tela do exército: quantidade (qualquer número até 3000), tipo, invocar ou remover. */
public final class ArmyScreen extends Screen {

    private static String lastCount = "50";
    private static int lastType = 0;

    private EditBox count;
    private Button typeButton;

    public ArmyScreen() {
        super(Component.literal("Exército"));
    }

    @Override
    protected void init() {
        int cx = width / 2, cy = height / 2;
        count = new EditBox(font, cx - 50, cy - 46, 100, 20, Component.literal("Quantidade"));
        count.setMaxLength(4);
        count.setFilter(s -> s.matches("\\d{0,4}"));
        count.setValue(lastCount);
        addRenderableWidget(count);
        setInitialFocus(count);

        int[] presets = {10, 50, 100, 500};
        for (int i = 0; i < presets.length; i++) {
            final int n = presets[i];
            addRenderableWidget(Button.builder(Component.literal(String.valueOf(n)), b -> count.setValue(String.valueOf(n)))
                    .bounds(cx - 100 + i * 51, cy - 22, 47, 20).build());
        }

        typeButton = addRenderableWidget(Button.builder(typeLabel(), b -> {
            lastType = (lastType + 1) % ArmyType.values().length;
            b.setMessage(typeLabel());
        }).bounds(cx - 100, cy + 2, 200, 20).build());

        addRenderableWidget(Button.builder(Component.literal("§6⚔ Invocar exército"), b -> summon())
                .bounds(cx - 100, cy + 30, 200, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Remover todos os soldados"), b -> {
            Network.CHANNEL.sendToServer(new ClearArmyMessage());
            onClose();
        }).bounds(cx - 100, cy + 54, 200, 20).build());
    }

    private Component typeLabel() {
        return Component.literal("Tipo: " + ArmyType.byId(lastType).label);
    }

    private void summon() {
        String v = count.getValue();
        int n = v.isEmpty() ? 0 : Integer.parseInt(v);
        if (n <= 0) return;
        n = Math.min(n, ArmySpawner.MAX);
        lastCount = String.valueOf(n);
        Network.CHANNEL.sendToServer(new SummonArmyMessage(n, lastType));
        onClose();
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
            summon();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderBackground(g);
        int cx = width / 2, cy = height / 2;
        g.drawCenteredString(font, "§l⚔ EXÉRCITO ⚔", cx, cy - 86, 0xFFD24A);
        g.drawCenteredString(font, "Quantos oponentes? Todos morrem com um golpe.", cx, cy - 70, 0xDDDDDD);
        g.drawCenteredString(font, "Máximo " + ArmySpawner.MAX + " · Enter invoca", cx, cy + 80, 0x888888);
        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
