package com.exercito.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.ItemStack;

/** Desenha os soldados com o modelo e a skin de um jogador, com armadura. */
public class WarriorRenderer<T extends Mob> extends HumanoidMobRenderer<T, PlayerModel<T>> {

    private final ResourceLocation texture;

    public WarriorRenderer(EntityRendererProvider.Context ctx, ResourceLocation texture) {
        super(ctx, new PlayerModel<T>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.5F);
        this.texture = texture;
        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<T>(ctx.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                new HumanoidModel<T>(ctx.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
                ctx.getModelManager()));
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return texture;
    }

    @Override
    public void render(T entity, float yaw, float partialTicks, PoseStack pose, MultiBufferSource buffers, int light) {
        PlayerModel<T> model = this.getModel();
        ItemStack main = entity.getMainHandItem();
        if (main.getItem() instanceof BowItem && entity.isAggressive()) {
            model.rightArmPose = HumanoidModel.ArmPose.BOW_AND_ARROW;
        } else {
            model.rightArmPose = main.isEmpty() ? HumanoidModel.ArmPose.EMPTY : HumanoidModel.ArmPose.ITEM;
        }
        model.leftArmPose = HumanoidModel.ArmPose.EMPTY;
        super.render(entity, yaw, partialTicks, pose, buffers, light);
    }
}
