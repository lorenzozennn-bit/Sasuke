package com.exercito;

import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingExperienceDropEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Tick das batalhas, fogo amigo, sangue, baixas e o comando /exercito limpar. */
@Mod.EventBusSubscriber(modid = ExercitoMod.MODID)
public final class ServerEvents {

    private ServerEvents() {
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) War.tick(event.getServer());
    }

    /** Lado de uma entidade: true = seu exército (você incluído), false = inimigo, null = nenhum. */
    private static Boolean side(Entity e) {
        if (e instanceof Warrior) return ((Warrior) e).isAllySide();
        if (e instanceof Player) return Boolean.TRUE;
        return null;
    }

    /** Sem fogo amigo: ninguém machuca alguém do próprio lado (flechas incluídas). */
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent event) {
        Boolean victim = side(event.getEntity());
        Boolean attacker = side(event.getSource().getEntity());
        if (victim != null && attacker != null && victim.equals(attacker)
                && (event.getEntity() instanceof Warrior || event.getSource().getEntity() instanceof Warrior)) {
            event.setCanceled(true);
        }
    }

    /**
     * Você é o general: golpes inimigos em você valem 1/4 e nunca matam;
     * seus golpes em inimigos valem o dobro. E sangue em cada golpe.
     */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        LivingEntity victim = event.getEntity();
        Entity source = event.getSource().getEntity();
        if (victim instanceof Player && source instanceof Warrior && !((Warrior) source).isAllySide()) {
            float amount = event.getAmount() * 0.25F;
            if (victim.getHealth() - amount < 2.0F) amount = Math.max(0.0F, victim.getHealth() - 2.0F);
            event.setAmount(amount);
            return;
        }
        if (victim instanceof Warrior) {
            if (source instanceof Player && !((Warrior) victim).isAllySide()) event.setAmount(event.getAmount() * 2.0F);
            if (victim.level() instanceof ServerLevel) War.blood((ServerLevel) victim.level(), victim, 12);
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        LivingEntity e = event.getEntity();
        if (!(e instanceof Warrior) || !(e.level() instanceof ServerLevel)) return;
        ServerLevel level = (ServerLevel) e.level();
        War.blood(level, e, 40);
        level.playSound(null, e.getX(), e.getY(), e.getZ(), SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.HOSTILE, 0.7F, 0.6F);
        Warrior w = (Warrior) e;
        Orders o = w.getOrders();
        if (o == null) return;
        War.Battle b = War.battle(o.battleId);
        if (b == null) return;
        b.onDeath(w.isAllySide());
        if (o.general) War.generalDown(b, e);
    }

    /** Centenas de soldados mortos não enchem o chão de itens nem de XP. */
    @SubscribeEvent
    public static void onDrops(LivingDropsEvent event) {
        if (event.getEntity() instanceof Warrior) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onXp(LivingExperienceDropEvent event) {
        if (event.getEntity() instanceof Warrior) event.setCanceled(true);
    }

    /** /exercito limpar */
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("exercito")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("limpar").executes(ctx -> {
                    War.clear(ctx.getSource().getPlayerOrException(), true);
                    return 1;
                })));
    }
}
