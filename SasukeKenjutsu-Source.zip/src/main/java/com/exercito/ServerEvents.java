package com.exercito;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingExperienceDropEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Tick de invocação, soldados sem drops e o comando /exercito. */
@Mod.EventBusSubscriber(modid = ExercitoMod.MODID)
public final class ServerEvents {

    private ServerEvents() {
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) ArmySpawner.tick(event.getServer());
    }

    /** Centenas de soldados mortos não enchem o chão de itens nem de XP. */
    @SubscribeEvent
    public static void onDrops(LivingDropsEvent event) {
        if (event.getEntity().getTags().contains(ExercitoMod.TAG)) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onXp(LivingExperienceDropEvent event) {
        if (event.getEntity().getTags().contains(ExercitoMod.TAG)) event.setCanceled(true);
    }

    /** /exercito <quantidade> [soldados|vindicadores|esqueletos|wither|misturado]  ·  /exercito limpar */
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("exercito")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("limpar").executes(ctx -> {
                    ArmySpawner.clear(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.argument("quantidade", IntegerArgumentType.integer(1, ArmySpawner.MAX))
                        .executes(ctx -> {
                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                            ArmySpawner.request(p, IntegerArgumentType.getInteger(ctx, "quantidade"), ArmyType.SOLDIERS);
                            return 1;
                        })
                        .then(Commands.argument("tipo", StringArgumentType.word())
                                .executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    ArmySpawner.request(p, IntegerArgumentType.getInteger(ctx, "quantidade"),
                                            parse(StringArgumentType.getString(ctx, "tipo")));
                                    return 1;
                                }))));
    }

    private static ArmyType parse(String s) {
        switch (s.toLowerCase()) {
            case "vindicadores": return ArmyType.VINDICATORS;
            case "esqueletos": return ArmyType.SKELETONS;
            case "wither": return ArmyType.WITHER;
            case "misturado": return ArmyType.MIXED;
            default: return ArmyType.SOLDIERS;
        }
    }
}
