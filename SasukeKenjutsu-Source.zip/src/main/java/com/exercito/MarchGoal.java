package com.exercito;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.EnumSet;

/**
 * Sem alvo, o soldado cumpre as ordens: espera na posição, faz a manobra
 * (vai de ponto em ponto) e, parado, olha para o inimigo.
 */
public final class MarchGoal extends Goal {

    private final PathfinderMob mob;
    private final Warrior warrior;
    private int repath;

    public MarchGoal(PathfinderMob mob) {
        this.mob = mob;
        this.warrior = (Warrior) mob;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        return mob.getTarget() == null && warrior.getOrders() != null;
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        repath = 0;
    }

    @Override
    public void stop() {
        mob.getNavigation().stop();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        Orders o = warrior.getOrders();
        if (o == null) return;
        int now = War.now();
        double tx = o.targetX(now), tz = o.targetZ(now);
        double dx = tx - mob.getX(), dz = tz - mob.getZ();
        if (dx * dx + dz * dz > 4.0D) {
            if (--repath <= 0) {
                repath = 20;
                int y = mob.level().getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(tx), Mth.floor(tz));
                mob.getNavigation().moveTo(tx, y, tz, 1.0D);
            }
        } else {
            o.reached(now);
            if (!mob.getNavigation().isDone()) mob.getNavigation().stop();
            mob.getLookControl().setLookAt(o.faceX, mob.getEyeY(), o.faceZ);
        }
    }
}
