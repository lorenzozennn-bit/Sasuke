package com.exercito;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Soldados e arqueiros, um tipo para cada lado (aliado e inimigo). */
public final class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ExercitoMod.MODID);

    public static final RegistryObject<EntityType<Soldier>> ALLY_SOLDIER = ENTITIES.register("soldado_aliado",
            () -> EntityType.Builder.<Soldier>of((t, l) -> new Soldier(t, l, true), MobCategory.MISC)
                    .sized(0.6F, 1.95F).clientTrackingRange(10).build("soldado_aliado"));

    public static final RegistryObject<EntityType<Soldier>> ENEMY_SOLDIER = ENTITIES.register("soldado_inimigo",
            () -> EntityType.Builder.<Soldier>of((t, l) -> new Soldier(t, l, false), MobCategory.MISC)
                    .sized(0.6F, 1.95F).clientTrackingRange(10).build("soldado_inimigo"));

    public static final RegistryObject<EntityType<Archer>> ALLY_ARCHER = ENTITIES.register("arqueiro_aliado",
            () -> EntityType.Builder.<Archer>of((t, l) -> new Archer(t, l, true), MobCategory.MISC)
                    .sized(0.6F, 1.95F).clientTrackingRange(10).build("arqueiro_aliado"));

    public static final RegistryObject<EntityType<Archer>> ENEMY_ARCHER = ENTITIES.register("arqueiro_inimigo",
            () -> EntityType.Builder.<Archer>of((t, l) -> new Archer(t, l, false), MobCategory.MISC)
                    .sized(0.6F, 1.95F).clientTrackingRange(10).build("arqueiro_inimigo"));

    private ModEntities() {
    }
}
