package com.exercito;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Soldado de corpo a corpo com visual de jogador. Usa a base do zumbi (para o
 * Epic Fight animar), mas sem gemidos, sem queimar no sol e sem virar afogado.
 */
public class Soldier extends Zombie implements Warrior {

    private final boolean ally;
    private Orders orders;

    public Soldier(EntityType<? extends Zombie> type, Level level, boolean ally) {
        super(type, level);
        this.ally = ally;
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createSoldierAttributes() {
        return Zombie.createAttributes()
                .add(Attributes.FOLLOW_RANGE, 128.0D)
                .add(Attributes.SPAWN_REINFORCEMENTS_CHANCE, 0.0D);
    }

    @Override
    public void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15D, true));
        this.goalSelector.addGoal(4, new MarchGoal(this));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new SeekEnemyGoal(this));
    }

    @Override
    public boolean isAllySide() {
        return ally;
    }

    @Override
    public Orders getOrders() {
        return orders;
    }

    @Override
    public void setOrders(Orders orders) {
        this.orders = orders;
    }

    @Override
    public boolean isSunSensitive() {
        return false;
    }

    @Override
    public boolean isSunBurnTick() {
        return false;
    }

    @Override
    public boolean convertsInWater() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean shouldDespawnInPeaceful() {
        return false;
    }

    @Override
    public SoundEvent getAmbientSound() {
        return null;
    }

    @Override
    public SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PLAYER_HURT;
    }

    @Override
    public SoundEvent getDeathSound() {
        return SoundEvents.PLAYER_DEATH;
    }

    @Override
    public void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.NETHERITE_BLOCK_STEP, 0.25F, 1.0F);
    }
}
