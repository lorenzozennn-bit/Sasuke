package com.exercito;

/**
 * Estratégias do Conselho de Guerra. A composição do exército aliado segue a
 * estratégia (porcentagens de infantaria, machadeiros, batedores e arqueiros).
 */
public enum Strategy {
    PINCA("Pinça de Canas", "Aníbal, 216 a.C.",
            "O centro recua devagar e segura o inimigo. Machadeiros e batedores contornam pelos dois lados e fecham o cerco.",
            new int[]{50, 20, 20, 10}),
    MARTELO("Martelo e Bigorna", "Alexandre, o Grande",
            "A infantaria segura a linha (bigorna). Os batedores contornam o inimigo, caem sobre os arqueiros e atacam pelas costas (martelo).",
            new int[]{45, 20, 25, 10}),
    QUADRADOS("Quadrados de Infantaria", "Napoleão no Egito, 1798",
            "Dois quadrados ocos com arqueiros no meio. A carga inimiga se quebra nas pontas; depois vem o contra-ataque.",
            new int[]{55, 10, 10, 25}),
    CARGA("Golpe de Austerlitz", "Napoleão, 1805",
            "Ataque imediato. Os batedores avançam pelos flancos direto nos arqueiros antes que eles consigam atirar.",
            new int[]{30, 20, 40, 10});

    public static final String[] UNIT_NAMES = {"infantaria", "machadeiros", "batedores", "arqueiros"};

    public final String title;
    public final String origin;
    public final String description;
    private final int[] percent;

    Strategy(String title, String origin, String description, int[] percent) {
        this.title = title;
        this.origin = origin;
        this.description = description;
        this.percent = percent;
    }

    public static Strategy byId(int id) {
        Strategy[] v = values();
        return v[Math.floorMod(id, v.length)];
    }

    /** Divide o exército aliado entre os tipos de tropa. */
    public int[] split(int total) {
        int[] out = new int[4];
        int used = 0;
        for (int i = 0; i < 3; i++) {
            out[i] = Math.round(total * percent[i] / 100.0F);
            used += out[i];
        }
        out[3] = Math.max(0, total - used);
        return out;
    }

    /** Melhor estratégia contra essa composição: [infantaria, machadeiros, batedores, arqueiros]. */
    public static Strategy recommend(int[] e) {
        int total = Math.max(1, e[0] + e[1] + e[2] + e[3]);
        if (e[2] * 100 / total >= 30 && e[2] >= e[3]) return QUADRADOS;
        if (e[3] * 100 / total >= 28) return CARGA;
        if ((e[0] + e[1]) * 100 / total >= 65) return PINCA;
        return MARTELO;
    }

    public static String reason(int[] e) {
        switch (recommend(e)) {
            case QUADRADOS: return "Muitos batedores rápidos: quadrados de infantaria quebram cargas.";
            case CARGA: return "Muitos arqueiros: ataque antes que eles atirem.";
            case PINCA: return "Muita infantaria pesada no centro: envolva pelos lados.";
            default: return "Exército equilibrado: segure a frente e ataque pela retaguarda.";
        }
    }
}
