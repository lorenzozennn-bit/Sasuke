package com.exercito;

import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import org.joml.Vector3f;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Cérebro das batalhas: monta os dois exércitos em formação, dá as ordens de
 * cada estratégia, acompanha as baixas e faz a abertura e a vitória.
 */
public final class War {

    public static final int MAX_ENEMIES = 400;
    private static final int PER_TICK = 16;
    private static final double SP = 1.6D;

    public enum Unit { INFANTARIA, MACHADEIROS, BATEDORES, ARQUEIROS, GENERAL }

    private static final String[] NAMES = {
            "Batalha do Vale Sangrento", "Batalha da Colina do Corvo", "Batalha do Rio de Ferro",
            "Batalha dos Campos de Cinza", "Batalha do Passo do Lobo", "Batalha da Planície Rubra",
            "Batalha de Brusque", "Batalha da Ponte Quebrada", "Batalha do Monte das Espadas"};
    private static final String[] QUOTES = {
            "\"A vitória pertence ao mais perseverante.\" — Napoleão",
            "\"Nunca interrompa o inimigo quando ele está cometendo um erro.\" — Napoleão",
            "\"Impossível é uma palavra que só existe no dicionário dos tolos.\" — Napoleão",
            "\"Um líder é um negociante de esperança.\" — Napoleão"};

    private static int now;
    private static int nextId = 1;
    private static final Map<Integer, Battle> BATTLES = new HashMap<Integer, Battle>();
    private static final Deque<SpawnSpec> QUEUE = new ArrayDeque<SpawnSpec>();
    private static final Random RNG = new Random();

    private War() {
    }

    public static int now() {
        return now;
    }

    public static Battle battle(int id) {
        return BATTLES.get(id);
    }

    static boolean allowed(ServerPlayer p) {
        return p.hasPermissions(2) || p.server.isSingleplayerOwner(p.getGameProfile());
    }

    // ------------------------------------------------------------------ tick

    public static void tick(MinecraftServer server) {
        now++;
        int budget = PER_TICK;
        while (budget > 0 && !QUEUE.isEmpty()) {
            spawn(QUEUE.poll());
            budget--;
        }
        if (now % 20 == 0 && !BATTLES.isEmpty()) {
            Iterator<Battle> it = BATTLES.values().iterator();
            while (it.hasNext()) {
                if (it.next().update(server)) it.remove();
            }
        }
    }

    // ------------------------------------------------------------- inimigos

    /** Quem é inimigo de quem. O general inimigo só vira alvo quando sobra só ele. */
    public static boolean isFoe(Mob self, LivingEntity e) {
        if (e == null || e == self || !e.isAlive() || !(self instanceof Warrior)) return false;
        Warrior sw = (Warrior) self;
        if (e instanceof Warrior) {
            Warrior ew = (Warrior) e;
            if (ew.isAllySide() == sw.isAllySide()) return false;
            Orders eo = ew.getOrders();
            if (eo != null && eo.general) {
                Battle b = BATTLES.get(eo.battleId);
                if (b != null && b.enemiesAlive > 1) return false;
            }
            return true;
        }
        if (e instanceof Player) {
            Player p = (Player) e;
            return !sw.isAllySide() && !p.isCreative() && !p.isSpectator();
        }
        return false;
    }

    public static LivingEntity findFoe(PathfinderMob mob) {
        Orders o = ((Warrior) mob).getOrders();
        double r = (o == null || o.engaged(now)) ? 96.0D : o.defense;
        if (r <= 0.0D) return null;
        LivingEntity best = null;
        double bestD = r * r;
        List<LivingEntity> list = mob.level().getEntitiesOfClass(LivingEntity.class,
                mob.getBoundingBox().inflate(r, 16.0D, r), x -> isFoe(mob, x));
        for (LivingEntity e : list) {
            double d = e.distanceToSqr(mob);
            if (d < bestD) {
                bestD = d;
                best = e;
            }
        }
        return best;
    }

    // ------------------------------------------------------------- batalha

    /** Pedido vindo do Conselho de Guerra. enemy = [infantaria, machadeiros, batedores, arqueiros]. */
    public static void start(ServerPlayer p, int[] enemy, Strategy strategy) {
        if (!allowed(p)) {
            p.sendSystemMessage(Component.literal("§cSó o dono do mundo (ou um operador) pode iniciar batalhas."));
            return;
        }
        int[] e = new int[4];
        int eTotal = 0;
        for (int i = 0; i < 4; i++) {
            e[i] = Mth.clamp(enemy[i], 0, MAX_ENEMIES);
            if (eTotal + e[i] > MAX_ENEMIES) e[i] = MAX_ENEMIES - eTotal;
            eTotal += e[i];
        }
        if (eTotal <= 0) return;
        clear(p, false);

        boolean rec = Strategy.recommend(e) == strategy;
        int aTotal = Math.max(8, Math.round(eTotal * 0.8F));
        int[] a = strategy.split(aTotal);

        Battle b = new Battle(nextId++, p, strategy, rec, NAMES[RNG.nextInt(NAMES.length)]);
        Frame fr = new Frame(p);
        int start = now + (eTotal + aTotal + 1) / PER_TICK + 80;
        b.startTick = start;
        b.enemyTotal = eTotal + 1;
        b.enemiesAlive = eTotal + 1;
        b.allyTotal = aTotal;
        b.allyAlive = aTotal;
        b.cx = fr.x(25, 0);
        b.cz = fr.z(25, 0);
        BATTLES.put(b.id, b);

        layoutEnemy(b, fr, e, start);
        layoutAlly(b, fr, a, strategy, start);

        p.sendSystemMessage(Component.literal("§6§l⚔ CONSELHO DE GUERRA ⚔ §r§7— " + b.name));
        p.sendSystemMessage(Component.literal("§eEstratégia: §f" + strategy.title + " §8(" + strategy.origin + ")"
                + (rec ? " §a★ recomendada: +30% de força" : "")));
        p.sendSystemMessage(Component.literal("§7" + strategy.description));
        p.sendSystemMessage(Component.literal("§fSeu exército: §a" + aTotal + " §f· Inimigo: §c" + (eTotal + 1)
                + " §8(incluindo o general)"));
        p.sendSystemMessage(Component.literal("§8As tropas estão tomando posição..."));
        ServerLevel level = p.serverLevel();
        level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ANVIL_PLACE, SoundSource.PLAYERS, 1.0F, 0.8F);
    }

    private static void layoutEnemy(Battle b, Frame fr, int[] e, int start) {
        int inf = e[0], axes = e[1], fast = e[2], arch = e[3];
        int main = inf + axes;
        int pr = perRow(main);
        double front = 40.0D;
        double half = Math.min(pr, Math.max(main, 1)) * SP / 2.0D;
        addGroup(b, fr, false, units(axes, Unit.MACHADEIROS, inf, Unit.INFANTARIA), block(main, front, 0, pr, 1),
                front, 0, new double[]{10, 0}, start, start, 10, false);
        double back = front + rows(main, pr) * SP;

        int left = fast / 2, right = fast - left;
        int wpr = Math.max(3, (int) Math.ceil(Math.sqrt(Math.max(1, right))));
        double wing = half + 5 + wpr * SP / 2.0D;
        addGroup(b, fr, false, units(left, Unit.BATEDORES, 0, Unit.BATEDORES), block(left, front + 2, -wing, wpr, 1),
                front + 2, -wing, new double[]{12, -wing * 0.6}, start, start, 10, false);
        addGroup(b, fr, false, units(right, Unit.BATEDORES, 0, Unit.BATEDORES), block(right, front + 2, wing, wpr, 1),
                front + 2, wing, new double[]{12, wing * 0.6}, start, start, 10, false);

        int apr = perRow(arch);
        double af = back + 3;
        addGroup(b, fr, false, units(arch, Unit.ARQUEIROS, 0, Unit.ARQUEIROS), block(arch, af, 0, apr, 1),
                af, 0, new double[]{af - 16, 0}, start, start, 26, false);
        double archBack = af + rows(arch, apr) * SP;

        List<double[]> gp = new ArrayList<double[]>();
        gp.add(new double[]{archBack + 4, 0});
        addGroup(b, fr, false, new Unit[]{Unit.GENERAL}, gp, archBack + 4, 0, new double[0],
                start, start + 20 * 3600, 5, false);

        b.enemyHalf = Math.max(half, wing + wpr * SP / 2.0D);
        b.enemyBack = archBack;
        b.archF = af;
    }

    private static void layoutAlly(Battle b, Frame fr, int[] a, Strategy s, int start) {
        int inf = a[0], axes = a[1], fast = a[2], arch = a[3];
        double ea = b.enemyHalf, eb = b.enemyBack;
        int apr = perRow(arch);
        switch (s) {
            case PINCA: {
                int pr = perRow(inf);
                double half = Math.min(pr, Math.max(inf, 1)) * SP / 2.0D;
                addGroup(b, fr, true, units(inf, Unit.INFANTARIA, 0, Unit.INFANTARIA), block(inf, 12, 0, pr, -1),
                        12, 0, new double[]{8, 0}, start, start + 20 * 40, 9, false);
                for (int side = -1; side <= 1; side += 2) {
                    int ax = side < 0 ? axes / 2 : axes - axes / 2;
                    int fa = side < 0 ? fast / 2 : fast - fast / 2;
                    int n = ax + fa;
                    int fp = Math.max(3, (int) Math.ceil(Math.sqrt(Math.max(1, n))));
                    double r = side * (half + 5 + fp * SP / 2.0D);
                    addGroup(b, fr, true, units(fa, Unit.BATEDORES, ax, Unit.MACHADEIROS), block(n, 12, r, fp, -1),
                            12, r, new double[]{30, side * (ea + 14), 46, side * (ea + 2)},
                            start, start + 20 * 25, 3, true);
                }
                addGroup(b, fr, true, units(arch, Unit.ARQUEIROS, 0, Unit.ARQUEIROS), block(arch, 4, 0, apr, -1),
                        4, 0, new double[0], start, start + 20 * 600, 22, false);
                break;
            }
            case MARTELO: {
                int main = inf + axes;
                int pr = perRow(main);
                double half = Math.min(pr, Math.max(main, 1)) * SP / 2.0D;
                addGroup(b, fr, true, units(axes, Unit.MACHADEIROS, inf, Unit.INFANTARIA), block(main, 12, 0, pr, -1),
                        12, 0, new double[0], start, start + 20 * 45, 9, false);
                int fp = Math.max(3, (int) Math.ceil(Math.sqrt(Math.max(1, fast))));
                double r = half + 6 + fp * SP / 2.0D;
                addGroup(b, fr, true, units(fast, Unit.BATEDORES, 0, Unit.BATEDORES), block(fast, 10, r, fp, -1),
                        10, r, new double[]{30, ea + 16, eb + 4, ea * 0.3},
                        start, start + 20 * 30, 3, true);
                addGroup(b, fr, true, units(arch, Unit.ARQUEIROS, 0, Unit.ARQUEIROS), block(arch, 4, 0, apr, -1),
                        4, 0, new double[0], start, start + 20 * 600, 22, false);
                break;
            }
            case QUADRADOS: {
                int main = inf + axes;
                int n1 = main / 2, n2 = main - n1;
                int side2 = squareSide(n2);
                double size = side2 * SP;
                double c = size / 2.0D + 3;
                int a1 = arch / 2, a2 = arch - a1;
                addGroup(b, fr, true, units(axes / 2, Unit.MACHADEIROS, n1 - axes / 2, Unit.INFANTARIA),
                        hollow(n1, 14, -c), 14, -c, new double[0], start, start + 20 * 30, 8, false);
                addGroup(b, fr, true, units(axes - axes / 2, Unit.MACHADEIROS, n2 - (axes - axes / 2), Unit.INFANTARIA),
                        hollow(n2, 14, c), 14, c, new double[0], start, start + 20 * 30, 8, false);
                int ap1 = Math.max(2, (int) Math.ceil(Math.sqrt(Math.max(1, a1))));
                int ap2 = Math.max(2, (int) Math.ceil(Math.sqrt(Math.max(1, a2))));
                addGroup(b, fr, true, units(a1, Unit.ARQUEIROS, 0, Unit.ARQUEIROS), block(a1, 15, -c, ap1, -1),
                        15, -c, new double[0], start, start + 20 * 600, 24, false);
                addGroup(b, fr, true, units(a2, Unit.ARQUEIROS, 0, Unit.ARQUEIROS), block(a2, 15, c, ap2, -1),
                        15, c, new double[0], start, start + 20 * 600, 24, false);
                int fp = perRow(fast);
                addGroup(b, fr, true, units(fast, Unit.BATEDORES, 0, Unit.BATEDORES), block(fast, 2, 0, fp, -1),
                        2, 0, new double[0], start, start + 20 * 20, 6, false);
                break;
            }
            case CARGA:
            default: {
                int main = inf + axes;
                int pr = perRow(main);
                double half = Math.min(pr, Math.max(main, 1)) * SP / 2.0D;
                addGroup(b, fr, true, units(axes, Unit.MACHADEIROS, inf, Unit.INFANTARIA), block(main, 12, 0, pr, -1),
                        12, 0, new double[]{30, 0}, start, start, 10, true);
                for (int side = -1; side <= 1; side += 2) {
                    int n = side < 0 ? fast / 2 : fast - fast / 2;
                    int fp = Math.max(3, (int) Math.ceil(Math.sqrt(Math.max(1, n))));
                    double r = side * (half + 5 + fp * SP / 2.0D);
                    addGroup(b, fr, true, units(n, Unit.BATEDORES, 0, Unit.BATEDORES), block(n, 12, r, fp, -1),
                            12, r, new double[]{24, side * (ea + 10), b.archF, side * 3.0D},
                            start, start + 20 * 20, 3, true);
                }
                addGroup(b, fr, true, units(arch, Unit.ARQUEIROS, 0, Unit.ARQUEIROS), block(arch, 4, 0, apr, -1),
                        4, 0, new double[]{20, 0}, start, start + 20 * 5, 24, false);
                break;
            }
        }
    }

    /** A Velha Guarda: reforços quando o seu exército está quase destruído. */
    static void reserve(Battle b, ServerPlayer p, int enemies) {
        int n = Math.min(150, Math.max(12, enemies / 2 + 8));
        Frame fr = new Frame(p);
        int go = now + 10;
        int pr = perRow(n);
        addGroup(b, fr, true, units(n / 3, Unit.MACHADEIROS, n - n / 3, Unit.INFANTARIA), block(n, -3, 0, pr, -1),
                -3, 0, new double[0], go, go, 96, false);
        b.allyTotal += n;
        title(p, "§9§lA VELHA GUARDA!", "§7" + n + " soldados de elite entram na batalha");
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENDER_DRAGON_GROWL,
                SoundSource.PLAYERS, 1.0F, 0.9F);
        p.sendSystemMessage(Component.literal("§9A Velha Guarda chegou para virar a batalha!"));
    }

    /** O general inimigo caiu: raio e anúncio. A vitória vem logo depois. */
    static void generalDown(Battle b, LivingEntity general) {
        if (!(general.level() instanceof ServerLevel)) return;
        ServerLevel level = (ServerLevel) general.level();
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(general.getX(), general.getY(), general.getZ());
            bolt.setVisualOnly(true);
            level.addFreshEntity(bolt);
        }
        blood(level, general, 80);
        ServerPlayer p = level.getServer().getPlayerList().getPlayer(b.player);
        if (p != null) p.sendSystemMessage(Component.literal("§4§lO General inimigo caiu!"));
    }

    /** Remove todos os soldados perto do jogador e encerra as batalhas dele. */
    public static void clear(ServerPlayer p, boolean message) {
        if (!allowed(p)) return;
        BATTLES.values().removeIf(b -> b.player.equals(p.getUUID()));
        QUEUE.removeIf(s -> !BATTLES.containsKey(s.battle));
        ServerLevel level = p.serverLevel();
        List<Mob> list = level.getEntitiesOfClass(Mob.class, new AABB(p.blockPosition()).inflate(256.0D),
                x -> x instanceof Warrior);
        for (Mob m : list) {
            if (message) level.sendParticles(ParticleTypes.POOF, m.getX(), m.getY() + 0.8, m.getZ(), 3, 0.2, 0.4, 0.2, 0.01);
            m.discard();
        }
        if (message) p.sendSystemMessage(Component.literal("§7Soldados removidos (" + list.size() + ")."));
    }

    // ------------------------------------------------------------- sangue

    public static void blood(ServerLevel level, LivingEntity e, int amount) {
        double y = e.getY() + e.getBbHeight() * 0.6D;
        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.defaultBlockState()),
                e.getX(), y, e.getZ(), amount, 0.25D, 0.3D, 0.25D, 0.15D);
        level.sendParticles(new DustParticleOptions(new Vector3f(0.55F, 0.0F, 0.0F), 1.6F),
                e.getX(), y, e.getZ(), amount / 2 + 2, 0.3D, 0.35D, 0.3D, 0.0D);
    }

    static void title(ServerPlayer p, String title, String subtitle) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 70, 20));
        p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(subtitle)));
        p.connection.send(new ClientboundSetTitleTextPacket(Component.literal(title)));
    }

    static void sound(ServerPlayer p, SoundEvent sound, float volume, float pitch) {
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), sound, SoundSource.PLAYERS, volume, pitch);
    }

    // ------------------------------------------------------------- formação

    private static int perRow(int n) {
        return Math.max(6, Math.min(30, (int) Math.ceil(Math.sqrt(Math.max(1, n)) * 1.8D)));
    }

    private static int rows(int n, int perRow) {
        return (n + perRow - 1) / perRow;
    }

    /** Bloco em fileiras. dir = 1: fileiras se afastam do jogador; -1: vêm na direção dele. */
    private static List<double[]> block(int n, double front, double centerR, int perRow, int dir) {
        List<double[]> out = new ArrayList<double[]>();
        for (int i = 0; i < n; i++) {
            int row = i / perRow, col = i % perRow;
            int inRow = Math.min(perRow, n - row * perRow);
            double r = centerR + (col - (inRow - 1) / 2.0D) * SP;
            double f = front + dir * row * SP;
            out.add(new double[]{f, r});
        }
        return out;
    }

    private static int squareSide(int n) {
        return Math.max(3, (int) Math.ceil(Math.sqrt(Math.max(1, n)) * 1.3D));
    }

    /** Quadrado oco: anéis de fora para dentro, deixando o meio livre. */
    private static List<double[]> hollow(int n, double cF, double cR) {
        int side = squareSide(n);
        List<int[]> cells = new ArrayList<int[]>();
        for (int r = 0; cells.size() < n && side - 2 * r > 0; r++) {
            int a = r, z = side - 1 - r;
            if (a == z) {
                cells.add(new int[]{a, a});
                continue;
            }
            for (int y = a; y <= z; y++) cells.add(new int[]{a, y});
            for (int x = a + 1; x <= z; x++) cells.add(new int[]{x, z});
            for (int y = z - 1; y >= a; y--) cells.add(new int[]{z, y});
            for (int x = z - 1; x > a; x--) cells.add(new int[]{x, a});
        }
        List<double[]> out = new ArrayList<double[]>();
        double mid = (side - 1) / 2.0D;
        for (int i = 0; i < n && i < cells.size(); i++) {
            int[] c = cells.get(i);
            out.add(new double[]{cF + (c[0] - mid) * SP, cR + (c[1] - mid) * SP});
        }
        return out;
    }

    private static Unit[] units(int nA, Unit a, int nB, Unit b) {
        Unit[] out = new Unit[Math.max(0, nA) + Math.max(0, nB)];
        for (int i = 0; i < out.length; i++) out[i] = i < nA ? a : b;
        return out;
    }

    /**
     * Enfileira um grupo. Os pontos de manobra são do centro do grupo; cada
     * soldado mantém sua posição relativa, então a formação anda junta.
     */
    private static void addGroup(Battle b, Frame fr, boolean ally, Unit[] units, List<double[]> pos,
                                 double cF, double cR, double[] waypoints, int moveAt, int engageAt,
                                 double defense, boolean engageOnArrival) {
        int n = Math.min(units.length, pos.size());
        for (int i = 0; i < n; i++) {
            double f = pos.get(i)[0], r = pos.get(i)[1];
            double[] pts = new double[waypoints.length];
            for (int k = 0; k + 1 < waypoints.length; k += 2) {
                double wf = waypoints[k] + (f - cF), wr = waypoints[k + 1] + (r - cR);
                pts[k] = fr.x(wf, wr);
                pts[k + 1] = fr.z(wf, wr);
            }
            double faceF = ally ? f + 30 : f - 30;
            Orders o = new Orders(b.id, units[i] == Unit.GENERAL, fr.x(f, r), fr.z(f, r), pts, moveAt, engageAt,
                    defense, engageOnArrival, fr.x(faceF, r), fr.z(faceF, r));
            float yaw = ally ? fr.yaw : fr.yaw + 180.0F;
            QUEUE.add(new SpawnSpec(b.id, ally, units[i], fr.x(f, r), fr.z(f, r), yaw, o));
        }
    }

    // ------------------------------------------------------------- spawn

    private static void spawn(SpawnSpec s) {
        Battle b = BATTLES.get(s.battle);
        if (b == null) return;
        ServerLevel level = b.level;
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(s.x), Mth.floor(s.z));
        Mob mob;
        if (s.unit == Unit.ARQUEIROS) {
            mob = (s.ally ? ModEntities.ALLY_ARCHER : ModEntities.ENEMY_ARCHER).get().create(level);
        } else {
            mob = (s.ally ? ModEntities.ALLY_SOLDIER : ModEntities.ENEMY_SOLDIER).get().create(level);
        }
        if (mob == null) return;
        mob.moveTo(s.x, y, s.z, s.yaw, 0.0F);
        mob.setYHeadRot(s.yaw);
        mob.setYBodyRot(s.yaw);
        equip(mob, s.ally, s.unit);
        stats(mob, s.ally, s.unit, b.recommended);
        ((Warrior) mob).setOrders(s.orders);
        mob.setPersistenceRequired();
        mob.setCanPickUpLoot(false);
        if (s.unit == Unit.GENERAL) {
            mob.setCustomName(Component.literal("§4§lGeneral Inimigo"));
            mob.setCustomNameVisible(true);
            mob.addEffect(new MobEffectInstance(MobEffects.GLOWING, 20 * 60 * 30, 0, false, false));
        }
        level.addFreshEntity(mob);
        level.sendParticles(ParticleTypes.LARGE_SMOKE, s.x, y + 0.6, s.z, 3, 0.2, 0.4, 0.2, 0.01);
    }

    /** Armadura completa de netherite (aliados com acabamento azul, inimigos vermelho). */
    private static void equip(Mob mob, boolean ally, Unit unit) {
        armor(mob, EquipmentSlot.HEAD, Items.NETHERITE_HELMET, ally);
        armor(mob, EquipmentSlot.CHEST, Items.NETHERITE_CHESTPLATE, ally);
        armor(mob, EquipmentSlot.LEGS, Items.NETHERITE_LEGGINGS, ally);
        armor(mob, EquipmentSlot.FEET, Items.NETHERITE_BOOTS, ally);
        Item weapon;
        switch (unit) {
            case MACHADEIROS: weapon = Items.NETHERITE_AXE; break;
            case ARQUEIROS: weapon = Items.BOW; break;
            default: weapon = Items.NETHERITE_SWORD; break;
        }
        ItemStack w = new ItemStack(weapon);
        w.getOrCreateTag().putBoolean("Unbreakable", true);
        mob.setItemSlot(EquipmentSlot.MAINHAND, w);
        mob.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    private static void armor(Mob mob, EquipmentSlot slot, Item item, boolean ally) {
        ItemStack stack = new ItemStack(item);
        CompoundTag tag = stack.getOrCreateTag();
        tag.putBoolean("Unbreakable", true);
        CompoundTag trim = new CompoundTag();
        trim.putString("material", ally ? "minecraft:lapis" : "minecraft:redstone");
        trim.putString("pattern", ally ? "minecraft:sentry" : "minecraft:rib");
        tag.put("Trim", trim);
        mob.setItemSlot(slot, stack);
        mob.setDropChance(slot, 0.0F);
    }

    /** Aliados mais fortes (com a estratégia recomendada, ainda mais): você sempre vence. */
    private static void stats(Mob mob, boolean ally, Unit unit, boolean recommended) {
        double hp = ally ? 40.0D : 16.0D;
        if (unit == Unit.ARQUEIROS) hp *= 0.75D;
        if (unit == Unit.GENERAL) hp = 60.0D;
        if (ally && recommended) hp *= 1.3D;
        set(mob, Attributes.MAX_HEALTH, hp);
        mob.setHealth((float) hp);
        double attack = ally ? (recommended ? 6.5D : 5.0D) : 2.0D;
        if (unit == Unit.GENERAL) attack = 4.0D;
        set(mob, Attributes.ATTACK_DAMAGE, attack);
        double speed;
        switch (unit) {
            case BATEDORES: speed = 0.34D; break;
            case MACHADEIROS: speed = 0.24D; break;
            case GENERAL: speed = 0.23D; break;
            default: speed = 0.25D; break;
        }
        set(mob, Attributes.MOVEMENT_SPEED, speed);
        set(mob, Attributes.FOLLOW_RANGE, 128.0D);
        if (ally) set(mob, Attributes.KNOCKBACK_RESISTANCE, 0.4D);
    }

    private static void set(Mob mob, Attribute attribute, double value) {
        AttributeInstance inst = mob.getAttribute(attribute);
        if (inst != null) inst.setBaseValue(value);
    }

    // ------------------------------------------------------------- tipos

    private static final class Frame {
        final double px, pz, fx, fz, rx, rz;
        final float yaw;

        Frame(ServerPlayer p) {
            yaw = p.getYRot();
            double a = Math.toRadians(yaw);
            fx = -Math.sin(a);
            fz = Math.cos(a);
            rx = -fz;
            rz = fx;
            px = p.getX();
            pz = p.getZ();
        }

        double x(double f, double r) {
            return px + fx * f + rx * r;
        }

        double z(double f, double r) {
            return pz + fz * f + rz * r;
        }
    }

    private static final class SpawnSpec {
        final int battle;
        final boolean ally;
        final Unit unit;
        final double x, z;
        final float yaw;
        final Orders orders;

        SpawnSpec(int battle, boolean ally, Unit unit, double x, double z, float yaw, Orders orders) {
            this.battle = battle;
            this.ally = ally;
            this.unit = unit;
            this.x = x;
            this.z = z;
            this.yaw = yaw;
            this.orders = orders;
        }
    }

    /** Uma batalha em andamento. */
    public static final class Battle {
        final int id;
        final UUID player;
        final ServerLevel level;
        final Strategy strategy;
        final boolean recommended;
        final String name;
        int startTick;
        int allyTotal, enemyTotal, allyAlive, enemiesAlive, allyDeaths, enemyDeaths;
        double cx, cz, enemyHalf, enemyBack, archF;
        boolean announced, reserveUsed;

        Battle(int id, ServerPlayer p, Strategy strategy, boolean recommended, String name) {
            this.id = id;
            this.player = p.getUUID();
            this.level = p.serverLevel();
            this.strategy = strategy;
            this.recommended = recommended;
            this.name = name;
        }

        void onDeath(boolean ally) {
            if (ally) {
                allyDeaths++;
                allyAlive--;
            } else {
                enemyDeaths++;
                enemiesAlive--;
            }
        }

        /** A cada segundo. Retorna true quando a batalha acabou. */
        boolean update(MinecraftServer server) {
            ServerPlayer p = server.getPlayerList().getPlayer(player);
            if (p == null) return true;
            if (now < startTick) return false;
            AABB box = new AABB(cx - 220, level.getMinBuildHeight(), cz - 220, cx + 220, level.getMaxBuildHeight(), cz + 220);
            int a = 0, e = 0;
            for (Mob m : level.getEntitiesOfClass(Mob.class, box, x -> x instanceof Warrior
                    && ((Warrior) x).getOrders() != null && ((Warrior) x).getOrders().battleId == id)) {
                if (((Warrior) m).isAllySide()) a++;
                else e++;
            }
            allyAlive = a;
            enemiesAlive = e;
            if (!announced) {
                announced = true;
                title(p, "§4§l⚔ À BATALHA! ⚔", "§e" + strategy.title);
                sound(p, SoundEvents.ENDER_DRAGON_GROWL, 1.0F, 0.6F);
                level.playSound(null, cx, p.getY(), cz, SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 3.0F, 0.7F);
                p.sendSystemMessage(Component.literal("§4§lO inimigo avança! §r§7Siga o plano, general."));
                return false;
            }
            if (e == 0) {
                victory(p);
                return true;
            }
            if (!reserveUsed && a <= Math.max(3, allyTotal / 5)) {
                reserveUsed = true;
                reserve(this, p, e);
            }
            return now - startTick > 20 * 60 * 20;
        }

        private void victory(ServerPlayer p) {
            title(p, "§6§lVITÓRIA!", "§e" + name);
            sound(p, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1.0F, 1.0F);
            sound(p, SoundEvents.PLAYER_LEVELUP, 1.0F, 0.7F);
            sound(p, SoundEvents.TOTEM_USE, 0.6F, 1.0F);
            level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, p.getX(), p.getY() + 1.5, p.getZ(), 150, 1.5, 1.5, 1.5, 0.4);
            level.sendParticles(ParticleTypes.FIREWORK, p.getX(), p.getY() + 4, p.getZ(), 120, 4, 2, 4, 0.15);
            AABB box = new AABB(p.blockPosition()).inflate(200.0D);
            for (Mob m : level.getEntitiesOfClass(Mob.class, box, x -> x instanceof Warrior && ((Warrior) x).isAllySide())) {
                m.getJumpControl().jump();
            }
            p.sendSystemMessage(Component.literal("§6§l══════ VITÓRIA ══════"));
            p.sendSystemMessage(Component.literal("§e" + name + " §7— " + strategy.title));
            p.sendSystemMessage(Component.literal("§cBaixas inimigas: §f" + enemyDeaths + " de " + enemyTotal));
            p.sendSystemMessage(Component.literal("§aBaixas aliadas: §f" + allyDeaths + " de " + allyTotal
                    + (reserveUsed ? " §9(com a Velha Guarda)" : "")));
            p.sendSystemMessage(Component.literal("§7§o" + QUOTES[RNG.nextInt(QUOTES.length)]));
        }
    }
}
