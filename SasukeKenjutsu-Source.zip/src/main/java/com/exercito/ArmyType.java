package com.exercito;

/** Tipos de exército (todos com animações do Epic Fight). */
public enum ArmyType {
    SOLDIERS("Soldados de armadura (espada)"),
    VINDICATORS("Vindicadores (machado)"),
    SKELETONS("Esqueletos espadachins"),
    WITHER("Esqueletos wither (espada de pedra)"),
    MIXED("Misturado");

    public final String label;

    ArmyType(String label) {
        this.label = label;
    }

    public static ArmyType byId(int id) {
        ArmyType[] v = values();
        return v[Math.floorMod(id, v.length)];
    }
}
