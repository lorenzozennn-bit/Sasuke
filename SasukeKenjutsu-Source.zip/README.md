# Sasuke Kenjutsu Cinematic — NeoForge 1.21.1

Mod **só de cliente** com lutas de espada cinematográficas 1v1, inspiradas no kenjutsu do Sasuke (era Boruto).
O seu personagem e o adversário aparecem com **armadura completa e espada de netherite**. Os dois itens são apenas
visuais: o mod não exige nem altera nada no seu inventário.

## Como usar
- **V**: liga/desliga o Kenjutsu (a câmera muda para terceira pessoa).
- **Clique esquerdo**: avança para o próximo golpe.
- **R**: reinicia com outro combo, sorteado sem repetir o anterior.
- As teclas podem ser trocadas em *Opções > Controles > Sasuke Kenjutsu*.
- Ajustes ficam em `config/kenjutsu-client.toml`: velocidade, micropausa e rastro da espada.

## Combos (sorteados), no estilo "Adult Sasuke vs Madara"
1. **Choque Relâmpago**: vocês correm um contra o outro e as lâminas se chocam no meio, com faíscas e micropausa; os dois deslizam para trás. Segunda investida: ele desce a espada de cima, você bloqueia e desliza de novo. Na terceira o Chidori acende e você o atravessa com um iai elétrico.
2. **Chidori**: os raios acendem na lâmina, você dispara deixando um rastro elétrico e o atravessa com uma estocada que o lança girando no ar.
3. **Salto**: os dois saltam e as espadas se chocam no ar. No chão vêm o corte descendente contra a guarda dele, o ascendente na armadura e o chute que o lança para o alto.
4. **Tempestade**: corrida e cortes sem frear, terminando no corte giratório com Chidori.

## Movimento
- Interpolação por spline (Hermite monotônica): as articulações não param em cada pose, o movimento flui.
- A transição entre golpes parte do movimento em andamento, sem congelar a pose anterior.
- O braço esquerdo e a cabeça acompanham o corpo com um pequeno atraso, então nada se move em bloco.
- Chidori: raios azuis tremulando na lâmina, arcos saltando dela e rastro de raios nas arrancadas; vultos azuis e faíscas elétricas.
- Faíscas vermelhas e som metálico nos choques de lâmina.
- Vultos roxos de velocidade aparecem nas arrancadas, além do rastro de luz da lâmina, da micropausa nos impactos e da câmera seguindo a corrida.
- Espada só na mão direita; o braço esquerdo continua vivo.

## Compilar (GitHub Actions)
O workflow `.github/workflows/build.yml` usa Java 21 e roda `./gradlew build`. Ele funciona com o projeto
descompactado ou com o arquivo `SasukeKenjutsu-Source.zip` enviado na raiz do repositório.
O `.jar` aparece em **Actions → execução → Artifacts → SasukeKenjutsu-jar**.

Requisitos: Minecraft 1.21.1 com NeoForge 21.1.x. Coloque o `.jar` em `.minecraft/mods`.
