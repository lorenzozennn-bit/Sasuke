# Sasuke Kenjutsu Cinematic — NeoForge 1.21.1

Mod **só de cliente** com lutas de espada cinematográficas 1v1, inspiradas no kenjutsu do Sasuke (era Boruto).
O seu personagem e o adversário aparecem com **armadura completa e espada de netherite**. Os dois itens são apenas
visuais: o mod não exige nem altera nada no seu inventário.

## Como usar
- **V**: liga/desliga o Kenjutsu (a câmera muda para terceira pessoa).
- **Clique esquerdo**: avança para o próximo golpe.
- **R**: reinicia com outro combo, sorteado sem repetir o anterior.
- As teclas podem ser trocadas em *Opções > Controles > Sasuke Kenjutsu*.
- Ajustes ficam em `config/kenjutsu-client.toml`: velocidade, micropausa e rastro da espada.

## Combos (sorteados)
1. **Iai**: o inimigo corre com a espada erguida. Sasuke dispara e o corta de passagem; o inimigo cai de joelhos e depois de cara no chão, enquanto Sasuke fica de costas.
2. **Desarme**: Sasuke apara o golpe e, com um giro de pulso, arranca a espada do inimigo, que voa girando e crava no chão. Fecha com uma estocada.
3. **Tempestade**: Sasuke avança com uma sequência de cortes (descendente, ascendente, horizontal e corte giratório final).
4. **Humilhação**: Sasuke desvia de três ataques sem esforço, dá um tapa com a lâmina de lado que desarma o inimigo e o derruba com um chute frontal.

A espada só fica na mão direita; o braço esquerdo continua se movendo de forma natural. Os golpes param por um
instante no impacto (hit-stop), a lâmina deixa um rastro de luz e a câmera acompanha a corrida.

## Compilar (GitHub Actions)
O workflow `.github/workflows/build.yml` usa Java 21 e roda `./gradlew build`. Ele funciona com o projeto
descompactado ou com o arquivo `SasukeKenjutsu-Source.zip` enviado na raiz do repositório.
O `.jar` aparece em **Actions → execução → Artifacts → SasukeKenjutsu-jar**.

Requisitos: Minecraft 1.21.1 com NeoForge 21.1.x. Coloque o `.jar` em `.minecraft/mods`.
