# Sasuke Kenjutsu Cinematic — NeoForge 1.21.1

Mod **só de cliente** com lutas de espada cinematográficas 1v1, inspiradas no kenjutsu do Sasuke (era Boruto).
O seu personagem e o adversário aparecem com **armadura completa e espada de netherite**. Os dois itens são apenas
visuais: o mod não exige nem altera nada no seu inventário.

## Como usar
- **V**: liga/desliga. A arena nasce onde você está, e o inimigo aparece à sua frente, um pouco de lado.
- **Um clique esquerdo** e a luta inteira acontece sozinha, como uma cena de anime.
- **R**: nova luta onde você estiver.
- Durante a luta o WASD fica travado, porque a coreografia move o seu personagem de verdade pelo mundo, com colisão e gravidade.
- No fim você fica onde a luta terminou. A câmera orbita o vencedor por alguns segundos e depois volta ao normal; ao andar, o personagem volta ao modelo normal.
- Prefira um lugar aberto, com uns 15 blocos livres.
- Ajustes ficam em `config/kenjutsu-client.toml`: velocidade, micropausa, rastro da espada e `cinematicCamera`.

## A luta (estilo "Adult Sasuke vs Madara")
1. Vocês disparam: você em **zigue-zague com raios**, ele em linha reta. Choque no meio do campo (câmera baixa) e os dois deslizam para trás.
2. Vocês se rodeiam (câmera do alto) e investem de novo em zigue-zague. Ele desce a espada, você bloqueia e os dois deslizam (plano aberto).
3. Os dois saltam e se chocam no ar; cada um cai do outro lado e se vira.
4. Troca de perto: você apara e sai para o lado. Ele bloqueia seu corte e **te acerta** (close em você).
5. Ele salta sobre você; bloqueio e joelhada que o lança longe.
6. Close com o **Chidori** acendendo enquanto ele se levanta.
7. **Três passes relâmpago**: você o atravessa de direções diferentes, cada um com um plano diferente.
8. **Iai elétrico final**: você para de costas e ele cai. Depois a câmera orbita o vencedor.

## Visual
- Câmera cinematográfica: plano aberto, lateral, baixo, sobre o ombro, close, perseguição, do alto e órbita, com cortes secos e transições suaves. Ela não atravessa paredes.
- Corpo solto: inclina para a frente ao acelerar e para o lado nas curvas, respira e balança levemente; o braço esquerdo e a cabeça acompanham com atraso.
- Chidori com raios na lâmina, rastro elétrico e vultos azuis; faíscas vermelhas nos choques; micropausa nos impactos.

## Compilar (GitHub Actions)
O workflow `.github/workflows/build.yml` usa Java 21 e roda `./gradlew build`. Ele funciona com o projeto
descompactado ou com o arquivo `SasukeKenjutsu-Source.zip` enviado na raiz do repositório.
O `.jar` aparece em **Actions → execução → Artifacts → SasukeKenjutsu-jar**.

Requisitos: Minecraft 1.21.1 com NeoForge 21.1.x. Coloque o `.jar` em `.minecraft/mods`.
