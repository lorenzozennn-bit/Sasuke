# Exército: Batalhas Estratégicas (Forge 1.20.1 + Epic Fight)

Seja o Napoleão do Minecraft. Aperte **V** para abrir o **Conselho de Guerra**, veja o reconhecimento do exército inimigo, siga a estratégia do conselheiro e vença batalhas entre exércitos de **armadura completa de netherite**.

## Como jogar
1. Aperte **V** (pode trocar em *Opções > Controles > Exército*).
2. Escolha o tamanho do exército inimigo: **Pequeno (40)**, **Médio (100)**, **Grande (200)** ou **Épico (400)**.
3. O **reconhecimento** mostra a composição do inimigo: infantaria, machadeiros, batedores, arqueiros e o general. Use **Novo reconhecimento** para sortear outro exército.
4. O **conselheiro** recomenda a melhor estratégia (★) e explica o porquê. **Outra estratégia** troca o plano.
5. Clique em **⚔ À BATALHA! ⚔**. Os exércitos tomam posição, o inimigo fica 40 blocos à sua frente, e a batalha começa com o grito de guerra.

## Estratégias
| Estratégia | Quando o conselheiro recomenda | O que suas tropas fazem |
|---|---|---|
| **Pinça de Canas** | Muita infantaria pesada | O centro recua e segura; os flancos contornam e fecham o cerco |
| **Martelo e Bigorna** | Exército equilibrado | A linha segura; os batedores contornam e atacam pelas costas |
| **Quadrados de Infantaria** | Muitos batedores rápidos | Dois quadrados ocos com arqueiros no meio; depois, contra-ataque |
| **Golpe de Austerlitz** | Muitos arqueiros | Ataque imediato; os batedores vão direto nos arqueiros |

Com a estratégia recomendada, seu exército ganha **+30% de força**.

## Você sempre vence
- Seus soldados são bem mais fortes que os inimigos.
- Golpes inimigos em você valem 1/4 e nunca matam; seus golpes em inimigos valem o dobro.
- Se o seu exército cair para 20%, a **Velha Guarda** entra em batalha.
- O **General Inimigo** (brilhando, na retaguarda) só pode ser atacado quando sobra só ele. Quando ele cai: raio, e a tela de **VITÓRIA** com as baixas de cada lado.

## Visual
- Soldados com modelo de jogador: aliados com a skin do Steve e acabamento **azul** (lápis) na netherite; inimigos com a skin do Kai e acabamento **vermelho**.
- Sangue em cada golpe e explosão de sangue em cada morte, sons de jogador, títulos na tela.
- Com o Epic Fight instalado, os soldados usam as animações de combate dele (patch incluído no mod).

## Outros detalhes
- Sem fogo amigo (nem flechas). Mortos não deixam itens nem XP.
- **Remover todos os soldados** (na tela) ou `/exercito limpar` apaga os soldados num raio de 256 blocos.
- Os soldados aparecem aos poucos (16 por tick). Batalhas épicas (mais de 700 soldados) pesam no computador.
- Só o dono do mundo (ou um operador) pode iniciar batalhas.

## Instalação
1. Minecraft **1.20.1** com **Forge 47.x**.
2. **Epic Fight** para 1.20.1 na pasta `mods` (recomendado).
3. Este mod (`SasukeExercito-1.20.1-2.0.0.jar`) na pasta `mods`. **Apague a versão 1.0.0**, as duas não funcionam juntas.

## Compilar (GitHub Actions)
O workflow usa Java 17 e ForgeGradle 6. O `.jar` aparece em **Actions → execução → Artifacts → mod-jar**.
