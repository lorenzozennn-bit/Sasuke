# Sasuke Kenjutsu Cinematic — NeoForge 1.21.1

Mod **só de cliente** com lutas de espada cinematográficas 1v1, inspiradas no kenjutsu do Sasuke (era Boruto).
O seu personagem e o adversário aparecem com **armadura completa e espada de netherite**. Os dois itens são apenas
visuais: o mod não exige nem altera nada no seu inventário.

## Como usar
- **V**: liga/desliga. A arena nasce onde você está, e o inimigo aparece à sua frente.
- **Clique esquerdo**: avança a luta. São 7 cliques, e algumas trocas emendam sozinhas.
- **R**: começa uma nova luta onde você estiver.
- Durante a luta o WASD fica travado, porque a coreografia move o seu personagem de verdade pelo mundo.
- Quando a luta acaba, você fica onde ela terminou. Ao andar, o personagem volta ao modelo normal; o inimigo derrotado continua caído até você apertar V.
- Ajustes ficam em `config/kenjutsu-client.toml`: velocidade, micropausa e rastro da espada.

## A luta (estilo "Adult Sasuke vs Madara")
Combate real, usando o espaço. O seu personagem anda pelo terreno com colisão e gravidade; o inimigo acompanha o relevo.
1. **Investida**: vocês correm um contra o outro na diagonal e as espadas se chocam no meio do campo; os dois deslizam para trás.
2. **Rodeio**: vocês se rodeiam, medindo um ao outro, e investem de novo. Ele desce a espada de cima, você bloqueia e desliza.
3. **Salto**: os dois saltam, as lâminas se chocam no ar e cada um aterrissa do outro lado; vocês se viram.
4. **De perto**: ele ataca, você apara e sai para o lado. Seu corte bate na guarda dele, e ele contra-ataca e **te acerta**: você recua com faíscas e flash vermelho.
5. **Joelhada**: ele salta sobre você, você bloqueia e acerta uma joelhada que o lança longe.
6. **Chidori**: ele se levanta, os raios acendem na sua lâmina, os dois disparam e você o atravessa com o iai elétrico, parando de costas enquanto ele cai.

## Visual
- Movimento por spline, transições a partir do embalo e braço esquerdo e cabeça com leve atraso.
- Chidori: raios na lâmina, rastro elétrico e vultos azuis.
- Faíscas vermelhas e som metálico nos choques, além de micropausa nos impactos.
- Espada só na mão direita; o braço esquerdo continua vivo.

## Compilar (GitHub Actions)
O workflow `.github/workflows/build.yml` usa Java 21 e roda `./gradlew build`. Ele funciona com o projeto
descompactado ou com o arquivo `SasukeKenjutsu-Source.zip` enviado na raiz do repositório.
O `.jar` aparece em **Actions → execução → Artifacts → SasukeKenjutsu-jar**.

Requisitos: Minecraft 1.21.1 com NeoForge 21.1.x. Coloque o `.jar` em `.minecraft/mods`.
