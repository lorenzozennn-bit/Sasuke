# Exército do Sasuke (Forge 1.20.1 + Epic Fight)

Aperte **V**, escolha quantos oponentes quiser e um exército vem marchando na sua direção. **Todos morrem com um golpe.**

## Como usar
- **V** abre a tela do exército. A tecla pode ser trocada em *Opções > Controles > Exército*.
- Digite **qualquer quantidade**, de 1 a 3000, ou use os atalhos 10, 50, 100 e 500.
- Escolha o **tipo**:
  - **Soldados de armadura**: zumbis com armadura de ferro e espada.
  - **Vindicadores**: com machado.
  - **Esqueletos espadachins**: com cota de malha e espada.
  - **Esqueletos wither**: com espada de pedra.
  - **Misturado**.
- **Invocar exército** (ou Enter): os soldados nascem em formação, 22 blocos à sua frente, e avançam contra você. Com muitos soldados, a formação ganha mais fileiras.
- **Remover todos os soldados** apaga os soldados invocados num raio de 256 blocos.
- Comandos alternativos, para operadores: `/exercito 200 vindicadores` e `/exercito limpar`.

## Detalhes
- Cada soldado tem 1 de vida: qualquer golpe do Epic Fight o derruba.
- Não caem itens nem XP ao morrer, para o chão não ficar lotado.
- Zumbis e esqueletos usam capacete, então não queimam no sol.
- O Epic Fight anima esses mobs com os combates dele: ataques, esquivas e mortes.
- Os soldados aparecem aos poucos, 12 por tick, para o jogo não travar. Exércitos de milhares podem pesar no computador.
- Só o dono do mundo (ou um operador) pode invocar.

## Instalação
1. Minecraft **1.20.1** com **Forge 47.x**.
2. **Epic Fight** para 1.20.1 na pasta `mods`.
3. Este mod (`SasukeExercito-1.20.1-1.0.0.jar`) na pasta `mods`. Num servidor, ele também precisa estar no servidor.

## Compilar (GitHub Actions)
O workflow usa Java 17 e ForgeGradle 6. O `.jar` aparece em **Actions → execução → Artifacts → mod-jar**.
