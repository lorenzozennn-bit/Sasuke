# Sasuke Kenjutsu Cinematic — NeoForge 1.21.1

Mod **só de cliente** com lutas de espada cinematográficas 1v1, inspiradas no kenjutsu do Sasuke (era Boruto).
O seu personagem e o adversário aparecem com **armadura completa e espada de netherite**. Os dois itens são apenas
visuais: o mod não exige nem altera nada no seu inventário.

## Como usar
- **V**: liga/desliga o Kenjutsu (a câmera muda para terceira pessoa).
- **Clique esquerdo**: avança para o próximo golpe.
- **R**: reinicia com outro combo, sorteado sem repetir o anterior.
- As teclas podem ser trocadas em *Opções > Controles > Sasuke Kenjutsu*.
- Ajustes ficam em `config/kenjutsu-client.toml`: velocidade, micropausa e rastro da espada.

## Combos (sorteados): você sempre parte para cima
1. **Iai**: você dispara correndo, com a lâmina arrastada para trás. Ele ergue a espada em pânico; você crava o pé, passa ao lado dele cortando e para de costas. Ele cai de joelhos e tomba.
2. **Desarme**: você corre para cima dele; ele tenta te parar com um golpe largo. Você apara, arranca a espada da mão dele e fecha com uma estocada.
3. **Tempestade**: corrida e, sem frear, quatro cortes sempre avançando, terminando num corte giratório que o arremessa longe.
4. **Humilhação**: você caminha devagar até ele, sem erguer a espada. Desvia de três ataques sem parar de avançar enquanto ele recua; um tapa com a lâmina de lado o desarma e um chute encerra.

## Movimento
- Interpolação por spline (Hermite monotônica): as articulações não param em cada pose, o movimento flui.
- A transição entre golpes parte do movimento em andamento, sem congelar a pose anterior.
- O braço esquerdo e a cabeça acompanham o corpo com um pequeno atraso, então nada se move em bloco.
- Vultos roxos de velocidade aparecem nas arrancadas, além do rastro de luz da lâmina, da micropausa nos impactos e da câmera seguindo a corrida.
- Espada só na mão direita; o braço esquerdo continua vivo.

## Compilar (GitHub Actions)
O workflow `.github/workflows/build.yml` usa Java 21 e roda `./gradlew build`. Ele funciona com o projeto
descompactado ou com o arquivo `SasukeKenjutsu-Source.zip` enviado na raiz do repositório.
O `.jar` aparece em **Actions → execução → Artifacts → SasukeKenjutsu-jar**.

Requisitos: Minecraft 1.21.1 com NeoForge 21.1.x. Coloque o `.jar` em `.minecraft/mods`.
